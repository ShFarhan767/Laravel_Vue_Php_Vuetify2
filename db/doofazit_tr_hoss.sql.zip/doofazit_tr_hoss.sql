-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 16, 2024 at 03:44 PM
-- Server version: 10.5.23-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doofazit_tr_hoss`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_setups`
--

CREATE TABLE `account_setups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `placementType` int(11) NOT NULL,
  `headName` varchar(255) NOT NULL,
  `headCode` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleteStatus` tinyint(1) DEFAULT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `account_setups`
--

INSERT INTO `account_setups` (`id`, `placementType`, `headName`, `headCode`, `status`, `deleteStatus`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `delete_at`) VALUES
(8, 25, '103', '506', 1, NULL, 1, NULL, NULL, '2021-07-16 03:06:55', NULL, NULL),
(9, 9, '100', '102010101', 1, NULL, 1, NULL, NULL, '2021-07-16 03:06:55', NULL, NULL),
(10, 24, '102', '302', 1, NULL, 1, NULL, NULL, '2021-07-16 10:30:57', NULL, NULL),
(11, 9, '26', '202010101', 1, NULL, 1, NULL, NULL, '2021-07-18 17:39:20', NULL, NULL),
(12, 9, '27', '202010102', 1, NULL, 1, NULL, NULL, '2021-07-18 17:39:34', NULL, NULL),
(13, 9, '99', '202010103', 1, NULL, 1, NULL, NULL, '2021-07-18 17:39:48', NULL, NULL),
(14, 18, '63', '102030101', 1, NULL, 1, NULL, NULL, '2021-07-18 17:40:23', NULL, NULL),
(15, 18, '64', '102030102', 1, NULL, 1, NULL, NULL, '2021-07-18 17:40:38', NULL, NULL),
(16, 18, '101', '102030103', 1, NULL, 1, NULL, NULL, '2021-07-18 17:41:19', NULL, NULL),
(17, 13, '37', '102040202', 1, NULL, 1, NULL, NULL, '2021-07-30 11:14:40', NULL, NULL),
(18, 11, '33', '1020401', 1, NULL, 1, NULL, NULL, '2021-07-30 11:15:36', NULL, NULL),
(19, 26, '104', '503010101', 1, NULL, 1, NULL, NULL, '2021-08-06 14:09:05', NULL, NULL),
(20, 22, '92', '20202010101', 1, NULL, 1, NULL, NULL, '2021-08-12 05:30:17', NULL, NULL),
(21, 22, '105', '20202010102', 1, NULL, 1, NULL, NULL, '2021-08-12 05:30:48', NULL, NULL),
(22, 27, '106', '10101', 1, NULL, 1, NULL, NULL, '2021-08-12 07:26:38', NULL, NULL),
(23, 7, '19', '1020201', 1, NULL, 1, NULL, NULL, '2021-08-19 08:49:49', NULL, NULL),
(24, 5, '17', '202020102', 1, NULL, 1, NULL, NULL, '2021-08-25 12:29:23', NULL, NULL),
(30, 15, '45', '1020101', 1, NULL, 1, NULL, NULL, '2021-08-29 06:46:44', NULL, NULL),
(31, 15, '47', '1020101', 1, NULL, 1, NULL, NULL, '2021-08-29 06:46:54', NULL, NULL),
(32, 15, '49', '1020102', 1, NULL, 1, NULL, NULL, '2021-08-29 06:48:42', NULL, NULL),
(33, 15, '51', '1020102', 1, NULL, 1, NULL, NULL, '2021-08-29 06:48:53', NULL, NULL),
(34, 15, '46', '5', 1, NULL, 1, NULL, NULL, '2021-08-29 08:36:32', NULL, NULL),
(35, 15, '50', '5', 1, NULL, 1, NULL, NULL, '2021-08-29 08:36:48', NULL, NULL),
(36, 15, '48', '10202', 1, NULL, 1, NULL, NULL, '2021-08-29 08:37:21', NULL, NULL),
(37, 15, '52', '10202', 1, NULL, 1, NULL, NULL, '2021-08-29 08:38:03', NULL, NULL),
(38, 15, '48', '3', 1, NULL, 1, NULL, NULL, '2021-08-29 08:38:18', NULL, NULL),
(39, 15, '52', '3', 1, NULL, 1, NULL, NULL, '2021-08-29 08:38:29', NULL, NULL),
(40, 15, '93', '1020101', 1, NULL, 1, NULL, NULL, '2021-08-29 08:42:29', NULL, NULL),
(41, 15, '93', '1020102', 1, NULL, 1, NULL, NULL, '2021-08-29 08:42:38', NULL, NULL),
(42, 15, '94', '1020101', 1, NULL, 1, NULL, NULL, '2021-08-29 08:42:49', NULL, NULL),
(43, 15, '94', '1020102', 1, NULL, 1, NULL, NULL, '2021-08-29 08:42:59', NULL, NULL),
(44, 15, '46', '2020201', 1, NULL, 1, NULL, NULL, '2021-08-29 10:01:31', NULL, NULL),
(45, 9, '100', '102010101', 1, NULL, 1, NULL, NULL, '2021-08-29 19:36:58', NULL, NULL),
(46, 15, '47', '003', 1, NULL, 1, NULL, NULL, '2021-08-29 20:36:00', NULL, NULL),
(47, 15, '48', '3', 1, NULL, 1, NULL, NULL, '2021-08-29 20:37:28', NULL, NULL),
(48, 28, '107', '102010101', 1, NULL, 3, NULL, NULL, '2021-09-18 11:38:06', NULL, NULL),
(49, 28, '108', '102010102', 1, NULL, 3, NULL, NULL, '2021-09-18 11:38:16', NULL, NULL),
(50, 15, '50', '2020201', 1, NULL, 1, NULL, NULL, '2021-08-29 10:01:31', NULL, NULL),
(51, 8, '25', '1020102', 1, NULL, 19, NULL, NULL, '2021-10-06 09:17:42', NULL, NULL),
(52, 1, '1', '5010101', 1, NULL, 1, NULL, NULL, '2021-10-14 14:46:39', NULL, NULL),
(53, 1, '2', '4010201', 1, NULL, 1, NULL, NULL, '2021-10-14 14:50:42', NULL, NULL),
(54, 1, '3', '5010202', 1, NULL, 1, NULL, NULL, '2021-10-14 14:53:24', NULL, NULL),
(55, 1, '4', '5010203', 1, NULL, 1, NULL, NULL, '2021-10-14 14:53:49', NULL, NULL),
(56, 1, '5', '20202040702', 1, NULL, 1, NULL, NULL, '2021-10-14 14:54:23', NULL, NULL),
(57, 1, '6', '202020701', 1, NULL, 1, NULL, NULL, '2021-10-14 14:54:58', NULL, NULL),
(58, 1, '7', '40301', 1, NULL, 1, NULL, NULL, '2021-10-14 14:56:37', NULL, NULL),
(59, 1, '81', '102050103', 1, NULL, 1, NULL, NULL, '2021-10-14 14:57:06', NULL, NULL),
(60, 1, '83', '20202040701', 1, NULL, 1, NULL, NULL, '2021-10-14 14:57:43', NULL, NULL),
(61, 4, '13', '5040101', 1, NULL, 1, NULL, NULL, '2021-10-17 11:23:54', NULL, NULL),
(62, 4, '14', '5040102', 1, NULL, 1, NULL, NULL, '2021-10-17 11:24:10', NULL, NULL),
(63, 4, '15', '5040202', 1, NULL, 1, NULL, NULL, '2021-10-17 11:25:00', NULL, NULL),
(64, 4, '84', '4010101', 1, NULL, 1, NULL, NULL, '2021-10-17 11:32:44', NULL, NULL),
(65, 4, '86', '102050103', 1, NULL, 1, NULL, NULL, '2021-10-17 11:33:22', NULL, NULL),
(66, 4, '88', '3030101', 1, NULL, 1, NULL, NULL, '2021-10-17 11:34:03', NULL, NULL),
(67, 9, '109', '5050301', 1, NULL, 5, NULL, NULL, '2021-10-26 06:34:17', NULL, NULL),
(68, 9, '110', '5050302', 1, NULL, 5, NULL, NULL, '2021-10-26 06:34:28', NULL, NULL),
(69, 9, '111', '5050303', 1, NULL, 5, NULL, NULL, '2021-10-26 06:34:40', NULL, NULL),
(70, 18, '112', '3010101', 1, NULL, 1, NULL, NULL, '2021-10-28 05:13:44', NULL, NULL),
(71, 27, '113', '101010601', 1, NULL, 1, NULL, NULL, '2021-11-01 14:13:09', NULL, NULL),
(72, 29, '114', '1020201', 1, NULL, 1, NULL, NULL, '2021-11-06 08:36:45', NULL, NULL),
(73, 30, '115', '202020102', 1, NULL, 1, NULL, NULL, '2021-11-07 10:21:06', NULL, NULL),
(74, 30, '116', '20202010101', 1, NULL, 1, NULL, NULL, '2021-11-07 10:41:09', NULL, NULL),
(75, 30, '117', '5050301', 1, NULL, 1, NULL, NULL, '2021-11-07 11:21:32', NULL, NULL),
(76, 30, '118', '506', 1, NULL, 1, NULL, NULL, '2021-11-07 12:14:27', NULL, NULL),
(77, 31, '119', '1020201', 1, NULL, 11, NULL, NULL, '2021-11-07 18:40:10', NULL, NULL),
(78, 31, '120', '30201', 1, NULL, 11, NULL, NULL, '2021-11-07 19:58:59', NULL, NULL),
(79, 32, '121', '1020101', 1, NULL, 11, NULL, NULL, '2021-11-07 20:39:42', NULL, NULL),
(80, 32, '122', '102010201', 1, NULL, 11, 13, NULL, '2021-11-07 20:42:41', '2021-11-27 04:10:09', NULL),
(81, 32, '124', '101010601', 1, NULL, 11, NULL, NULL, '2021-11-07 21:12:15', NULL, NULL),
(82, 32, '123', '102050103', 1, NULL, 11, NULL, NULL, '2021-11-07 21:13:04', NULL, NULL),
(83, 32, '125', '102040201', 1, NULL, 11, NULL, NULL, '2021-11-07 21:13:57', NULL, NULL),
(84, 30, '126', '503010101', 1, NULL, 13, NULL, NULL, '2021-11-15 08:16:54', NULL, NULL),
(85, 29, '127', '1020101', 1, NULL, 13, NULL, NULL, '2021-11-15 11:26:49', NULL, NULL),
(86, 29, '128', '102010201', 1, NULL, 13, NULL, NULL, '2021-11-15 11:28:33', NULL, NULL),
(87, 29, '129', '102010202', 1, NULL, 13, NULL, NULL, '2021-11-15 11:35:51', NULL, NULL),
(88, 2, '10', '102050103', 1, NULL, 1, NULL, NULL, '2021-11-26 03:55:07', NULL, NULL),
(89, 2, '130', '201010102', 1, NULL, 1, NULL, NULL, '2021-11-26 04:01:13', NULL, NULL),
(90, 32, '131', '102010202', 1, NULL, 13, NULL, NULL, '2021-11-27 04:10:49', NULL, NULL),
(91, 15, '94', '1020101', 1, NULL, 1, NULL, NULL, '2021-08-29 08:42:59', NULL, NULL),
(92, 33, '131', '2010101', 1, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(93, 33, '132', '2010102', 1, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(94, 15, '48', '20101', 1, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(95, 15, '52', '20101', 1, NULL, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role` int(11) NOT NULL DEFAULT 2,
  `shopName` varchar(100) DEFAULT NULL,
  `userName` varchar(100) DEFAULT NULL,
  `employeeId` int(11) DEFAULT NULL,
  `shopSirialId` varchar(15) DEFAULT NULL,
  `shopSirialNo` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `loginStatus` int(11) DEFAULT 1,
  `lastLoginIp` varchar(255) DEFAULT NULL,
  `refferType` int(11) DEFAULT NULL,
  `refferUserId` int(11) DEFAULT NULL,
  `refferStatus` int(11) NOT NULL DEFAULT 0,
  `registredForm` int(11) NOT NULL DEFAULT 0,
  `shopLicenceTypeId` int(11) DEFAULT NULL,
  `authorizeShare` double DEFAULT NULL,
  `perShareValue` double DEFAULT NULL,
  `shareUse` int(11) DEFAULT NULL,
  `authorizeCapital` double DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `facebook` varchar(191) DEFAULT NULL,
  `youtube` varchar(191) DEFAULT NULL,
  `haveBranch` int(11) DEFAULT NULL,
  `totalBranch` int(11) DEFAULT NULL,
  `countryId` int(11) NOT NULL,
  `currencyId` int(11) DEFAULT NULL,
  `shopId` int(11) DEFAULT NULL,
  `shopTypeId` int(11) DEFAULT NULL,
  `paymentStatus` tinyint(1) NOT NULL DEFAULT 1,
  `language` int(11) NOT NULL DEFAULT 1 COMMENT '1=english, 2=bangla',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `informationNeedStatus` int(11) NOT NULL DEFAULT 0,
  `deleteStatus` tinyint(1) DEFAULT NULL,
  `reason` longtext DEFAULT NULL,
  `createBy` int(11) DEFAULT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `existingUrl` text DEFAULT NULL,
  `refferUrl` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `role`, `shopName`, `userName`, `employeeId`, `shopSirialId`, `shopSirialNo`, `email`, `password`, `pass`, `loginStatus`, `lastLoginIp`, `refferType`, `refferUserId`, `refferStatus`, `registredForm`, `shopLicenceTypeId`, `authorizeShare`, `perShareValue`, `shareUse`, `authorizeCapital`, `website`, `facebook`, `youtube`, `haveBranch`, `totalBranch`, `countryId`, `currencyId`, `shopId`, `shopTypeId`, `paymentStatus`, `language`, `status`, `informationNeedStatus`, `deleteStatus`, `reason`, `createBy`, `updateBy`, `deleteBy`, `existingUrl`, `refferUrl`, `created_at`, `updated_at`, `delete_at`) VALUES
(16, 3, 'Doofazit limited', 'doofaz', NULL, NULL, NULL, 'doofaz', '$2y$10$/P0U/6sqVeTYg596o5.rwuXtpwh.47EmjBqhnIbswZ.BF54mR7u6i', '123', 1, '1', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 19, 19, 16, NULL, 2, 1, 9, 0, 0, 'www1', 1, NULL, NULL, 'https://cashbook.com.bd/16', 'https://cutt.ly/X9QG', '2023-02-03 13:28:34', '2023-02-03 13:29:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_menus`
--

CREATE TABLE `admin_menus` (
  `adminMenuId` bigint(20) UNSIGNED NOT NULL,
  `adminMenuTitleId` int(11) NOT NULL,
  `adminMenuName` varchar(191) NOT NULL,
  `adminMenuNameBn` text NOT NULL,
  `adminMenuPosition` varchar(191) NOT NULL,
  `adminMenuUrl` varchar(191) DEFAULT NULL,
  `adminMenuIcon` varchar(191) DEFAULT NULL,
  `adminMenuStatus` int(11) NOT NULL,
  `adminSubMenuStatus` tinyint(1) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_menus`
--

INSERT INTO `admin_menus` (`adminMenuId`, `adminMenuTitleId`, `adminMenuName`, `adminMenuNameBn`, `adminMenuPosition`, `adminMenuUrl`, `adminMenuIcon`, `adminMenuStatus`, `adminSubMenuStatus`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(1, 24, 'Property Configuration', 'হোটেল সেটাপ', '1', '#', 'pe-7s-star', 1, 1, 1, 1, '2022-11-07 07:37:43', '2023-01-17 04:30:01'),
(2, 1, 'Rooms', 'হোটেল রিপোর্ট', '3', 'hotel@room@setup', 'pe-7s-star', 1, 0, 1, NULL, '2022-11-07 07:38:32', '2022-11-07 07:38:32'),
(3, 1, 'Hotels', 'Property Setup', '2', 'hotel@information@setup', 'pe-7s-star', 1, 0, 1, NULL, '2022-11-07 08:29:18', '2022-11-07 08:29:18'),
(4, 1, 'Hotel Sales Report', 'Hotel Sales Report', '4', 'hotel@sales@report', 'pe-7s-star', 0, 1, 1, NULL, '2022-11-07 09:15:22', '2022-11-07 09:15:22'),
(5, 3, 'Entry', 'ইনেভেস্টর যোগ', '1', NULL, 'pe-7s-star', 1, 1, 1, 1, '2022-11-10 05:27:53', '2023-06-03 20:19:38'),
(6, 3, 'Report', 'Report', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-10 05:28:18', '2022-11-10 05:28:18'),
(7, 4, 'Setup', 'Setup', '1', '#', 'pe-7s-star', 1, 1, 1, NULL, '2022-11-12 09:43:30', '2022-11-12 09:43:30'),
(8, 4, 'Report', 'Report', '2', '#', 'pe-7s-star', 1, 1, 1, NULL, '2022-11-12 12:22:18', '2022-11-12 12:22:18'),
(9, 5, 'Setup', 'Setup', '1', '#', 'pe-7s-star', 1, 1, 1, NULL, '2022-11-14 11:01:40', '2022-11-14 11:01:40'),
(10, 5, 'Report', 'Report', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-14 11:03:00', '2022-11-14 11:03:00'),
(11, 6, 'Setup', 'Setup', '1', NULL, 'pe-7s-star', 1, 1, 1, 1, '2022-11-16 06:06:27', '2022-11-16 06:07:40'),
(12, 6, 'Report', 'Report', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-16 06:08:03', '2022-11-16 06:08:03'),
(13, 2, 'Booking', 'Booking', '1', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-20 03:22:10', '2022-11-20 03:22:10'),
(14, 2, 'API Settings', 'API Settings', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-20 03:22:46', '2022-11-20 03:22:46'),
(15, 12, 'Setup', 'Setup', '1', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-20 03:44:44', '2022-11-20 03:44:44'),
(16, 12, 'Report', 'Report', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-20 16:21:35', '2022-11-20 16:21:35'),
(17, 13, 'Query Center', 'Query Center', '1', 'queryCenter', 'pe-7s-star', 1, 0, 1, NULL, '2022-11-28 06:21:45', '2022-11-28 06:21:45'),
(18, 13, 'Issue', 'Issue', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 06:22:30', '2022-11-28 06:22:30'),
(19, 13, 'Cancel', 'Cancel', '3', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 06:34:53', '2022-11-28 06:34:53'),
(20, 13, 'Report', 'Report', '4', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 06:46:10', '2022-11-28 06:46:10'),
(21, 8, 'Direct Sale', 'Direct Sale', '1', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 06:51:33', '2022-11-28 06:51:33'),
(23, 8, 'Accounting Voucher', 'Accounting Voucher', '2', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 06:58:22', '2022-11-28 06:58:22'),
(24, 8, 'Bank Management', 'Bank Management', '3', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 07:15:34', '2022-11-28 07:15:34'),
(25, 8, 'Report', 'Report', '4', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-11-28 07:59:30', '2022-11-28 07:59:30'),
(26, 9, 'Dashboard Customize', 'Dashboard Customize', '1', NULL, 'pe-7s-star', 1, 1, 1, NULL, '2022-12-04 10:45:32', '2022-12-04 10:45:32'),
(41, 15, 'Company Registration', 'Company Registration', '1', 'companyRegistration', 'pe-7s-star', 1, 0, 1, 1, '2021-03-24 03:08:28', '2021-03-24 22:20:58'),
(42, 15, 'Report', 'Report', '2', '#', 'pe-7s-star', 1, 1, 1, NULL, '2021-03-24 03:09:04', '2021-03-24 03:09:04'),
(45, 18, 'New Shop', 'New Shop', '1', 'newshop', 'pe-7s-star', 1, 0, 1, 1, '2021-05-02 02:24:52', '2021-05-02 03:15:49'),
(46, 18, 'Verified Shop', 'Verified Shop', '2', 'verifiedshop', 'pe-7s-star', 1, 0, 1, 1, '2021-05-02 02:26:06', '2021-05-03 01:21:56'),
(47, 18, 'Pending Shop', 'Pending Shop', '3', 'pendingshop', 'pe-7s-star', 1, 0, 1, 1, '2021-05-02 02:26:40', '2021-05-03 02:08:52'),
(48, 18, 'Cancel Shop', 'Cancel Shop', '4', 'cancelshop', 'pe-7s-star', 1, 0, 1, 1, '2021-05-02 02:27:12', '2021-05-03 02:26:47'),
(49, 18, 'Information Need', 'Information Need', '5', 'informationneedshop', 'pe-7s-star', 1, 0, 1, 1, '2021-05-02 02:27:54', '2021-05-03 03:00:03'),
(50, 18, 'Delivered', 'Delivered', '6', 'deliveredshop', 'pe-7s-star', 1, 0, 1, 1, '2021-05-02 02:28:21', '2021-05-03 03:23:33'),
(54, 19, 'Grace Date List', 'Grace Date List', '4', 'billinggracedate', 'pe-7s-star', 1, 0, 1, 1, '2021-05-03 03:52:29', '2021-05-04 01:33:36'),
(55, 19, 'Paid List', 'Paid List', '5', '#', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-03 03:53:05', '2021-05-03 03:53:05'),
(56, 19, 'Grace Date List', 'Grace Date List', '4', 'billinggracedate', 'pe-7s-star', 1, 0, 1, 1, '2021-05-03 03:52:29', '2021-05-04 01:33:36'),
(57, 19, 'Paid List', 'Paid List', '5', '#', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-03 03:53:05', '2021-05-03 03:53:05'),
(58, 19, 'Billing List', 'Billing List', '2', 'billinglist', 'pe-7s-star', 0, 0, 1, 1, '2021-05-03 03:51:17', '2021-05-08 07:56:13'),
(59, 19, 'Date Expired List', 'Date Expired List', '3', 'dateexpiredlist', 'pe-7s-star', 1, 0, 1, 1, '2021-05-03 03:51:53', '2021-05-05 01:15:43'),
(60, 19, 'Grace Date List', 'Grace Date List', '4', 'billinggracedate', 'pe-7s-star', 1, 0, 1, 1, '2021-05-03 03:52:29', '2021-05-04 01:33:36'),
(61, 19, 'Paid List', 'Paid List', '5', '#', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-03 03:53:05', '2021-05-03 03:53:05'),
(62, 19, 'Activation', 'Activation', '6', '#', 'pe-7s-star', 1, 1, 1, NULL, '2021-05-03 04:28:03', '2021-05-03 04:28:03'),
(63, 20, 'New Shop', 'New Shop', '1', 'trainingnewshop', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-05 01:28:22', '2021-05-05 01:28:22'),
(64, 20, 'Training Schedule List', 'Training Schedule List', '2', 'scheduleList', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-05 02:35:01', '2021-05-05 02:35:01'),
(65, 20, 'With Trainer Training Schedule', 'With Trainer Training Schedule', '3', 'trainertrainingschedule', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-05 04:43:01', '2021-05-05 04:43:01'),
(66, 20, 'Success Training List', 'Success Training List', '4', 'successtraining', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-05 06:09:19', '2021-05-05 06:09:19'),
(67, 22, 'Meeting Entry', 'Meeting Entry', '1', 'meetingEntry', 'pe-7s-star', 1, 1, 1, NULL, '2021-07-28 11:19:49', '2021-07-28 11:19:49'),
(68, 22, 'Meeting Report', 'Meeting Report', '2', 'meetingReport', 'pe-7s-star', 1, 1, 1, NULL, '2021-07-28 11:20:20', '2021-07-28 11:20:20'),
(69, 19, 'Bill Request List', 'Bill Request List', '7', 'newBillRequest', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-03 04:28:03', '2021-05-03 04:28:03'),
(70, 19, 'Bill Approve List', 'Bill Approve List', '8', 'newBillApproveList', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-03 04:28:03', '2021-05-03 04:28:03'),
(71, 19, 'Bill Cancel List', 'Bill Cancel List', '9', 'newBillCancelList', 'pe-7s-star', 1, 0, 1, NULL, '2021-05-03 04:28:03', '2021-05-03 04:28:03'),
(72, 23, 'Active Shop', 'Active Shop', '1', 'active@shop@list', 'pe-7s-star', 1, 0, 1, 1, '2021-10-24 22:36:43', '2021-10-24 22:37:44'),
(73, 1, 'Hotel Settings', 'Hotel Settings', '5', 'hotel@settings', 'pe-7s-star', 1, 0, 1, 1, '2023-01-17 04:54:37', '2023-01-17 05:11:20'),
(74, 25, 'Hotel Booking', 'Hotel Booking', '1', 'create@booking@new', 'pe-7s-star', 1, 0, 1, NULL, '2022-11-07 07:38:32', '2022-11-07 07:38:32');

-- --------------------------------------------------------

--
-- Table structure for table `admin_menu_title_names`
--

CREATE TABLE `admin_menu_title_names` (
  `adminMenuTitleId` bigint(20) UNSIGNED NOT NULL,
  `adminMenuTitleName` varchar(191) NOT NULL,
  `adminMenuTitleNameBn` text NOT NULL,
  `adminMenuTitlePosition` int(11) NOT NULL,
  `adminMenuTitleIcon` varchar(191) DEFAULT NULL,
  `adminMenuTitleStatus` varchar(191) NOT NULL,
  `adminMenuTitlePermission` int(11) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_menu_title_names`
--

INSERT INTO `admin_menu_title_names` (`adminMenuTitleId`, `adminMenuTitleName`, `adminMenuTitleNameBn`, `adminMenuTitlePosition`, `adminMenuTitleIcon`, `adminMenuTitleStatus`, `adminMenuTitlePermission`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(3, 'Investor', 'ইনভেস্টর', 1, 'fa fa-star', '1', 1, 1, 1, '2022-11-10 05:15:34', '2023-06-03 20:17:32'),
(15, 'Cashbook Sales Center', 'Cashbook Sales Center', 12, NULL, '1', 0, 1, 1, '2021-03-23 21:07:44', '2021-04-05 12:57:37'),
(18, 'Shop Verification', 'Shop Verification', 14, NULL, '1', 0, 1, 1, '2021-05-02 02:20:30', '2021-05-02 02:23:19'),
(19, 'Billing Department', 'Billing Department', 15, 'metismenu-icon pe-7s-paint-bucket bg-danger text-white rounded', '1', 0, 1, NULL, '2021-05-03 03:49:00', NULL),
(20, 'CRM & Training', 'CRM & Training', 16, 'metismenu-icon pe-7s-paint-bucket bg-danger text-white rounded', '1', 0, 1, NULL, '2021-05-05 01:27:11', NULL),
(22, 'Meet Or Visit', 'Meet Or Visit', 17, NULL, '1', 0, 1, 1, '2021-07-28 11:19:12', '2021-08-04 10:20:08'),
(23, 'Active Shop List', 'Active Shop List', 18, NULL, '1', 0, 1, 1, '2021-10-24 22:36:01', '2021-11-11 07:24:36'),
(24, 'Configuration', 'Configuration', 19, NULL, '1', 0, 1, NULL, '2023-01-17 04:42:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_sub_menus`
--

CREATE TABLE `admin_sub_menus` (
  `adminSubMenuId` bigint(20) UNSIGNED NOT NULL,
  `adminMenuId` int(11) NOT NULL,
  `adminSubMenuName` varchar(191) NOT NULL,
  `adminSubMenuNameBn` text NOT NULL,
  `adminSubMenuUrl` varchar(191) NOT NULL,
  `adminSubMenuePosition` int(11) NOT NULL,
  `adminSubMenueStatus` int(11) NOT NULL,
  `adminSubMenuePermission` int(11) NOT NULL DEFAULT 1 COMMENT '0=inactive, 1=active',
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_sub_menus`
--

INSERT INTO `admin_sub_menus` (`adminSubMenuId`, `adminMenuId`, `adminSubMenuName`, `adminSubMenuNameBn`, `adminSubMenuUrl`, `adminSubMenuePosition`, `adminSubMenueStatus`, `adminSubMenuePermission`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(1, 1, 'Property Type', 'Property Type', 'hotel@property@type', 1, 1, 1, 1, NULL, '2022-11-07 07:51:33', '2022-11-07 07:51:33'),
(2, 1, 'Location Entry', 'Location Entry', 'hotel@location@entry', 2, 1, 1, 1, NULL, '2022-11-07 07:53:54', '2022-11-07 07:53:54'),
(3, 1, 'Hotel Facility', 'Hotel Facility', 'hotel@facility@entry', 3, 1, 1, 1, NULL, '2022-11-07 07:59:20', '2022-11-07 07:59:20'),
(4, 1, 'Cancellation Policy', 'Cancellation Policy', 'hotel@cancellation@policy', 4, 1, 1, 1, NULL, '2022-11-07 08:04:00', '2022-11-07 08:04:00'),
(6, 3, 'Room Entry', 'Room Entry', 'room@entry', 1, 1, 1, 1, NULL, '2022-11-07 08:35:15', '2022-11-07 08:35:15'),
(7, 1, 'Room Type Entry', 'Room Type Entry', 'room@type@entry', 2, 1, 1, 1, NULL, '2022-11-07 08:35:59', '2022-11-07 08:35:59'),
(8, 1, 'Bed Type Entry', 'Bed Type Entry', 'bed@type@entry', 3, 1, 1, 1, NULL, '2022-11-07 08:36:32', '2022-11-07 08:36:32'),
(9, 1, 'Room Facility Entry', 'Room Facility Entry', 'room@facility@entry', 4, 1, 1, 1, NULL, '2022-11-07 08:37:24', '2022-11-07 08:37:24'),
(10, 2, 'Hotel Inventory', 'Hotel Inventory', 'hotel@inventory', 1, 1, 1, 1, NULL, '2022-11-07 08:41:23', '2022-11-07 08:41:23'),
(11, 2, 'Hotel Out of Inventory', 'Hotel Out of Inventory', 'hotel@stock@out', 2, 1, 1, 1, NULL, '2022-11-07 08:55:13', '2022-11-07 08:55:13'),
(12, 2, 'Hotel List', 'Hotel List', 'hotel@list', 3, 1, 1, 1, NULL, '2022-11-07 09:12:38', '2022-11-07 09:12:38'),
(13, 4, 'Direct Sale', 'Direct Sale', 'direct@sale', 1, 1, 1, 1, NULL, '2022-11-07 09:20:11', '2022-11-07 09:20:11'),
(14, 4, 'Online New Request', 'Online New Request', 'online@new@request', 2, 1, 1, 1, NULL, '2022-11-07 09:21:13', '2022-11-07 09:21:13'),
(15, 4, 'Online Pending Request', 'Online Pending Request', 'online@pending@request', 3, 1, 1, 1, NULL, '2022-11-07 09:22:50', '2022-11-07 09:22:50'),
(16, 4, 'Online Cencel Request', 'Online Cencel Request', 'online@cancel@request', 4, 1, 1, 1, NULL, '2022-11-07 09:23:49', '2022-11-07 09:23:49'),
(17, 4, 'Online Accept List', 'Online Accept List', 'online@accept@list', 5, 1, 1, 1, NULL, '2022-11-07 09:26:18', '2022-11-07 09:26:18'),
(18, 4, 'Sales Complete', 'Sales Complete', 'online@sales@complete', 6, 1, 1, 1, NULL, '2022-11-07 09:27:10', '2022-11-07 09:27:10'),
(19, 3, 'Property Entry', 'Hotel Name Entry', 'hotel@name@entry', 6, 1, 1, 1, NULL, '2022-11-09 03:29:32', '2022-11-09 03:29:32'),
(20, 3, 'Property Information', 'Hotel Information Setup', 'hotel@information@setup', 7, 1, 1, 1, NULL, '2022-11-09 09:51:23', '2022-11-09 09:51:23'),
(22, 5, 'Investory Entry', 'ইনভেস্টর যোক', 'visa@type@entry', 2, 1, 1, 1, 1, '2022-11-10 05:29:56', '2023-06-03 20:22:02'),
(27, 6, 'Investor Report', 'ইনেভেস্টর রিপোর্ট', 'working@country', 1, 1, 1, 1, 1, '2022-11-10 05:33:33', '2023-06-03 20:26:18'),
(34, 7, 'Tour Location Entry', 'Tour Location Entry', 'tour@location@entry', 1, 1, 1, 1, NULL, '2022-11-12 12:23:57', '2022-11-12 12:23:57'),
(35, 7, 'Tour Product Type', 'Tour Product Type', 'tour@product@type', 2, 1, 1, 1, NULL, '2022-11-12 12:55:02', '2022-11-12 12:55:02'),
(37, 7, 'Tour Facility Entry', 'Tour Facility Entry', 'tour@facility@entry', 4, 1, 1, 1, NULL, '2022-11-12 14:34:32', '2022-11-12 14:34:32'),
(38, 7, 'Product Name Entry', 'Product Name Entry', 'product@name@entry', 5, 1, 1, 1, NULL, '2022-11-12 15:54:26', '2022-11-12 15:54:26'),
(39, 7, 'Package Create', 'Package Create', 'package@create', 6, 1, 1, 1, NULL, '2022-11-12 16:55:15', '2022-11-12 16:55:15'),
(40, 7, 'Create Schedule', 'Create Schedule', 'create@tour@schedule', 7, 1, 1, 1, NULL, '2022-11-12 18:16:14', '2022-11-12 18:16:14'),
(41, 7, 'Create Booking', 'Create Booking', 'create@tour@booking', 8, 1, 1, 1, NULL, '2022-11-12 18:16:40', '2022-11-12 18:16:40'),
(43, 8, 'Tour Location', 'Tour Location', 'tour@location@list', 1, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(44, 8, 'Tour Product', 'Tour Product', 'tour@product@list', 2, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(45, 8, 'Tour Facility', 'Tour Facility', 'tour@facility@list', 3, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(46, 8, 'Product Name List', 'Product Name List', 'tour@product@name@list', 4, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(47, 8, 'Package List', 'Package List', 'tour@package@list', 5, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(48, 8, 'Package Schedule', 'Package Schedule', 'tour@package@schedule', 6, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(49, 8, 'Tour Booking List', 'Tour Booking List', 'tour@booking@list', 7, 1, 1, 1, NULL, '2022-11-13 15:44:45', '2022-11-13 15:44:45'),
(50, 9, 'Place Entry', 'Place Entry', 'sightseeng@place@entry', 1, 1, 1, 1, NULL, '2022-11-14 11:04:17', '2022-11-14 11:04:17'),
(51, 9, 'Event Entry', 'Event Entry', 'sightseeing@event@entry', 2, 1, 1, 1, NULL, '2022-11-15 09:17:19', '2022-11-15 09:17:19'),
(52, 9, 'Product Name Entry', 'Product Name Entry', 'sightseeing@product@new', 5, 1, 1, 1, NULL, '2022-11-15 09:22:26', '2022-11-15 09:22:26'),
(53, 9, 'Facility Entry', 'Facility Entry', 'sightseeing@facility@entry', 4, 1, 1, 1, NULL, '2022-11-15 09:23:20', '2022-11-15 09:23:20'),
(54, 9, 'Time Schedule', 'Time Schedule', 'sightseeing@time@schedule', 5, 1, 1, 1, NULL, '2022-11-15 09:24:39', '2022-11-15 09:24:39'),
(55, 9, 'Create Booking', 'Create Booking', 'sightseeing@booking', 1, 1, 1, 1, NULL, '2022-11-15 09:28:43', '2022-11-15 09:28:43'),
(56, 9, 'Extra Activity Entry', 'Extra Activity Entry', 'sightseeing@activity@entry', 4, 1, 1, 1, NULL, '2022-11-15 09:23:20', '2022-11-15 09:23:20'),
(57, 9, 'Product Price Entry', 'Product Price Entry', 'product@price@entry', 5, 1, 1, 1, NULL, '2022-11-15 09:22:26', '2022-11-15 09:22:26'),
(58, 10, 'Place List', 'Place List', 'sightseeing@place@list', 1, 1, 1, 1, NULL, '2022-11-15 15:39:05', '2022-11-15 15:39:05'),
(59, 10, 'Booking List', 'Booking List', 'sightseeing@booking@list', 2, 1, 1, 1, NULL, '2022-11-15 15:39:54', '2022-11-15 15:39:54'),
(60, 10, 'Event List', 'Event List', 'sightseeing@event@list', 3, 1, 1, 1, NULL, '2022-11-15 15:40:28', '2022-11-15 15:40:28'),
(61, 10, 'Facility List', 'Facility List', 'sightseeing@facility@list', 4, 1, 1, 1, NULL, '2022-11-15 15:41:24', '2022-11-15 15:41:24'),
(62, 10, 'Activity List', 'Activity List', 'sightseeing@activity@list', 5, 1, 1, 1, NULL, '2022-11-15 15:41:59', '2022-11-15 15:41:59'),
(63, 10, 'Product Name List', 'Product Name List', 'sightseeing@product@name@list', 6, 1, 1, 1, NULL, '2022-11-15 15:44:15', '2022-11-15 15:44:15'),
(64, 10, 'Schedual List', 'Schedual List', 'sightseeing@schedule@list', 7, 1, 1, 1, NULL, '2022-11-15 15:46:10', '2022-11-15 15:46:10'),
(65, 10, 'Product Price List', 'Product Price List', 'sightseeing@product@price@list', 8, 1, 1, 1, NULL, '2022-11-15 15:47:26', '2022-11-15 15:47:26'),
(66, 11, 'Location Entry', 'Location Entry', 'transport@location@entry', 1, 1, 1, 1, NULL, '2022-11-16 06:13:53', '2022-11-16 06:13:53'),
(67, 11, 'Vendor Entry', 'Vendor Entry', 'transport@vendor@entry', 2, 1, 1, 1, NULL, '2022-11-16 06:14:29', '2022-11-16 06:14:29'),
(68, 11, 'Car Entry', 'Car Entry', 'transport@car@entry', 3, 1, 1, 1, NULL, '2022-11-16 06:15:39', '2022-11-16 06:15:39'),
(69, 11, 'Facility Entry', 'Facility Entry', 'transport@facility@entry', 4, 1, 1, 1, NULL, '2022-11-16 06:16:59', '2022-11-16 06:16:59'),
(70, 11, 'Driver Entry', 'Driver Entry', 'transport@driver@entry', 5, 1, 1, 1, NULL, '2022-11-16 06:17:48', '2022-11-16 06:17:48'),
(71, 11, 'Car Expense Entry', 'Car Expense Entry', 'transport@carExpense@entry', 6, 1, 1, 1, NULL, '2022-11-16 06:20:06', '2022-11-16 06:20:06'),
(72, 11, 'Create Rent', 'Create Rent', 'transport@rent@entry', 7, 1, 1, 1, NULL, '2022-11-16 06:21:07', '2022-11-16 06:21:07'),
(73, 11, 'Price Entry', 'Price Entry', 'transport@price@entry', 8, 1, 1, 1, NULL, '2022-11-16 06:22:06', '2022-11-16 06:22:06'),
(74, 12, 'Location List', 'Location List', 'transport@location@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(75, 12, 'Vendor List', 'Vendor List', 'transport@vendor@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(76, 12, 'Car List', 'Car List', 'transport@car@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(77, 12, 'Facility List', 'Facility List', 'transport@facility@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(78, 12, 'Driver List', 'Driver List', 'transport@driver@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(79, 12, 'Price List', 'Price List', 'transport@price@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(80, 12, 'Expense List', 'Expense List', 'transport@carExpense@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(81, 12, 'Rent List', 'Rent List', 'transport@rent@list', 1, 1, 1, 1, NULL, '2022-11-16 16:08:15', '2022-11-16 16:08:15'),
(82, 15, 'New Quotation', 'New Quotation', 'quotation@entry', 1, 1, 1, 1, NULL, '2022-11-20 03:46:24', '2022-11-20 03:46:24'),
(83, 16, 'Quotation List', 'Quotation List', 'quotation@list', 1, 1, 1, 1, NULL, '2022-11-20 16:23:52', '2022-11-20 16:23:52'),
(84, 3, 'Create Booking', 'Create Booking', 'create@booking@entry', 8, 1, 1, 1, NULL, '2022-11-21 05:01:54', '2022-11-21 05:01:54'),
(85, 18, 'Hotel', 'Hotel', 'hotel@issue', 1, 1, 1, 1, NULL, '2022-11-28 06:23:36', '2022-11-28 06:23:36'),
(86, 18, 'Flight', 'Flight', 'flight@issue', 2, 1, 1, 1, NULL, '2022-11-28 06:24:49', '2022-11-28 06:24:49'),
(87, 18, 'Visa', 'Visa', 'visa@issue', 3, 1, 1, 1, NULL, '2022-11-28 06:25:59', '2022-11-28 06:25:59'),
(88, 18, 'Tour', 'Tour', 'tour@issue', 4, 1, 1, 1, NULL, '2022-11-28 06:27:18', '2022-11-28 06:27:18'),
(89, 18, 'Sightseeing', 'Sightseeing', 'sightseeing@issue', 5, 1, 1, 1, NULL, '2022-11-28 06:28:26', '2022-11-28 06:28:26'),
(90, 18, 'Transport', 'Transport', 'transport@issue', 6, 1, 1, 1, NULL, '2022-11-28 06:29:34', '2022-11-28 06:29:34'),
(91, 19, 'Hotel', 'Hotel', 'hotel@cancel', 1, 1, 1, 1, NULL, '2022-11-28 06:39:26', '2022-11-28 06:39:26'),
(92, 19, 'Flight', 'Flight', 'flight@cancel', 2, 1, 1, 1, NULL, '2022-11-28 06:41:53', '2022-11-28 06:41:53'),
(93, 19, 'Visa', 'Visa', 'visa@cancel', 3, 1, 1, 1, NULL, '2022-11-28 06:42:45', '2022-11-28 06:42:45'),
(94, 19, 'Tour', 'Tour', 'tour@cancel', 4, 1, 1, 1, NULL, '2022-11-28 06:43:16', '2022-11-28 06:43:16'),
(95, 19, 'Sightseeing', 'Sightseeing', 'sightseeing@cancel', 5, 1, 1, 1, NULL, '2022-11-28 06:44:15', '2022-11-28 06:44:15'),
(96, 19, 'Transport', 'Transport', 'transport@cancel', 6, 1, 1, 1, NULL, '2022-11-28 06:44:43', '2022-11-28 06:44:43'),
(97, 20, 'Issue Report', 'Issue Report', 'issue@report', 1, 1, 1, 1, NULL, '2022-11-28 06:48:44', '2022-11-28 06:48:44'),
(98, 20, 'Cancel Report', 'Cancel Report', 'cancel@report', 2, 1, 1, 1, NULL, '2022-11-28 06:49:50', '2022-11-28 06:49:50'),
(99, 23, 'Cash Payment', 'Cash Payment', 'cash@payment@voucher', 1, 1, 1, 1, NULL, '2022-11-28 07:00:12', '2022-11-28 07:00:12'),
(100, 23, 'Cash Receipt', 'Cash Receipt', 'cash@receipt@voucher', 2, 1, 1, 1, NULL, '2022-11-28 07:01:04', '2022-11-28 07:01:04'),
(101, 23, 'Bank Payment', 'Bank Payment', 'bank@payment@voucher', 3, 1, 1, 1, NULL, '2022-11-28 07:02:10', '2022-11-28 07:02:10'),
(102, 23, 'Bank Receipt', 'Bank Receipt', 'bank@receipt@voucher', 3, 1, 1, 1, NULL, '2022-11-28 07:02:10', '2022-11-28 07:02:10'),
(103, 23, 'Journal', 'Journal', 'journal@voucher', 4, 1, 1, 1, 1, '2022-11-28 07:09:30', '2022-11-28 07:09:47'),
(104, 23, 'Contra', 'Contra', 'contra@voucher', 5, 1, 1, 1, NULL, '2022-11-28 07:10:28', '2022-11-28 07:10:28'),
(105, 24, 'Bank Entry', 'Bank Entry', 'bank@entry', 1, 1, 1, 1, NULL, '2022-11-28 07:48:46', '2022-11-28 07:48:46'),
(106, 24, 'Cheque Book Entry', 'Cheque Book Entry', 'cheque@entry', 2, 1, 1, 1, NULL, '2022-11-28 07:51:57', '2022-11-28 07:51:57'),
(109, 25, 'Voucher List', 'Voucher List', 'voucher@list', 1, 1, 1, 1, NULL, '2022-11-28 08:42:24', '2022-11-28 08:42:24'),
(110, 25, 'General Journal', 'General Journal', 'general@journal', 2, 1, 1, 1, NULL, '2022-11-28 09:34:50', '2022-11-28 09:34:50'),
(111, 25, 'General Ledger', 'General Ledger', 'general@ledger', 2, 1, 1, 1, NULL, '2022-11-28 09:34:50', '2022-11-28 09:34:50'),
(112, 25, 'Income Summery', 'Income Summery', 'income@summery', 2, 1, 1, 1, NULL, '2022-11-28 09:34:50', '2022-11-28 09:34:50'),
(113, 25, 'Expense Summery', 'Expense Summery', 'expense@summery', 2, 1, 1, 1, NULL, '2022-11-28 09:34:50', '2022-11-28 09:34:50'),
(114, 25, 'Payment Summery', 'Payment Summery', 'payment@summery', 3, 1, 1, 1, NULL, '2022-11-28 09:56:52', '2022-11-28 09:56:52'),
(115, 25, 'Receive Summery', 'Receive Summery', 'receive@summery', 4, 1, 1, 1, NULL, '2022-11-28 09:57:44', '2022-11-28 09:57:44'),
(116, 25, 'Trial Balance', 'Trial Balance', 'trial@balance', 5, 1, 1, 1, NULL, '2022-11-28 09:58:46', '2022-11-28 09:58:46'),
(117, 25, 'Balance Sheet', 'Balance Sheet', 'balance@sheet', 6, 1, 1, 1, NULL, '2022-11-28 09:59:43', '2022-11-28 09:59:43'),
(118, 25, 'Bank Account', 'Bank Account', 'bank@account', 7, 1, 1, 1, NULL, '2022-11-28 10:00:46', '2022-11-28 10:00:46'),
(119, 25, 'Cash Account', 'Cash Account', 'cash@account', 8, 1, 1, 1, NULL, '2022-11-28 10:01:35', '2022-11-28 10:01:35'),
(120, 25, 'Cheque Book List', 'Cheque Book List', 'cheque@book@list', 9, 1, 1, 1, NULL, '2022-11-28 10:02:16', '2022-11-28 10:02:16'),
(121, 25, 'Pending Payment Cheque', 'Pending Payment Cheque', 'pending@payment@cheque', 10, 1, 1, 1, NULL, '2022-11-28 10:05:30', '2022-11-28 10:05:30'),
(122, 25, 'Pending Receipt Cheque', 'Pending Receipt Cheque', 'pending@receipt@cheque', 11, 1, 1, 1, NULL, '2022-11-28 10:07:29', '2022-11-28 10:07:29'),
(123, 25, 'Payable List', 'Payable List', 'payable@list', 12, 1, 1, 1, NULL, '2022-11-28 10:09:34', '2022-11-28 10:09:34'),
(124, 25, 'Receiveable List', 'Receiveable List', 'receivable@list', 13, 1, 1, 1, 1, '2022-11-28 10:27:32', '2022-11-28 10:33:05'),
(125, 25, 'Advance Payment List', 'Advance Payment List', 'advance@payment@list', 14, 1, 1, 1, NULL, '2022-11-28 10:29:01', '2022-11-28 10:29:01'),
(126, 25, 'Statement', 'Statement', 'statement', 15, 1, 1, 1, NULL, '2022-11-28 10:32:10', '2022-11-28 10:32:10'),
(127, 25, 'Due List', 'Due List', 'due@list', 16, 1, 1, 1, NULL, '2022-11-28 10:34:19', '2022-11-28 10:34:19'),
(128, 25, 'Income & Expense Budget', 'Income & Expense Budget', 'income@expense@budget', 17, 1, 1, 1, NULL, '2022-11-28 11:38:54', '2022-11-28 11:38:54'),
(129, 42, 'Shop Registration List', 'Shop Registration List', 'adminReportShopList', 1, 1, 1, 1, 1, '2021-03-24 03:39:28', '2021-09-02 04:38:24'),
(130, 42, 'Information need', 'Information need', 'informationneedAdminshop', 3, 1, 1, 1, 1, '2021-09-02 04:40:32', '2021-09-03 23:18:45'),
(134, 62, 'New Shop', 'New Shop', 'billingnewshop', 1, 1, 1, 1, NULL, '2021-05-03 04:28:43', '2021-05-03 04:28:43'),
(135, 62, 'Cancel', 'Cancel', 'cancelbillingshop', 2, 1, 1, 1, NULL, '2021-05-03 04:30:03', '2021-05-03 04:30:03'),
(136, 62, 'Pending', 'Pending', 'pendingbillingshop', 3, 1, 1, 1, NULL, '2021-05-03 04:30:58', '2021-05-03 04:30:58'),
(137, 62, 'Delivered', 'Delivered', 'deliveredbillingshop', 4, 1, 1, 1, 1, '2021-05-03 04:31:31', '2023-01-17 04:30:52'),
(138, 73, 'Commission & VAT', 'Commission & VAT', 'hotel@commission@setup', 1, 1, 1, 1, 1, '2023-01-17 05:05:34', '2023-01-17 05:25:38');

-- --------------------------------------------------------

--
-- Table structure for table `asset_brand_entries`
--

CREATE TABLE `asset_brand_entries` (
  `assetBrandEntryId` bigint(20) UNSIGNED NOT NULL,
  `assetBrandName` varchar(191) NOT NULL,
  `assetBrandStatus` int(11) NOT NULL,
  `createBy` int(11) NOT NULL,
  `shopId` int(11) DEFAULT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `asset_brand_entries`
--

INSERT INTO `asset_brand_entries` (`assetBrandEntryId`, `assetBrandName`, `assetBrandStatus`, `createBy`, `shopId`, `updateBy`, `created_at`, `updated_at`) VALUES
(1, 'HP', 1, 2, 1, NULL, '2022-06-17 00:31:29', NULL),
(2, 'Samsung', 1, 2, 1, NULL, '2022-06-21 04:36:37', NULL),
(3, 'Customized', 1, 4, 4, NULL, '2022-06-25 11:32:52', NULL),
(4, 'EPSON', 1, 4, 4, NULL, '2022-06-27 12:00:49', NULL),
(5, 'CANNON', 1, 4, 4, NULL, '2022-06-27 12:01:00', NULL),
(6, 'Mega', 1, 4, 4, NULL, '2022-06-27 12:03:18', NULL),
(7, 'TOSHIBA', 1, 4, 4, NULL, '2022-06-27 12:15:29', NULL),
(8, 'YATO', 1, 4, 4, NULL, '2022-06-27 12:19:11', NULL),
(9, 'Deli', 1, 4, 4, NULL, '2022-06-27 12:19:15', NULL),
(10, 'Good Luck', 1, 4, 4, NULL, '2022-06-27 12:19:28', NULL),
(11, 'INCCO', 1, 4, 4, NULL, '2022-06-27 12:19:37', NULL),
(12, 'Kangaro', 1, 4, 4, NULL, '2022-06-27 12:22:43', NULL),
(13, 'COMIX CHINA', 1, 4, 4, NULL, '2022-06-27 12:23:54', NULL),
(14, 'Jonny', 1, 4, 4, NULL, '2022-06-27 12:25:26', NULL),
(15, 'LG', 1, 4, 4, NULL, '2022-06-27 12:25:30', NULL),
(16, 'Dolphin', 1, 4, 4, NULL, '2022-06-27 12:25:46', NULL),
(17, 'Sony', 1, 4, 4, NULL, '2022-06-27 12:25:57', NULL),
(18, 'Esonic', 1, 4, 4, NULL, '2022-06-27 12:44:22', NULL),
(19, 'Lenevo', 1, 4, 4, NULL, '2022-06-27 12:44:28', NULL),
(20, 'Asus', 1, 4, 4, NULL, '2022-06-27 12:47:45', NULL),
(21, 'WD', 1, 4, 4, NULL, '2022-06-27 12:48:55', NULL),
(22, 'Runner', 1, 4, 4, NULL, '2022-06-27 12:56:53', NULL),
(23, 'TPLINK', 1, 4, 4, NULL, '2022-06-27 13:14:25', NULL),
(24, 'Huawei', 1, 4, 4, NULL, '2022-06-27 13:16:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chart_of_accounts`
--

CREATE TABLE `chart_of_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `headLavel` int(11) NOT NULL,
  `headName` varchar(255) NOT NULL,
  `headCode` varchar(255) NOT NULL,
  `pre_code` varchar(255) NOT NULL,
  `dr_cr` int(11) NOT NULL,
  `headGroupId` int(11) NOT NULL,
  `headGroupType` int(11) NOT NULL,
  `lastCode` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `autoCreate` int(11) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chart_of_accounts`
--

INSERT INTO `chart_of_accounts` (`id`, `headLavel`, `headName`, `headCode`, `pre_code`, `dr_cr`, `headGroupId`, `headGroupType`, `lastCode`, `status`, `position`, `autoCreate`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Asset', '1', '0', 1, 1, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 11:53:58', '2021-11-10 05:19:29', NULL),
(2, 1, 'Equities & Liabilities', '2', '0', 2, 2, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 11:54:34', NULL, NULL),
(3, 1, 'Income', '3', '0', 2, 3, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 11:55:12', NULL, NULL),
(4, 1, 'Cost Of Good Sale', '4', '0', 1, 4, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 11:56:42', NULL, NULL),
(5, 1, 'Expenses', '5', '0', 1, 5, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 11:57:25', NULL, NULL),
(13, 2, 'Non Current Asset', '101', '1', 1, 1, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 12:37:24', NULL, NULL),
(14, 2, 'Current Asset', '102', '1', 1, 1, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 12:37:41', NULL, NULL),
(15, 3, 'Cash and Bank Balance', '10201', '102', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 12:39:46', '2021-06-26 12:40:03', NULL),
(16, 4, 'Cash In Hand', '1020101', '10201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 12:40:31', NULL, NULL),
(19, 4, 'Cash at Bank', '1020102', '10201', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-06-26 12:43:27', '2021-07-01 21:51:31', NULL),
(29, 3, 'Accounts Receivable', '10202', '102', 1, 1, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-01 13:38:52', NULL, NULL),
(30, 4, 'Accounts Receivable Customer', '1020201', '10202', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-01 13:40:00', NULL, NULL),
(31, 5, 'Accounts Receiveable General Customer', '102020101', '1020201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-01 13:44:33', NULL, NULL),
(37, 5, 'Corporate Banking', '102010201', '1020102', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-01 22:04:37', NULL, NULL),
(38, 5, 'Mobile Banking', '102010202', '1020102', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-01 22:11:59', NULL, NULL),
(56, 3, 'Loan & Investment', '10203', '102', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-03 01:15:53', NULL, NULL),
(57, 4, 'Loan', '1020301', '10203', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-03 01:16:16', NULL, NULL),
(58, 5, 'Loan-Personal', '102030101', '1020301', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-03 01:24:23', NULL, NULL),
(59, 5, 'Loan-NGO', '102030102', '1020301', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-03 01:25:27', NULL, NULL),
(60, 5, 'Loan-Bank', '102030103', '1020301', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-03 01:32:45', NULL, NULL),
(70, 2, 'Equity', '201', '2', 2, 2, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-06 09:26:09', NULL, NULL),
(71, 2, 'Liability', '202', '2', 2, 2, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-06 09:26:31', NULL, NULL),
(72, 3, 'Non Current Liability', '20201', '202', 2, 2, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-06 09:27:01', NULL, NULL),
(88, 4, 'Long Term Loan', '2020101', '20201', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-08 11:41:53', NULL, NULL),
(89, 5, 'LTL from Person', '202010101', '2020101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-08 11:47:33', NULL, NULL),
(90, 5, 'LTL from NGO', '202010102', '2020101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-08 11:48:09', NULL, NULL),
(91, 5, 'LTL from Bank', '202010103', '2020101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-08 11:50:59', NULL, NULL),
(131, 2, 'Direct Expense', '501', '5', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-13 23:45:39', '2021-07-14 02:40:42', NULL),
(134, 2, 'Direct Income', '301', '3', 2, 3, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-15 21:07:52', NULL, NULL),
(135, 2, 'Indirect Income', '302', '3', 2, 3, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-15 21:08:27', NULL, NULL),
(152, 3, 'Advance, Deposit & Prepayments', '10204', '102', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-30 05:08:07', NULL, NULL),
(153, 4, 'Advance Payment', '1020401', '10204', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-30 05:09:14', NULL, NULL),
(154, 4, 'Deposit & Security', '1020402', '10204', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-30 05:09:48', NULL, NULL),
(155, 4, 'Prepayment', '1020403', '10204', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-07-30 05:10:42', NULL, NULL),
(192, 3, 'current Liability', '20202', '202', 2, 2, 1, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-11 23:17:35', NULL, NULL),
(193, 4, 'Accounts Payable', '2020201', '20202', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-11 23:19:17', NULL, NULL),
(194, 5, 'Accounts Payable vendor', '202020101', '2020201', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-11 23:20:03', NULL, NULL),
(195, 6, 'Asset Vendor', '20202010101', '202020101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-11 23:20:39', NULL, NULL),
(196, 6, 'Product Vendor', '20202010102', '202020101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-11 23:21:16', NULL, NULL),
(197, 3, 'Tangible Asset', '10101', '101', 1, 1, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-12 01:06:28', NULL, NULL),
(198, 4, 'Furniture & Fixtsre', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 3, NULL, NULL, '2021-08-12 01:50:10', NULL, NULL),
(199, 5, 'Accounts Receiveable Regular Customer', '102020102', '1020201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-19 02:50:00', NULL, NULL),
(200, 5, 'Accounts Receiveable Ecommerce Customer', '102020103', '1020201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-19 02:52:55', NULL, NULL),
(201, 5, 'Accounts Receiveable Wholesale Customer', '102020104', '1020201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-19 02:53:16', NULL, NULL),
(202, 5, 'Accounts Receiveable Special Customer', '102020105', '1020201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-19 02:54:00', NULL, NULL),
(224, 5, 'Accounts Payable Supplier', '202020102', '2020201', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-08-25 06:28:54', NULL, NULL),
(246, 5, 'Deposit', '102040201', '1020402', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-09-25 04:33:22', NULL, NULL),
(247, 5, 'Security', '102040202', '1020402', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-09-25 04:33:43', NULL, NULL),
(249, 4, 'Office Equipment', '1010102', '10101', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 13:07:47', NULL, NULL),
(250, 4, 'Electrical Equipment', '1010103', '10101', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 13:09:37', NULL, NULL),
(251, 4, 'Decoration & Fitings', '1010104', '10101', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 13:10:12', NULL, NULL),
(252, 4, 'Computer & Prephirals', '1010105', '10101', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 13:10:52', NULL, NULL),
(253, 3, 'Stock & Stroe', '10205', '102', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 13:58:59', NULL, NULL),
(263, 5, 'Advance Remuneration', '102040101', '1020401', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:14:38', NULL, NULL),
(264, 5, 'Advance Honorium', '102040102', '1020401', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:17:09', NULL, NULL),
(265, 5, 'Advance Salary & Wages', '102040103', '1020401', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:17:54', NULL, NULL),
(266, 5, 'Advance Expenses', '102040104', '1020401', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:18:37', NULL, NULL),
(267, 5, 'Advance Office Rent', '102040105', '1020401', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:19:09', NULL, NULL),
(268, 5, 'Advance Supplies', '102040106', '1020401', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:20:04', NULL, NULL),
(269, 6, 'Sundry Deposit', '10204020101', '102040201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 14:59:24', NULL, NULL),
(270, 4, 'Investment', '1020302', '10203', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:38:09', NULL, NULL),
(271, 5, 'Investment Bank', '102030201', '1020302', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:38:45', NULL, NULL),
(272, 6, 'Inv-DPS', '10203020101', '102030201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:41:00', NULL, NULL),
(273, 6, 'Inv-FDR', '10203020102', '102030201', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:41:27', NULL, NULL),
(274, 5, 'Plot, Flat & Land', '102030202', '1020302', 1, 1, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:43:03', NULL, NULL),
(275, 6, 'Inv-Plot', '10203020201', '102030202', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:43:40', NULL, NULL),
(276, 6, 'Inv-Flat', '10203020202', '102030202', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:44:29', NULL, NULL),
(277, 6, 'Inv-Land', '10203020203', '102030202', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:45:00', NULL, NULL),
(278, 3, 'Paid up capital', '20101', '201', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:58:57', NULL, NULL),
(279, 4, 'Ordinary Share Account', '2010101', '20101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 15:59:42', NULL, NULL),
(280, 4, 'Preference share capital account', '2010102', '20101', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 16:05:35', NULL, NULL),
(281, 4, 'Liabilities for deposits', '2020102', '20201', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 16:40:06', NULL, NULL),
(282, 5, 'Liability-Agent Deposit', '202010201', '2020102', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 16:41:07', NULL, NULL),
(283, 5, 'Liabilities Foreign Deposit', '202010202', '2020102', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 16:45:27', NULL, NULL),
(284, 4, 'Liabilities for vat', '2020202', '20202', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 16:46:53', NULL, NULL),
(285, 4, 'Liabilities for Income Tax', '2020203', '20202', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 16:47:35', NULL, NULL),
(286, 5, 'Lia Sales Vat', '202020201', '2020202', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 17:03:37', NULL, NULL),
(287, 4, 'Liabilities for Expenses', '2020204', '20202', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:08:52', NULL, NULL),
(288, 5, 'Lia Exp-Remuneration', '202020401', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:09:29', NULL, NULL),
(289, 5, 'Lia Exp-Honorium', '202020402', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:10:05', NULL, NULL),
(290, 5, 'Lia Exp-Salary', '202020403', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:10:49', NULL, NULL),
(291, 5, 'Lia Exp-Wages', '202020404', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:11:13', NULL, NULL),
(292, 5, 'Lia Exp- Festible Bonus', '202020405', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:11:45', NULL, NULL),
(293, 5, 'Lia Exp- Incentive', '202020406', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:12:16', NULL, NULL),
(294, 4, 'Liabilities for commission', '2020205', '20202', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:16:54', NULL, NULL),
(295, 4, 'Preferential Creditors', '2020206', '20202', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:17:27', NULL, NULL),
(296, 5, 'Tax Remueration', '202020601', '2020206', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:19:09', NULL, NULL),
(297, 5, 'Tax Honorium', '202020602', '2020206', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:19:39', NULL, NULL),
(298, 5, 'Tax Salary', '202020603', '2020206', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:20:08', NULL, NULL),
(299, 5, 'Tax Wage', '202020604', '2020206', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:20:30', NULL, NULL),
(300, 5, 'Tax Suplier', '202020605', '2020206', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:21:02', NULL, NULL),
(301, 4, 'Provisions', '2020207', '20202', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:22:58', NULL, NULL),
(302, 4, 'Inter transaction current account', '2020208', '20202', 2, 2, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:23:26', NULL, NULL),
(304, 5, 'Suspenses Accounts', '202020801', '2020208', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:24:44', NULL, NULL),
(305, 5, 'Inter Branch Current Account', '202020802', '2020208', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:25:40', NULL, NULL),
(306, 5, 'Inter Stock project current account', '202020803', '2020208', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-08 19:26:04', NULL, NULL),
(307, 2, 'Revenue', '303', '3', 2, 3, 2, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:04:45', NULL, NULL),
(308, 3, 'Sales Account', '30301', '303', 2, 3, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:05:23', NULL, NULL),
(309, 3, 'Sales Return\r\n', '30302', '303', 2, 3, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:06:56', NULL, NULL),
(310, 3, 'Non operating income', '30303', '303', 2, 3, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:09:32', NULL, NULL),
(311, 4, 'Profit on sales of fixed assets', '3030301', '30303', 2, 3, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:13:16', NULL, NULL),
(312, 4, 'Financial income', '3030302', '30303', 2, 3, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:13:39', NULL, NULL),
(314, 2, 'Direct cost', '401', '4', 1, 4, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-09 02:15:59', NULL, NULL),
(316, 2, 'Indirect Expense', '502', '5', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 07:57:23', NULL, NULL),
(317, 3, 'Product Purchase', '50101', '501', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 07:59:04', NULL, NULL),
(318, 3, 'Direct Labor', '50102', '501', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 07:59:37', NULL, NULL),
(319, 2, 'Indirect Cost', '402', '4', 1, 4, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:08:55', NULL, NULL),
(320, 2, 'Purchase Discount & Return', '403', '4', 1, 4, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:09:22', NULL, NULL),
(321, 3, 'products cost', '40101', '401', 1, 4, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:38:03', NULL, NULL),
(322, 3, 'Direct Labor Cost', '40102', '401', 1, 4, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:43:10', NULL, NULL),
(323, 5, 'Lia Exp-Other', '202020407', '2020204', 2, 2, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 09:32:49', NULL, NULL),
(324, 2, 'Operating Expanes', '503', '5', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:39:21', NULL, NULL),
(325, 2, 'Sales & Marketing Expenses', '504', '5', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:39:47', NULL, NULL),
(326, 2, 'Financial expenses', '505', '5', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:40:13', NULL, NULL),
(327, 3, 'Carrying & Transport', '50401', '504', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:41:32', NULL, NULL),
(328, 3, 'Commission & discount', '50402', '504', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:46:06', NULL, NULL),
(329, 4, 'Inventory-Raw Material & Goods', '1020501', '10205', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-14 13:43:25', NULL, NULL),
(330, 3, 'Adminstrative expenses', '50301', '503', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-16 05:35:00', NULL, NULL),
(331, 4, 'Salary & Wages', '5030101', '50301', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-16 05:36:59', NULL, NULL),
(332, 5, 'Salary', '503010101', '5030101', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-16 05:53:45', NULL, NULL),
(333, 5, 'Wages', '503010102', '5030101', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-16 05:54:08', NULL, NULL),
(339, 3, 'Mobile banking charge', '50501', '505', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-25 13:25:47', NULL, NULL),
(340, 3, 'Bank charge', '50502', '505', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-25 13:26:11', NULL, NULL),
(341, 3, 'Interest Exp', '50503', '505', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-25 13:28:30', NULL, NULL),
(342, 4, 'Loan From Person', '5050301', '50503', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-26 06:19:05', NULL, NULL),
(343, 4, 'Loan From NGO', '5050302', '50503', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-26 06:19:40', NULL, NULL),
(344, 4, 'Loan From Bank', '5050303', '50503', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-26 06:20:03', NULL, NULL),
(345, 3, 'Finencial Income', '30101', '301', 2, 3, 3, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-28 05:02:44', NULL, NULL),
(346, 4, 'Interest Income', '3010101', '30101', 2, 3, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-28 05:03:18', NULL, NULL),
(355, 4, 'Other Asset', '1010106', '10101', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2021-11-01 13:24:35', NULL, NULL),
(357, 2, 'Other Expense', '506', '5', 1, 5, 3, 0, 1, 0, 0, 1, NULL, NULL, NULL, NULL, NULL),
(369, 3, 'Office Expense', '50601', '506', 1, 5, 4, 0, 1, 0, 0, 1, NULL, NULL, '2022-02-03 04:21:38', NULL, NULL),
(370, 5, 'Debit/Credit Card', '102010203', '1020102', 1, 1, 4, 0, 1, 0, 0, 1, NULL, NULL, '2022-02-06 06:31:29', NULL, NULL),
(371, 3, 'other income', '30201', '302', 2, 3, 4, 0, 1, 0, 0, 1, NULL, NULL, '2022-04-13 20:22:31', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chart_of_account_balances`
--

CREATE TABLE `chart_of_account_balances` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `branchId` int(11) NOT NULL,
  `accountHeadCode` varchar(255) NOT NULL,
  `accountCode` varchar(255) NOT NULL,
  `debitAmount` double DEFAULT NULL,
  `creditAmount` double DEFAULT NULL,
  `balanceAmount` double NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleteStatus` tinyint(1) DEFAULT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chart_of_account_balances`
--

INSERT INTO `chart_of_account_balances` (`id`, `shopId`, `branchId`, `accountHeadCode`, `accountCode`, `debitAmount`, `creditAmount`, `balanceAmount`, `status`, `deleteStatus`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `delete_at`) VALUES
(1, 1, 0, '1020101', '102010101', 2652930, -271900, 2381030, 1, NULL, 1, 1, NULL, '2022-06-16 10:46:53', '2022-06-17 02:53:36', NULL),
(2, 3, 0, '1020101', '102010101', 100, NULL, 100, 1, NULL, 3, NULL, NULL, '2022-06-20 15:41:30', NULL, NULL),
(3, 4, 0, '1020101', '102010101', 518500, -300810, 217690, 1, NULL, 4, 4, NULL, '2022-06-25 10:14:24', '2022-06-27 13:46:52', NULL),
(4, 6, 0, '1020101', '102010101', 500000, -106341, 393659, 1, NULL, 6, 6, NULL, '2022-07-07 12:23:22', '2022-07-07 16:13:44', NULL),
(5, 7, 0, '1020101', '102010101', 500509, -2400, 498109, 1, NULL, 7, 7, NULL, '2022-07-17 12:34:45', '2022-07-18 13:00:28', NULL),
(18, 11, 0, '1020101', '102010101', 2400020, -106000, 2294020, 1, NULL, 11, 11, NULL, '2022-08-02 16:48:29', '2022-08-11 13:34:02', NULL),
(19, 11, 0, '102010202', '10201020201', 1000, NULL, 1000, 1, NULL, 11, NULL, NULL, '2022-08-11 13:34:02', NULL, NULL),
(22, 13, 0, '1020101', '102010101', 5402814.88, -1700, 5401114.88, 1, NULL, 13, 13, NULL, '2022-08-14 13:46:55', '2022-09-06 00:27:29', NULL),
(23, 41, 0, '1020101', '102010101', 75800, -610, 75190, 1, NULL, 41, 41, NULL, '2022-09-28 16:13:54', '2022-10-06 20:02:06', NULL),
(24, 42, 0, '1020101', '102010101', 300, -20, 280, 1, NULL, 42, 42, NULL, '2022-09-28 22:12:47', '2022-09-30 18:03:55', NULL),
(25, 42, 0, '102010201', '10201020101', 200, NULL, 200, 1, NULL, 42, NULL, NULL, '2022-09-28 22:14:52', NULL, NULL),
(26, 47, 0, '1020101', '102010101', 2980, -1100, 1880, 1, NULL, 47, 47, NULL, '2022-10-01 16:35:53', '2022-10-06 18:58:10', NULL),
(27, 53, 0, '1020101', '102010101', 500, -400, 100, 1, NULL, 53, 53, NULL, '2022-10-07 01:00:50', '2022-10-07 01:04:06', NULL),
(28, 54, 0, '1020101', '102010101', 90, NULL, 90, 1, NULL, 54, NULL, NULL, '2022-10-07 12:06:56', NULL, NULL),
(29, 58, 0, '1020101', '102010101', 2000, -100, 1900, 1, NULL, 58, 58, NULL, '2022-10-07 22:38:55', '2022-10-09 02:03:43', NULL),
(30, 59, 0, '1020101', '102010101', 200000, -10000, 190000, 1, NULL, 59, 59, NULL, '2022-10-08 20:15:17', '2022-10-08 20:24:19', NULL),
(31, 58, 0, '102010201', '10201020101', 500, NULL, 500, 1, NULL, 58, NULL, NULL, '2022-10-08 21:18:08', NULL, NULL),
(32, 60, 0, '102010201', '10201020101', 500, NULL, 500, 1, NULL, 60, NULL, NULL, '2022-10-08 21:26:38', NULL, NULL),
(33, 60, 0, '102010202', '10201020201', 500, NULL, 500, 1, NULL, 60, NULL, NULL, '2022-10-08 21:27:47', NULL, NULL),
(34, 60, 0, '1020101', '102010101', 1000, -100, 900, 1, NULL, 60, 60, NULL, '2022-10-08 21:29:05', '2022-10-08 21:42:11', NULL),
(35, 61, 0, '1020101', '102010101', 1500, NULL, 1500, 1, NULL, 61, 61, NULL, '2022-10-08 23:34:48', '2022-10-08 23:37:15', NULL),
(36, 61, 0, '102010201', '10201020101', 500, -200, 300, 1, NULL, 61, 61, NULL, '2022-10-08 23:36:38', '2022-10-09 00:13:40', NULL),
(37, 62, 0, '1020101', '102010101', 6500, NULL, 6500, 1, NULL, 62, 62, NULL, '2022-10-09 11:01:02', '2022-10-09 14:06:59', NULL),
(38, 62, 0, '102010201', '10201020101', 500, NULL, 500, 1, NULL, 62, NULL, NULL, '2022-10-09 13:12:31', NULL, NULL),
(39, 62, 0, '102010202', '10201020201', 500, NULL, 500, 1, NULL, 62, NULL, NULL, '2022-10-09 13:13:58', NULL, NULL),
(40, 63, 0, '1020101', '102010101', 1500, -545, 955, 1, NULL, 63, 63, NULL, '2022-10-15 01:32:01', '2022-10-28 07:04:39', NULL),
(41, 63, 0, '102010202', '10201020201', 545, NULL, 545, 1, NULL, 63, 63, NULL, '2022-10-15 01:42:06', '2022-10-15 20:56:14', NULL),
(42, 63, 0, '102010201', '10201020101', 2000, NULL, 2000, 1, NULL, 63, NULL, NULL, '2022-10-15 01:53:05', NULL, NULL),
(43, 63, 0, '102010201', '10201020102', 599, NULL, 599, 1, NULL, 63, NULL, NULL, '2022-10-15 20:57:38', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chart_of_account_group_types`
--

CREATE TABLE `chart_of_account_group_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chart_of_account_group_types`
--

INSERT INTO `chart_of_account_group_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Main Group', NULL, NULL),
(2, 'Group', NULL, NULL),
(3, 'Sub Group', NULL, NULL),
(4, 'Sub Ladger', NULL, NULL),
(5, 'Register', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chart_of_account_registers`
--

CREATE TABLE `chart_of_account_registers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `branchId` int(11) DEFAULT NULL,
  `headLavel` int(11) NOT NULL,
  `headName` varchar(255) NOT NULL,
  `headCode` varchar(255) NOT NULL,
  `pre_code` varchar(255) NOT NULL,
  `dr_cr` int(11) NOT NULL,
  `headGroupId` int(11) NOT NULL,
  `headGroupType` int(11) NOT NULL,
  `lastCode` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `autoCreate` int(11) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chart_of_account_registers`
--

INSERT INTO `chart_of_account_registers` (`id`, `shopId`, `branchId`, `headLavel`, `headName`, `headCode`, `pre_code`, `dr_cr`, `headGroupId`, `headGroupType`, `lastCode`, `status`, `position`, `autoCreate`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 0, NULL, 5, 'General Cash', '102010101', '1020101', 1, 1, 5, 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, '2021-08-29 09:49:31'),
(110, 0, NULL, 4, 'Carriage Inward', '5010201', '50102', 1, 5, 5, 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, '2021-08-29 09:49:31'),
(111, 0, NULL, 4, 'Others purchase cost', '5010202', '50102', 1, 5, 5, 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, '2021-08-29 09:49:31'),
(112, 0, NULL, 4, 'Damage & warranty exp', '5010203', '50102', 1, 5, 5, 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, '2021-08-29 09:49:31'),
(115, 0, NULL, 4, 'Carriage Inward', '4010201', '40102', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:43:54', NULL, NULL),
(116, 0, NULL, 4, 'Others Purchase Cost', '4010202', '40102', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:47:21', NULL, NULL),
(117, 0, NULL, 4, 'Damage & Warranty', '4010203', '40102', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:48:39', NULL, NULL),
(118, 0, NULL, 3, 'Transportation & Carring Exp.', '40201', '402', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:49:24', NULL, NULL),
(119, 0, NULL, 3, 'Travelling Expenses', '40202', '402', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:49:57', NULL, NULL),
(120, 0, NULL, 3, 'Purchase Discount', '40301', '403', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:50:43', NULL, NULL),
(121, 0, NULL, 3, 'Purchase Return', '40302', '403', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:51:14', NULL, NULL),
(122, 0, NULL, 4, 'Product Purchase Cost', '5010101', '50101', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 08:54:42', NULL, NULL),
(123, 0, NULL, 6, 'Lia-exp- Carriage inward', '20202040701', '202020407', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 09:33:45', NULL, NULL),
(124, 0, NULL, 6, 'Lia-exp- Others purchase Cost', '20202040702', '202020407', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 09:34:47', NULL, NULL),
(125, 0, NULL, 6, 'Lia-exp-purchase Discount', '20202040703', '202020407', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-10 09:35:37', NULL, NULL),
(126, 0, NULL, 4, 'labor exp', '5040101', '50401', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:44:41', NULL, NULL),
(127, 0, NULL, 4, 'Transport exp', '5040102', '50401', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:45:14', NULL, NULL),
(128, 0, NULL, 4, 'Commission exp', '5040201', '50402', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:46:27', NULL, NULL),
(129, 0, NULL, 4, 'Discounts exp', '5040202', '50402', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-13 06:46:47', NULL, NULL),
(130, 0, NULL, 5, 'Inventory-Raw Material', '102050101', '1020501', 1, 1, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-14 13:44:24', NULL, NULL),
(131, 0, NULL, 5, 'Inventory-WIP', '102050102', '1020501', 1, 1, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-14 13:46:31', NULL, NULL),
(132, 0, NULL, 5, 'Inventory-Finish Goods', '102050103', '1020501', 1, 1, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-14 13:47:10', NULL, NULL),
(133, 0, NULL, 5, 'Prov-Damage & Warranty', '202020701', '2020207', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-15 06:36:23', NULL, NULL),
(137, 0, NULL, 4, 'Sales Product', '3030101', '30301', 2, 3, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-17 04:53:17', NULL, NULL),
(138, 0, NULL, 4, 'Sales Other', '3030102', '30301', 2, 3, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-17 04:53:44', NULL, NULL),
(139, 0, NULL, 4, 'Product Cost', '4010101', '40101', 1, 4, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-10-17 04:57:48', NULL, NULL),
(262, 0, NULL, 5, 'All Asset', '101010601', '1010106', 1, 1, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-11-01 13:25:36', NULL, NULL),
(288, 0, NULL, 5, 'Owner\'s Share', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-11-14 07:13:44', NULL, NULL),
(303, 0, NULL, 5, 'Opening Inventory Account', '901010102', '9010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2021-11-14 07:13:44', NULL, NULL),
(850, 1, NULL, 6, 'Loan-Personal-MD. Shamsul Haque ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 09:56:28', NULL, NULL),
(851, 1, NULL, 5, 'Loan-Personal-MD. Shamsul Haque ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 09:56:28', NULL, NULL),
(852, 1, NULL, 6, 'Loan-Personal-Nurkorim Vai ', '20201010102', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 10:52:45', NULL, NULL),
(853, 1, NULL, 5, 'Loan-Personal-Nurkorim Vai ', '505030102', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 10:52:45', NULL, NULL),
(854, 1, NULL, 6, 'Loan-Personal-Mohammad Main Uddin ', '20201010103', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 11:05:34', NULL, NULL),
(855, 1, NULL, 5, 'Loan-Personal-Mohammad Main Uddin ', '505030103', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 11:05:34', NULL, NULL),
(856, 1, NULL, 6, 'Loan-Personal-Abdullah Al Nahid ', '20201010104', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:00:46', NULL, NULL),
(857, 1, NULL, 5, 'Loan-Personal-Abdullah Al Nahid ', '505030104', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:00:46', NULL, NULL),
(858, 1, NULL, 6, 'Loan-Personal-Ziaul Haque ', '20201010105', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:01:54', NULL, NULL),
(859, 1, NULL, 5, 'Loan-Personal-Ziaul Haque ', '505030105', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:01:54', NULL, NULL),
(860, 1, NULL, 6, 'Loan-Personal-Koli Apu ', '20201010106', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:03:18', NULL, NULL),
(861, 1, NULL, 5, 'Loan-Personal-Koli Apu ', '505030106', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:03:18', NULL, NULL),
(862, 1, NULL, 6, 'Loan-Personal-Nasir Hossain( Uttara) ', '20201010107', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:04:17', NULL, NULL),
(863, 1, NULL, 5, 'Loan-Personal-Nasir Hossain( Uttara) ', '505030107', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:04:17', NULL, NULL),
(864, 1, NULL, 6, 'Loan-Personal-Senbag Ric ', '20201010108', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:05:11', NULL, NULL),
(865, 1, NULL, 5, 'Loan-Personal-Senbag Ric ', '505030108', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:05:11', NULL, NULL),
(866, 1, NULL, 6, 'Loan-NGO-একটি বাডি একটি খামার () (Senbag)', '20201010201', '202010102', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:06:46', NULL, NULL),
(867, 1, NULL, 5, 'Loan-NGO-একটি বাডি একটি খামার () (Senbag)', '505030201', '5050302', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:06:46', NULL, NULL),
(868, 1, NULL, 6, 'Loan-Personal-Kohinur Akter ', '20201010109', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:09:03', NULL, NULL),
(869, 1, NULL, 5, 'Loan-Personal-Kohinur Akter ', '505030109', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:09:03', NULL, NULL),
(870, 1, NULL, 6, 'Loan-Personal-Abdul Gani Arif ', '20201010110', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:10:06', NULL, NULL),
(871, 1, NULL, 5, 'Loan-Personal-Abdul Gani Arif ', '505030110', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:10:06', NULL, NULL),
(872, 1, NULL, 6, 'Loan-Personal-Josnara Akter ', '20201010111', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:17:01', NULL, NULL),
(873, 1, NULL, 5, 'Loan-Personal-Josnara Akter ', '505030111', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:17:01', NULL, NULL),
(874, 1, NULL, 6, 'Loan-Personal-F.S Cosmetics ', '20201010112', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:19:33', NULL, NULL),
(875, 1, NULL, 5, 'Loan-Personal-F.S Cosmetics ', '505030112', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:19:33', NULL, NULL),
(876, 1, NULL, 6, 'Loan-Personal-Rabeya Enter Prise ', '20201010113', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:20:37', NULL, NULL),
(877, 1, NULL, 5, 'Loan-Personal-Rabeya Enter Prise ', '505030113', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:20:37', NULL, NULL),
(878, 1, NULL, 6, 'Loan-Personal-Nosad Sir ', '20201010114', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:21:45', NULL, NULL),
(879, 1, NULL, 5, 'Loan-Personal-Nosad Sir ', '505030114', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:21:45', NULL, NULL),
(880, 1, NULL, 6, 'Loan-Personal-Ahsan ', '20201010115', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:22:42', NULL, NULL),
(881, 1, NULL, 5, 'Loan-Personal-Ahsan ', '505030115', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:22:42', NULL, NULL),
(882, 1, NULL, 6, 'Loan-Personal-Maolana Ismail ', '20201010116', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:26:54', NULL, NULL),
(883, 1, NULL, 5, 'Loan-Personal-Maolana Ismail ', '505030116', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:26:54', NULL, NULL),
(884, 1, NULL, 6, 'Loan-Personal-Mahbubul Haque ', '20201010117', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:28:05', NULL, NULL),
(885, 1, NULL, 5, 'Loan-Personal-Mahbubul Haque ', '505030117', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:28:05', NULL, NULL),
(886, 1, NULL, 6, 'Loan-Personal-Jasmin Ara Begum ', '20201010118', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:29:14', NULL, NULL),
(887, 1, NULL, 5, 'Loan-Personal-Jasmin Ara Begum ', '505030118', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:29:14', NULL, NULL),
(888, 1, NULL, 6, 'Loan-Personal-Sumaiya ', '20201010119', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:41:01', NULL, NULL),
(889, 1, NULL, 5, 'Loan-Personal-Sumaiya ', '505030119', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:41:01', NULL, NULL),
(890, 1, NULL, 6, 'Loan-Personal-Mohi Uddin Mister ', '20201010120', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:41:42', NULL, NULL),
(891, 1, NULL, 5, 'Loan-Personal-Mohi Uddin Mister ', '505030120', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:41:43', NULL, NULL),
(892, 1, NULL, 6, 'Loan-Personal-Oagi Ullsh Shamim ', '20201010121', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:55:07', NULL, NULL),
(893, 1, NULL, 5, 'Loan-Personal-Oagi Ullsh Shamim ', '505030121', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:55:07', NULL, NULL),
(894, 1, NULL, 6, 'Loan-Personal-Mamun Mahi ', '20201010122', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:59:18', NULL, NULL),
(895, 1, NULL, 5, 'Loan-Personal-Mamun Mahi ', '505030122', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 12:59:18', NULL, NULL),
(896, 1, NULL, 6, 'Loan-Personal-hiron ', '20201010123', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 13:04:44', NULL, NULL),
(897, 1, NULL, 5, 'Loan-Personal-hiron ', '505030123', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 13:04:44', NULL, NULL),
(898, 1, NULL, 6, 'Loan-Personal-Riaz Uddin ', '20201010124', '202010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 13:05:45', NULL, NULL),
(899, 1, NULL, 5, 'Loan-Personal-Riaz Uddin ', '505030124', '5050301', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-16 13:05:45', NULL, NULL),
(900, 1, NULL, 4, 'Ceiling Pen', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:28:33', NULL, NULL),
(901, 1, NULL, 4, 'AC', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:28:45', NULL, NULL),
(902, 1, NULL, 4, 'চেয়ার', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:29:30', NULL, NULL),
(903, 1, NULL, 4, 'টেবিল', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:29:37', NULL, NULL),
(904, 1, NULL, 4, 'চোপা', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:29:53', NULL, NULL),
(905, 1, NULL, 4, 'লেপ্টপ', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:30:13', NULL, NULL),
(906, 1, NULL, 4, 'ডেস্কটপ', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:30:24', NULL, NULL),
(907, 1, NULL, 4, 'মনিটর', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:30:44', NULL, NULL),
(908, 1, NULL, 7, 'Proven Computer (1)', '2020201010101', '20202010101', 2, 2, 5, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-17 00:35:26', NULL, NULL),
(909, 1, NULL, 4, 'টিকেটিং সফট্ওয়্যার (ParkLin)', '3020101', '30201', 2, 3, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-17 02:32:11', NULL, NULL),
(910, 1, NULL, 6, 'Office Rent (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-17 02:43:51', NULL, NULL),
(911, 1, NULL, 4, 'Office Rent (খোরশেদ আলম (Haque Manjil))', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-06-17 02:43:51', NULL, NULL),
(912, 3, NULL, 6, 'SAI (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 3, NULL, NULL, '2022-06-20 15:37:25', NULL, NULL),
(913, 3, NULL, 6, 'nazmul', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 3, NULL, NULL, '2022-06-20 15:40:40', NULL, NULL),
(914, 1, NULL, 4, 'Desktop', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 2, NULL, NULL, '2022-06-21 04:37:52', NULL, NULL),
(915, 4, NULL, 6, 'Loan-Personal-Abu Bakar ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:13:33', NULL, NULL),
(916, 4, NULL, 5, 'Loan-Personal-Abu Bakar ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:13:33', NULL, NULL),
(917, 4, NULL, 6, 'Loan-Personal-Kazi Fazlul Haque ', '20201010102', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:21:16', NULL, NULL),
(918, 4, NULL, 5, 'Loan-Personal-Kazi Fazlul Haque ', '505030102', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:21:16', NULL, NULL),
(919, 4, NULL, 6, 'Loan-Personal-Rasel Patowary ', '20201010103', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:22:16', NULL, NULL),
(920, 4, NULL, 5, 'Loan-Personal-Rasel Patowary ', '505030103', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:22:16', NULL, NULL),
(921, 4, NULL, 6, 'Loan-Personal-Saifuddin (FRNF-MU) ', '20201010104', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:23:12', NULL, NULL),
(922, 4, NULL, 5, 'Loan-Personal-Saifuddin (FRNF-MU) ', '505030104', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:23:12', NULL, NULL),
(923, 4, NULL, 6, 'Loan-Personal-Rostum Ali (Central Hardaware) ', '20201010105', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:27:37', NULL, NULL),
(924, 4, NULL, 5, 'Loan-Personal-Rostum Ali (Central Hardaware) ', '505030105', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:27:37', NULL, NULL),
(925, 4, NULL, 6, 'Loan-Personal-Hafizur Rahman ', '20201010106', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:29:21', NULL, NULL),
(926, 4, NULL, 5, 'Loan-Personal-Hafizur Rahman ', '505030106', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:29:21', NULL, NULL),
(927, 4, NULL, 6, 'Loan-Personal-Tuhin Vai ', '20201010107', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:30:37', NULL, NULL),
(928, 4, NULL, 5, 'Loan-Personal-Tuhin Vai ', '505030107', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:30:37', NULL, NULL),
(929, 4, NULL, 6, 'Loan-Personal-Faysal Ahmed ', '20201010108', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:35:33', NULL, NULL),
(930, 4, NULL, 5, 'Loan-Personal-Faysal Ahmed ', '505030108', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:35:33', NULL, NULL),
(931, 4, NULL, 6, 'Loan-Personal-Mainuddin ', '20201010109', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:39:50', NULL, NULL),
(932, 4, NULL, 5, 'Loan-Personal-Mainuddin ', '505030109', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:39:50', NULL, NULL),
(933, 4, NULL, 6, 'Loan-Personal-Subuj Vai, (Al-falah) ', '20201010110', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:44:07', NULL, NULL),
(934, 4, NULL, 5, 'Loan-Personal-Subuj Vai, (Al-falah) ', '505030110', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:44:07', NULL, NULL),
(935, 4, NULL, 6, 'Shop Rent (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:54:06', NULL, NULL),
(936, 4, NULL, 4, 'Shop Rent (Mamun Vai (Shop Owner))', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:54:06', NULL, NULL),
(937, 4, NULL, 4, 'Computer', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 10:59:10', NULL, NULL),
(938, 4, NULL, 4, 'Photocopier Machine', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:00:41', NULL, NULL),
(939, 4, NULL, 4, 'Furniture', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:01:07', NULL, NULL),
(940, 4, NULL, 4, 'Chair', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:01:20', NULL, NULL),
(941, 4, NULL, 4, 'Electric Equipment', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:04:34', NULL, NULL),
(942, 4, NULL, 4, 'Cables, Socket & Etc.', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:06:21', NULL, NULL),
(943, 4, NULL, 4, 'Printer', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:07:17', NULL, NULL),
(944, 4, NULL, 4, 'Laminating Machine', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:09:21', NULL, NULL),
(945, 4, NULL, 4, 'Office Stationery', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:10:27', NULL, NULL),
(946, 4, NULL, 7, 'Cash-Supplier (1)', '2020201010101', '20202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:21:08', NULL, NULL),
(947, 4, NULL, 4, 'Computer Accessories', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-25 11:58:29', NULL, NULL),
(948, 4, NULL, 6, 'Loan-Personal-Khairun Nesa ', '20201010111', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:24:24', NULL, NULL),
(949, 4, NULL, 5, 'Loan-Personal-Khairun Nesa ', '505030111', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:24:24', NULL, NULL),
(950, 4, NULL, 6, 'Loan-Personal-Patowari Foundation ', '20201010112', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:25:30', NULL, NULL),
(951, 4, NULL, 5, 'Loan-Personal-Patowari Foundation ', '505030112', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:25:30', NULL, NULL),
(952, 4, NULL, 6, 'Loan-Personal-Baijid Vai ', '20201010113', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:26:35', NULL, NULL),
(953, 4, NULL, 5, 'Loan-Personal-Baijid Vai ', '505030113', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:26:35', NULL, NULL),
(954, 4, NULL, 6, 'Loan-Personal-Younus Vai ', '20201010114', '202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:29:41', NULL, NULL),
(955, 4, NULL, 5, 'Loan-Personal-Younus Vai ', '505030114', '5050301', 1, 5, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 10:29:41', NULL, NULL),
(956, 4, NULL, 4, 'Transport & Vehicle', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 11:15:22', NULL, NULL),
(957, 4, NULL, 4, 'Hardware & Tools Equipment', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 11:22:24', NULL, NULL),
(958, 4, NULL, 4, 'Camera Support Tools', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 11:23:18', NULL, NULL),
(959, 4, NULL, 4, 'Networking Tools', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 11:30:26', NULL, NULL),
(960, 4, NULL, 4, 'Mobile', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 11:34:23', NULL, NULL),
(961, 4, NULL, 7, 'MD KAMAL HOSSIN (2)', '2020201010102', '20202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 12:56:27', NULL, NULL),
(962, 4, NULL, 4, 'Office Accesories', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 13:22:18', NULL, NULL),
(963, 4, NULL, 4, 'Software', '1010101', '10101', 1, 1, 3, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 13:44:10', NULL, NULL),
(964, 4, NULL, 7, 'DoofazIT (3)', '2020201010103', '20202010101', 2, 2, 5, 0, 1, 0, 0, 4, NULL, NULL, '2022-06-27 13:45:51', NULL, NULL),
(965, 5, NULL, 6, 'MR COSMETICS (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 5, NULL, NULL, '2022-06-27 17:49:34', NULL, NULL),
(966, 6, NULL, 6, 'HOQUE (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-07 12:14:57', NULL, NULL),
(967, 6, NULL, 6, 'RANI FOOD INDUSTRIES LIMITED (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-07 12:33:10', NULL, NULL),
(968, 6, NULL, 6, 'Mr  Monir', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-07 16:32:38', NULL, NULL),
(969, 6, NULL, 6, 'Bashar', '102020102002', '102020102', 1, 1, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-07 16:32:57', NULL, NULL),
(970, 7, NULL, 6, 'ABL-babul(1234)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-17 12:33:36', NULL, NULL),
(971, 7, NULL, 6, 'RFL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-17 12:39:08', NULL, NULL),
(972, 7, NULL, 6, 'Loan-Personal-Nazmul ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-17 13:04:42', NULL, NULL),
(973, 7, NULL, 5, 'Loan-Personal-Nazmul ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-17 13:04:42', NULL, NULL),
(974, 6, NULL, 6, 'Loan-Personal-Saiful vai ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-17 13:05:09', NULL, NULL),
(975, 6, NULL, 5, 'Loan-Personal-Saiful vai ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-17 13:05:09', NULL, NULL),
(976, 7, NULL, 6, 'COMPUTER SOURCE (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-18 11:13:29', NULL, NULL),
(977, 6, NULL, 6, 'RS DISTRIBUTION (3)', '20202010203', '202020102', 2, 2, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-18 11:58:44', NULL, NULL),
(978, 6, NULL, 6, 'RS DISTRIBUTION (4)', '20202010204', '202020102', 2, 2, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-18 12:09:30', NULL, NULL),
(979, 7, NULL, 6, 'AKIJ (3)', '20202010203', '202020102', 2, 2, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-18 12:13:25', NULL, NULL),
(980, 7, NULL, 6, 'saifl', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-18 12:36:37', NULL, NULL),
(981, 7, NULL, 6, 'Guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-18 12:50:46', NULL, NULL),
(982, 7, NULL, 6, 'FFD (4)', '20202010204', '202020102', 2, 2, 5, 0, 1, 0, 0, 7, NULL, NULL, '2022-07-18 13:18:56', NULL, NULL),
(983, 11, NULL, 6, 'Loan-Personal-Father ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-18 14:10:11', NULL, NULL),
(984, 11, NULL, 5, 'Loan-Personal-Father ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-18 14:10:11', NULL, NULL),
(985, 11, NULL, 6, 'MR. R (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-18 22:02:27', NULL, NULL),
(986, 11, NULL, 6, 'MR. X (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-18 22:05:33', NULL, NULL),
(987, 11, NULL, 6, 'MR. Y (3)', '20202010203', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-18 22:06:22', NULL, NULL),
(988, 12, NULL, 6, 'TOP UP POIN (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 12, NULL, NULL, '2022-07-18 22:18:39', NULL, NULL),
(989, 13, NULL, 6, 'বাবুল সাহেব (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-19 01:40:13', NULL, NULL),
(990, 13, NULL, 6, 'Mandol', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-19 01:42:50', NULL, NULL),
(991, 13, NULL, 6, 'guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-19 01:44:27', NULL, NULL),
(992, 13, NULL, 6, 'Regular', '102020102002', '102020102', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-19 09:15:37', NULL, NULL),
(993, 10, NULL, 6, 'RFL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 10, NULL, NULL, '2022-07-19 10:53:18', NULL, NULL),
(994, 6, NULL, 6, 'BOSHUNDHARA (5)', '20202010205', '202020102', 2, 2, 5, 0, 1, 0, 0, 6, NULL, NULL, '2022-07-19 11:06:50', NULL, NULL),
(995, 10, NULL, 6, 'ACI (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 10, NULL, NULL, '2022-07-19 11:07:12', NULL, NULL),
(996, 13, NULL, 6, 'ALAMIN (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-19 11:55:41', NULL, NULL),
(997, 13, NULL, 6, 'BOSHUNDHARA (3)', '20202010203', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-19 16:59:12', NULL, NULL),
(998, 11, NULL, 6, 'MR. Z (4)', '20202010204', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-19 17:05:05', NULL, NULL),
(999, 11, NULL, 6, 'Rohim', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-19 17:09:35', NULL, NULL),
(1000, 11, NULL, 6, 'MR. S (5)', '20202010205', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:15:12', NULL, NULL),
(1001, 11, NULL, 4, 'Selling (Brand)', '3020101', '30201', 2, 3, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:29:37', NULL, NULL),
(1002, 11, NULL, 6, 'Shoping (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:31:12', NULL, NULL),
(1003, 11, NULL, 4, 'Shoping (Robi)', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:31:12', NULL, NULL),
(1004, 11, NULL, 6, 'Loan-NGO-Brac (Banasri)', '20201010201', '202010102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:32:51', NULL, NULL),
(1005, 11, NULL, 5, 'Loan-NGO-Brac (Banasri)', '505030201', '5050302', 1, 5, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:32:51', NULL, NULL),
(1006, 11, NULL, 6, 'Loan-Personal-Ritu', '10203010101', '102030101', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:37:50', NULL, NULL),
(1007, 11, NULL, 6, 'Loan-Personal-Ritu', '301010101', '3010101', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:37:50', NULL, NULL),
(1008, 11, NULL, 6, 'Bkash-017777(Personal)', '10201020201', '102010202', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 08:45:32', NULL, NULL),
(1009, 13, NULL, 6, 'atik', '102020102003', '102020102', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:06:47', NULL, NULL),
(1010, 13, NULL, 6, 'Bkash-01812454358(Personal)', '10201020201', '102010202', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:15:12', NULL, NULL),
(1011, 13, NULL, 6, 'IIBL-efer(344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:31:14', NULL, NULL),
(1012, 13, NULL, 6, 'Loan-Personal-atik ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:32:05', NULL, NULL),
(1013, 13, NULL, 5, 'Loan-Personal-atik ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:32:05', NULL, NULL),
(1014, 13, NULL, 6, 'Loan-Personal-akash', '10203010101', '102030101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:42:48', NULL, NULL),
(1015, 13, NULL, 6, 'Loan-Personal-akash', '301010101', '3010101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:42:48', NULL, NULL),
(1016, 13, NULL, 6, 'office rent (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:50:40', NULL, NULL),
(1017, 13, NULL, 4, 'office rent (office)', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 10:50:40', NULL, NULL),
(1018, 13, NULL, 6, 'অফিস নাস্তা (Security Money)', '10204020202', '102040202', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 11:25:18', NULL, NULL),
(1019, 13, NULL, 4, 'অফিস নাস্তা (office)', '5060102', '50601', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 11:25:18', NULL, NULL),
(1020, 13, NULL, 6, 'transport (Security Money)', '10204020203', '102040202', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 11:27:09', NULL, NULL),
(1021, 13, NULL, 4, 'transport (office)', '5060103', '50601', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 11:27:09', NULL, NULL),
(1022, 13, NULL, 6, 'SQ (4)', '20202010204', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-20 12:22:16', NULL, NULL),
(1023, 15, NULL, 6, 'sa', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 14:29:23', NULL, NULL),
(1024, 15, NULL, 6, 'man', '102020102002', '102020102', 1, 1, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 14:31:08', NULL, NULL),
(1025, 15, NULL, 6, 'ACI (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:03:12', NULL, NULL),
(1026, 15, NULL, 6, 'sakil', '102020102003', '102020102', 1, 1, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:04:56', NULL, NULL),
(1027, 15, NULL, 6, 'PRAN (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:07:13', NULL, NULL),
(1028, 15, NULL, 6, 'Bkash-01812454358(Agent)', '10201020201', '102010202', 1, 1, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:08:54', NULL, NULL),
(1029, 15, NULL, 6, 'Loan-Personal-Brack Bokhtar Munshi ', '20201010101', '202010101', 2, 2, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:17:58', NULL, NULL),
(1030, 15, NULL, 5, 'Loan-Personal-Brack Bokhtar Munshi ', '505030101', '5050301', 1, 5, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:17:58', NULL, NULL),
(1031, 15, NULL, 6, 'Loan-Bank-dbbl (banasree)', '20201010301', '202010103', 2, 2, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:18:54', NULL, NULL),
(1032, 15, NULL, 5, 'Loan-Bank-dbbl (banasree)', '505030301', '5050303', 1, 5, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:18:54', NULL, NULL),
(1033, 15, NULL, 6, 'guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 15, NULL, NULL, '2022-07-20 15:39:00', NULL, NULL),
(1034, 11, NULL, 7, 'alhamdulillah (1)', '2020201010101', '20202010101', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-20 19:44:58', NULL, NULL),
(1035, 11, NULL, 6, 'MR. XYZ (6)', '20202010206', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-21 08:25:04', NULL, NULL),
(1036, 13, NULL, 7, 'a (1)', '2020201010101', '20202010101', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:23:31', NULL, NULL),
(1037, 13, NULL, 6, 'Loan-Bank-CITY BANK (BANASREE SHAKA)', '20201010301', '202010103', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:42:58', NULL, NULL),
(1038, 13, NULL, 5, 'Loan-Bank-CITY BANK (BANASREE SHAKA)', '505030301', '5050303', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:42:58', NULL, NULL),
(1039, 13, NULL, 6, 'Loan-NGO-ALIF NGO (BANASREE SHAKA)', '20201010201', '202010102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:43:55', NULL, NULL),
(1040, 13, NULL, 5, 'Loan-NGO-ALIF NGO (BANASREE SHAKA)', '505030201', '5050302', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:43:55', NULL, NULL),
(1041, 13, NULL, 6, 'Loan-Personal-CITY BANK', '10203010102', '102030101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:55:09', NULL, NULL),
(1042, 13, NULL, 6, 'Loan-Personal-CITY BANK', '301010102', '3010101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 11:55:10', NULL, NULL),
(1043, 13, NULL, 6, 'Loan-Personal-CITY BANK', '10203010103', '102030101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:06:53', NULL, NULL),
(1044, 13, NULL, 6, 'Loan-Personal-CITY BANK', '301010103', '3010101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:06:53', NULL, NULL),
(1045, 13, NULL, 6, 'Loan-Personal-atik ', '20201010102', '202010101', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:10:13', NULL, NULL),
(1046, 13, NULL, 5, 'Loan-Personal-atik ', '505030102', '5050301', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:10:13', NULL, NULL),
(1047, 13, NULL, 6, 'Loan-Bank-dbbl (dhaka)', '20201010302', '202010103', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:10:36', NULL, NULL),
(1048, 13, NULL, 5, 'Loan-Bank-dbbl (dhaka)', '505030302', '5050303', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:10:36', NULL, NULL),
(1049, 13, NULL, 6, 'Loan-Bank-CITY BANK (BANASREE SHAKA)', '20201010303', '202010103', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:34:51', NULL, NULL),
(1050, 13, NULL, 5, 'Loan-Bank-CITY BANK (BANASREE SHAKA)', '505030303', '5050303', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:34:52', NULL, NULL),
(1051, 13, NULL, 7, 'MOON (2)', '2020201010102', '20202010101', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-21 12:55:32', NULL, NULL),
(1052, 11, NULL, 6, 'Loan-Personal-nazrul islam ', '20201010102', '202010101', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-22 09:55:43', NULL, NULL),
(1053, 11, NULL, 5, 'Loan-Personal-nazrul islam ', '505030102', '5050301', 1, 5, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-22 09:55:43', NULL, NULL),
(1054, 11, NULL, 6, 'ACME LABRATORIES (7)', '20202010207', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-22 10:06:22', NULL, NULL),
(1055, 11, NULL, 6, 'MOON (8)', '20202010208', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-22 10:33:14', NULL, NULL),
(1056, 11, NULL, 6, 'Loan-Personal-moon200', '10203010102', '102030101', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-22 12:38:22', NULL, NULL),
(1057, 11, NULL, 6, 'Loan-Personal-moon200', '301010102', '3010101', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-22 12:38:22', NULL, NULL),
(1058, 11, NULL, 6, 'SHAKIL RAZVE (9)', '20202010209', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-23 10:05:24', NULL, NULL),
(1059, 13, NULL, 6, 'BOSHUNDARA (5)', '20202010205', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-23 19:44:53', NULL, NULL),
(1060, 13, NULL, 6, 'nazmul', '102020102004', '102020102', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-23 19:49:11', NULL, NULL),
(1061, 13, NULL, 6, 'mototcycle (Security Money)', '10204020204', '102040202', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-23 20:46:56', NULL, NULL),
(1062, 13, NULL, 4, 'mototcycle (office)', '5060104', '50601', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-23 20:46:56', NULL, NULL),
(1063, 13, NULL, 6, 'Loan-NGO-brac (ss)', '20201010202', '202010102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-23 20:50:36', NULL, NULL),
(1064, 13, NULL, 5, 'Loan-NGO-brac (ss)', '505030202', '5050302', 1, 5, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-23 20:50:36', NULL, NULL),
(1065, 11, NULL, 6, 'WATON ELECTRONIC (10)', '20202010210', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-25 11:08:55', NULL, NULL),
(1066, 11, NULL, 6, 'Samrat', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-25 11:32:09', NULL, NULL),
(1067, 13, NULL, 6, 'FSDF (6)', '20202010206', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-25 16:19:51', NULL, NULL),
(1068, 13, NULL, 6, 'MITHUN (7)', '20202010207', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-25 16:22:29', NULL, NULL),
(1069, 13, NULL, 6, 'ARISTRO (8)', '20202010208', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-26 16:33:06', NULL, NULL),
(1070, 11, NULL, 6, 'Mr. S', '102020102002', '102020102', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-27 11:38:57', NULL, NULL),
(1071, 11, NULL, 6, 'Mr. Due', '102020102003', '102020102', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-07-27 12:16:38', NULL, NULL),
(1072, 13, NULL, 6, 'MOON (9)', '20202010209', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-07-27 18:15:51', NULL, NULL),
(1080, 11, NULL, 6, 'SUJON (11)', '20202010211', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-08-02 12:42:15', NULL, NULL),
(1081, 11, NULL, 6, 'unknown', '102020101002', '102020101', 1, 1, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-08-02 16:46:19', NULL, NULL),
(1082, 11, NULL, 6, 'RAKIB TRADERS (12)', '20202010212', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-08-02 17:21:02', NULL, NULL),
(1083, 11, NULL, 6, 'PRAN-RFL LIMITED (13)', '20202010213', '202020102', 2, 2, 5, 0, 1, 0, 0, 11, NULL, NULL, '2022-08-11 13:10:42', NULL, NULL),
(1091, 13, NULL, 6, 'INDIA (10)', '20202010210', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-08-14 13:29:50', NULL, NULL),
(1092, 13, NULL, 6, 'GREEN GURD (11)', '20202010211', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-08-15 11:09:30', NULL, NULL),
(1093, 13, NULL, 6, 'nazmul', '102020101002', '102020101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-08-15 11:17:49', NULL, NULL),
(1095, 22, NULL, 6, 'NAZMUL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 22, NULL, NULL, '2022-08-26 22:28:59', NULL, NULL),
(1096, 13, NULL, 6, 'NURUL (12)', '20202010212', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-08-30 01:22:23', NULL, NULL),
(1097, 13, NULL, 6, 'NAJM (13)', '20202010213', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-08-30 15:54:23', NULL, NULL),
(1098, 13, NULL, 6, 'NAZMUL (14)', '20202010214', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-09-04 23:29:45', NULL, NULL),
(1099, 13, NULL, 6, 'jesmin', '102020101003', '102020101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-09-04 23:32:29', NULL, NULL),
(1100, 13, NULL, 6, 'ARIF GHANI (15)', '20202010215', '202020102', 2, 2, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-09-05 00:42:15', NULL, NULL),
(1101, 13, NULL, 6, 'fara', '102020101004', '102020101', 1, 1, 5, 0, 1, 0, 0, 13, NULL, NULL, '2022-09-05 00:45:57', NULL, NULL),
(1102, 24, NULL, 6, 'লিমেরিক ডিস্ট্রিবিউশন লিঃ (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 24, NULL, NULL, '2022-09-05 20:41:08', NULL, NULL),
(1103, 40, NULL, 6, 'AJ METAL JALAL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 40, NULL, NULL, '2022-09-28 08:59:42', NULL, NULL),
(1104, 40, NULL, 6, 'RAJON METAL (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 40, NULL, NULL, '2022-09-28 09:00:26', NULL, NULL),
(1105, 40, NULL, 6, 'TAILIN SANITARY WARE (3)', '20202010203', '202020102', 2, 2, 5, 0, 1, 0, 0, 40, NULL, NULL, '2022-09-28 09:01:06', NULL, NULL),
(1106, 41, NULL, 6, 'ALIF (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-09-28 16:08:52', NULL, NULL),
(1107, 41, NULL, 6, 'Guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-09-28 16:13:23', NULL, NULL),
(1108, 42, NULL, 6, 'DBB-Doofaz IT(258.151.1344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 42, NULL, NULL, '2022-09-28 22:14:20', NULL, NULL),
(1109, 42, NULL, 6, 'LABU (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 42, NULL, NULL, '2022-09-29 00:42:31', NULL, NULL),
(1110, 41, NULL, 5, 'tst', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-09-29 10:27:15', NULL, NULL),
(1111, 42, NULL, 5, 'saiful', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 42, NULL, NULL, '2022-09-29 10:27:17', NULL, NULL),
(1112, 42, NULL, 6, 'regular', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 42, NULL, NULL, '2022-09-29 14:36:25', NULL, NULL),
(1113, 41, NULL, 6, 'nasta (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-09-30 22:10:54', NULL, NULL),
(1114, 41, NULL, 4, 'nasta (head office lunce)', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-09-30 22:10:54', NULL, NULL),
(1115, 41, NULL, 6, 'ALIF (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-10-01 15:06:36', NULL, NULL),
(1116, 41, NULL, 6, 'TERA HO (3)', '20202010203', '202020102', 2, 2, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-10-01 15:06:56', NULL, NULL),
(1117, 46, NULL, 5, 'Good2', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-01 16:14:14', NULL, NULL),
(1118, 47, NULL, 5, 't', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-01 16:20:58', NULL, NULL),
(1119, 47, NULL, 6, 'SAIFUL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-01 16:34:20', NULL, NULL),
(1120, 47, NULL, 6, 'Guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-01 16:35:25', NULL, NULL),
(1121, 47, NULL, 5, 'akash', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-01 18:58:15', NULL, NULL),
(1122, 47, NULL, 5, 'obuj balok', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-02 20:53:04', NULL, NULL),
(1123, 47, NULL, 5, 'JESMIN', '201010104', '2010101', 2, 2, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-02 22:33:20', NULL, NULL),
(1124, 47, NULL, 6, 'daily lunce (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-02 22:39:56', NULL, NULL),
(1125, 47, NULL, 4, 'daily lunce (lunce)', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-02 22:39:56', NULL, NULL),
(1126, 47, NULL, 6, 'SAI (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-02 22:50:40', NULL, NULL),
(1127, 47, NULL, 6, 'para', '102020101002', '102020101', 1, 1, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-02 22:55:08', NULL, NULL),
(1128, 47, NULL, 6, 'whole', '102020104001', '102020104', 1, 1, 5, 0, 1, 0, 0, 47, NULL, NULL, '2022-10-04 02:43:12', NULL, NULL),
(1129, 48, NULL, 5, 'nokia', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-04 22:39:39', NULL, NULL),
(1130, 41, NULL, 6, 'SHOPON (4)', '20202010204', '202020102', 2, 2, 5, 0, 1, 0, 0, 41, NULL, NULL, '2022-10-06 20:00:55', NULL, NULL),
(1131, 49, NULL, 5, 'bigdemo', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-06 21:53:55', NULL, NULL),
(1132, 50, NULL, 5, 'aklima', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-06 22:12:37', NULL, NULL),
(1133, 51, NULL, 5, 'Mr ayat islam', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-06 23:31:10', NULL, NULL),
(1134, 52, NULL, 5, 'sfd', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-07 00:01:56', NULL, NULL),
(1135, 53, NULL, 5, 'saiful islam', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-07 00:54:53', NULL, NULL),
(1136, 53, NULL, 5, 'saiful', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 53, NULL, NULL, '2022-10-07 00:58:22', NULL, NULL),
(1137, 53, NULL, 5, 'naser', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 53, NULL, NULL, '2022-10-07 00:59:21', NULL, NULL),
(1138, 53, NULL, 6, 'MASUM (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 53, NULL, NULL, '2022-10-07 01:01:35', NULL, NULL),
(1139, 54, NULL, 5, 'father', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-07 09:53:59', NULL, NULL),
(1140, 54, NULL, 5, 'nazmul', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 54, NULL, NULL, '2022-10-07 09:58:33', NULL, NULL),
(1141, 54, NULL, 6, 'regular', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 54, NULL, NULL, '2022-10-07 12:02:59', NULL, NULL),
(1142, 54, NULL, 6, 'NAGAL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 54, NULL, NULL, '2022-10-07 12:04:43', NULL, NULL),
(1143, 57, NULL, 5, 'a', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-07 18:12:44', NULL, NULL),
(1144, 58, NULL, 5, 'tapos', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-07 19:58:34', NULL, NULL),
(1145, 58, NULL, 6, 'SUP (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 58, NULL, NULL, '2022-10-07 20:00:51', NULL, NULL),
(1146, 57, NULL, 6, 'UU (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 57, NULL, NULL, '2022-10-07 21:13:07', NULL, NULL),
(1147, 58, NULL, 6, 'Nosu', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 58, NULL, NULL, '2022-10-07 22:37:38', NULL, NULL),
(1148, 58, NULL, 5, 'nanu', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 58, NULL, NULL, '2022-10-08 19:40:02', NULL, NULL),
(1149, 59, NULL, 5, 'test', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-08 20:11:07', NULL, NULL),
(1150, 59, NULL, 6, 'NAZMUL (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 59, NULL, NULL, '2022-10-08 20:16:13', NULL, NULL),
(1151, 59, NULL, 7, 'hasan (1)', '2020201010101', '20202010101', 2, 2, 5, 0, 1, 0, 0, 59, NULL, NULL, '2022-10-08 20:18:31', NULL, NULL),
(1152, 59, NULL, 5, 'saiful', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 59, NULL, NULL, '2022-10-08 20:23:51', NULL, NULL),
(1153, 58, NULL, 5, 'belu', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 58, NULL, NULL, '2022-10-08 21:15:44', NULL, NULL),
(1154, 58, NULL, 6, 'DBB-Doofaz IT limited(258.151.1344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 58, NULL, NULL, '2022-10-08 21:16:31', NULL, NULL),
(1155, 58, NULL, 6, 'INDRO (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 58, NULL, NULL, '2022-10-08 21:18:53', NULL, NULL),
(1156, 60, NULL, 5, 'special', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-08 21:23:21', NULL, NULL),
(1157, 60, NULL, 5, 'mintu', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:25:29', NULL, NULL),
(1158, 60, NULL, 6, 'DBB-Doofaz IT limited(258.151.1344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:26:04', NULL, NULL),
(1159, 60, NULL, 6, 'Bkash-01749818523(Agent)', '10201020201', '102010202', 1, 1, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:26:19', NULL, NULL),
(1160, 60, NULL, 5, 'Asek', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:27:27', NULL, NULL),
(1161, 60, NULL, 5, 'nazmul', '201010104', '2010101', 2, 2, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:28:25', NULL, NULL),
(1162, 60, NULL, 6, 'HALUA (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:29:48', NULL, NULL),
(1163, 60, NULL, 6, 'Guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:31:21', NULL, NULL),
(1164, 60, NULL, 6, 'regula', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 60, NULL, NULL, '2022-10-08 21:38:34', NULL, NULL),
(1165, 61, NULL, 5, 'gudda', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-08 23:32:00', NULL, NULL),
(1166, 61, NULL, 5, 'nuro 1', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 61, NULL, NULL, '2022-10-08 23:33:57', NULL, NULL),
(1167, 61, NULL, 5, 'nuro 2', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 61, NULL, NULL, '2022-10-08 23:34:09', NULL, NULL),
(1168, 61, NULL, 5, 'nuro 3', '201010104', '2010101', 2, 2, 5, 0, 1, 0, 0, 61, NULL, NULL, '2022-10-08 23:34:21', NULL, NULL),
(1169, 61, NULL, 6, 'DBB-Doofaz IT limited(258.151.1344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 61, NULL, NULL, '2022-10-08 23:36:16', NULL, NULL),
(1170, 61, NULL, 6, 'NANTU (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 61, NULL, NULL, '2022-10-09 00:12:55', NULL, NULL),
(1171, 61, NULL, 6, 'INNA LILLAH HI (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 61, NULL, NULL, '2022-10-09 00:18:18', NULL, NULL),
(1172, 62, NULL, 5, 'maro', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-09 10:34:02', NULL, NULL),
(1173, 62, NULL, 6, 'MERE JAN (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 10:56:53', NULL, NULL),
(1174, 62, NULL, 6, 'Guest', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 11:00:09', NULL, NULL),
(1175, 62, NULL, 6, 'Regular', '102020102001', '102020102', 1, 1, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 11:04:07', NULL, NULL),
(1176, 62, NULL, 5, 'mridul', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 12:01:53', NULL, NULL),
(1177, 62, NULL, 5, 'irani', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 12:02:05', NULL, NULL),
(1178, 62, NULL, 6, 'ecustomer', '102020103001', '102020103', 1, 1, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 12:09:13', NULL, NULL),
(1179, 62, NULL, 6, 'DBB-Doofaz IT limited(258.151.1344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 13:12:07', NULL, NULL),
(1180, 62, NULL, 6, 'Bkash-01749818523(Merchant)', '10201020201', '102010202', 1, 1, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 13:13:29', NULL, NULL),
(1181, 62, NULL, 6, 'Special', '102020105001', '102020105', 1, 1, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 13:53:33', NULL, NULL),
(1182, 62, NULL, 6, 'SPECIAL (2)', '20202010202', '202020102', 2, 2, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 13:54:45', NULL, NULL),
(1183, 62, NULL, 6, 'Loan-NGO-brack (bokhtarmunshi)', '20201010201', '202010102', 2, 2, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 14:05:51', NULL, NULL),
(1184, 62, NULL, 5, 'Loan-NGO-brack (bokhtarmunshi)', '505030201', '5050302', 1, 5, 5, 0, 1, 0, 0, 62, NULL, NULL, '2022-10-09 14:05:51', NULL, NULL),
(1185, 63, NULL, 5, 'shop', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-15 01:17:15', NULL, NULL),
(1186, 63, NULL, 6, 'DBB-Doofaz IT limited(258.151.1344)', '10201020101', '102010201', 1, 1, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-15 01:29:21', NULL, NULL),
(1187, 63, NULL, 6, 'Bkash-01749818523(Agent)', '10201020201', '102010202', 1, 1, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-15 01:29:35', NULL, NULL),
(1188, 63, NULL, 5, 'saiful', '201010102', '2010101', 2, 2, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-15 01:30:52', NULL, NULL),
(1189, 63, NULL, 5, 'Nazmul', '201010103', '2010101', 2, 2, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-15 01:31:05', NULL, NULL),
(1190, 63, NULL, 6, 'ABL-Doofaz IT limited1(01749818523)', '10201020102', '102010201', 1, 1, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-15 20:57:15', NULL, NULL),
(1191, 9, NULL, 6, 'SUP (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 9, NULL, NULL, '2022-10-16 19:01:12', NULL, NULL),
(1192, 63, NULL, 6, 'TEST (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-17 05:26:34', NULL, NULL),
(1193, 64, NULL, 5, 'jk', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-25 08:10:55', NULL, NULL),
(1194, 65, NULL, 5, 'jk', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-10-25 08:11:56', NULL, NULL),
(1195, 64, NULL, 6, 'TEST (1)', '20202010201', '202020102', 2, 2, 5, 0, 1, 0, 0, 64, NULL, NULL, '2022-10-25 08:21:11', NULL, NULL),
(1196, 63, NULL, 6, 'office lunch (Security Money)', '10204020201', '102040202', 1, 1, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-28 06:16:50', NULL, NULL),
(1197, 63, NULL, 4, 'office lunch (office lunch)', '5060101', '50601', 1, 5, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-28 06:16:50', NULL, NULL),
(1198, 63, NULL, 6, 'guest (Security Money)', '10204020202', '102040202', 1, 1, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-28 07:03:09', NULL, NULL);
INSERT INTO `chart_of_account_registers` (`id`, `shopId`, `branchId`, `headLavel`, `headName`, `headCode`, `pre_code`, `dr_cr`, `headGroupId`, `headGroupType`, `lastCode`, `status`, `position`, `autoCreate`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1199, 63, NULL, 4, 'guest (office lunch)', '5060102', '50601', 1, 5, 5, 0, 1, 0, 0, 63, NULL, NULL, '2022-10-28 07:03:09', NULL, NULL),
(1200, 9, NULL, 5, 'sdf', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-14 14:56:15', NULL, NULL),
(1201, 10, NULL, 5, 'bangla', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-17 12:07:45', NULL, NULL),
(1202, 11, NULL, 5, 'bangla', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-17 12:09:02', NULL, NULL),
(1203, 12, NULL, 5, 'New Company', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-17 12:11:07', NULL, NULL),
(1204, 13, NULL, 5, 'sa', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-17 12:12:01', NULL, NULL),
(1205, 14, NULL, 5, 'nokia', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-17 12:41:53', NULL, NULL),
(1206, 15, NULL, 5, 'Babul Uddin', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2022-12-26 05:11:12', NULL, NULL),
(1207, 16, NULL, 5, 'Md babul uddin', '201010101', '2010101', 2, 2, 5, 0, 1, 0, 0, 1, NULL, NULL, '2023-02-03 13:28:35', NULL, NULL),
(1208, 9, NULL, 6, 'ew', '102020101001', '102020101', 1, 1, 5, 0, 1, 0, 0, 9, NULL, NULL, '2023-02-26 08:00:31', NULL, NULL),
(1209, 9, NULL, 6, 'Md Nazmul Huda', '102020101002', '102020101', 1, 1, 5, 0, 1, 0, 0, 9, NULL, NULL, '2023-02-26 08:04:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `chart_of_account_relations`
--

CREATE TABLE `chart_of_account_relations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `branchId` int(11) NOT NULL,
  `tableHeadId` int(11) NOT NULL,
  `accountHeadCode` varchar(255) NOT NULL,
  `accountCode` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleteStatus` tinyint(1) DEFAULT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `iso` varchar(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `nicename` varchar(80) NOT NULL,
  `iso3` varchar(3) NOT NULL,
  `numcode` int(11) NOT NULL,
  `phonecode` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `iso`, `name`, `nicename`, `iso3`, `numcode`, `phonecode`, `created_at`, `updated_at`, `status`) VALUES
(1, 'AF', 'AFGHANISTAN', 'Afghanistan', 'AFG', 4, 93, NULL, NULL, 0),
(2, 'AL', 'ALBANIA', 'Albania', 'ALB', 8, 355, NULL, NULL, 0),
(3, 'DZ', 'ALGERIA', 'Algeria', 'DZA', 12, 213, NULL, NULL, 0),
(4, 'AS', 'AMERICAN SAMOA', 'American Samoa', 'ASM', 16, 1684, NULL, NULL, 0),
(5, 'AD', 'ANDORRA', 'Andorra', 'AND', 20, 376, NULL, NULL, 0),
(6, 'AO', 'ANGOLA', 'Angola', 'AGO', 24, 244, NULL, NULL, 0),
(7, 'AI', 'ANGUILLA', 'Anguilla', 'AIA', 660, 1264, NULL, NULL, 0),
(8, 'AQ', 'ANTARCTICA', 'Antarctica', '', 0, 0, NULL, NULL, 0),
(9, 'AG', 'ANTIGUA AND BARBUDA', 'Antigua and Barbuda', 'ATG', 28, 1268, NULL, NULL, 0),
(10, 'AR', 'ARGENTINA', 'Argentina', 'ARG', 32, 54, NULL, NULL, 0),
(11, 'AM', 'ARMENIA', 'Armenia', 'ARM', 51, 374, NULL, NULL, 0),
(12, 'AW', 'ARUBA', 'Aruba', 'ABW', 533, 297, NULL, NULL, 0),
(13, 'AU', 'AUSTRALIA', 'Australia', 'AUS', 36, 61, NULL, NULL, 0),
(14, 'AT', 'AUSTRIA', 'Austria', 'AUT', 40, 43, NULL, NULL, 0),
(15, 'AZ', 'AZERBAIJAN', 'Azerbaijan', 'AZE', 31, 994, NULL, NULL, 0),
(16, 'BS', 'BAHAMAS', 'Bahamas', 'BHS', 44, 1242, NULL, NULL, 0),
(17, 'BH', 'BAHRAIN', 'Bahrain', 'BHR', 48, 973, NULL, NULL, 0),
(18, 'BB', 'BARBADOS', 'Barbados', 'BRB', 52, 1246, NULL, NULL, 0),
(19, 'BD', 'BANGLADESH', 'Bangladesh', 'BGD', 50, 880, NULL, NULL, 1),
(20, 'BY', 'BELARUS', 'Belarus', 'BLR', 112, 375, NULL, NULL, 0),
(21, 'BE', 'BELGIUM', 'Belgium', 'BEL', 56, 32, NULL, NULL, 0),
(22, 'BZ', 'BELIZE', 'Belize', 'BLZ', 84, 501, NULL, NULL, 0),
(23, 'BJ', 'BENIN', 'Benin', 'BEN', 204, 229, NULL, NULL, 0),
(24, 'BM', 'BERMUDA', 'Bermuda', 'BMU', 60, 1441, NULL, NULL, 0),
(25, 'BT', 'BHUTAN', 'Bhutan', 'BTN', 64, 975, NULL, NULL, 0),
(26, 'BO', 'BOLIVIA', 'Bolivia', 'BOL', 68, 591, NULL, NULL, 0),
(27, 'BA', 'BOSNIA AND HERZEGOVINA', 'Bosnia and Herzegovina', 'BIH', 70, 387, NULL, NULL, 0),
(28, 'BW', 'BOTSWANA', 'Botswana', 'BWA', 72, 267, NULL, NULL, 0),
(29, 'BV', 'BOUVET ISLAND', 'Bouvet Island', '', 0, 0, NULL, NULL, 0),
(30, 'BR', 'BRAZIL', 'Brazil', 'BRA', 76, 55, NULL, NULL, 0),
(31, 'IO', 'BRITISH INDIAN OCEAN TERRITORY', 'British Indian Ocean Territory', '', 0, 246, NULL, NULL, 0),
(32, 'BN', 'BRUNEI DARUSSALAM', 'Brunei Darussalam', 'BRN', 96, 673, NULL, NULL, 0),
(33, 'BG', 'BULGARIA', 'Bulgaria', 'BGR', 100, 359, NULL, NULL, 0),
(34, 'BF', 'BURKINA FASO', 'Burkina Faso', 'BFA', 854, 226, NULL, NULL, 0),
(35, 'BI', 'BURUNDI', 'Burundi', 'BDI', 108, 257, NULL, NULL, 0),
(36, 'KH', 'CAMBODIA', 'Cambodia', 'KHM', 116, 855, NULL, NULL, 0),
(37, 'CM', 'CAMEROON', 'Cameroon', 'CMR', 120, 237, NULL, NULL, 0),
(38, 'CA', 'CANADA', 'Canada', 'CAN', 124, 1, NULL, NULL, 0),
(39, 'CV', 'CAPE VERDE', 'Cape Verde', 'CPV', 132, 238, NULL, NULL, 0),
(40, 'KY', 'CAYMAN ISLANDS', 'Cayman Islands', 'CYM', 136, 1345, NULL, NULL, 0),
(41, 'CF', 'CENTRAL AFRICAN REPUBLIC', 'Central African Republic', 'CAF', 140, 236, NULL, NULL, 0),
(42, 'TD', 'CHAD', 'Chad', 'TCD', 148, 235, NULL, NULL, 0),
(43, 'CL', 'CHILE', 'Chile', 'CHL', 152, 56, NULL, NULL, 0),
(44, 'CN', 'CHINA', 'China', 'CHN', 156, 86, NULL, NULL, 0),
(45, 'CX', 'CHRISTMAS ISLAND', 'Christmas Island', '', 0, 61, NULL, NULL, 0),
(46, 'CC', 'COCOS (KEELING) ISLANDS', 'Cocos (Keeling) Islands', '', 0, 672, NULL, NULL, 0),
(47, 'CO', 'COLOMBIA', 'Colombia', 'COL', 170, 57, NULL, NULL, 0),
(48, 'KM', 'COMOROS', 'Comoros', 'COM', 174, 269, NULL, NULL, 0),
(49, 'CG', 'CONGO', 'Congo', 'COG', 178, 242, NULL, NULL, 0),
(50, 'CD', 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'Congo, the Democratic Republic of the', 'COD', 180, 242, NULL, NULL, 0),
(51, 'CK', 'COOK ISLANDS', 'Cook Islands', 'COK', 184, 682, NULL, NULL, 0),
(52, 'CR', 'COSTA RICA', 'Costa Rica', 'CRI', 188, 506, NULL, NULL, 0),
(53, 'CI', 'COTE D\'IVOIRE', 'Cote D\'Ivoire', 'CIV', 384, 225, NULL, NULL, 0),
(54, 'HR', 'CROATIA', 'Croatia', 'HRV', 191, 385, NULL, NULL, 0),
(55, 'CU', 'CUBA', 'Cuba', 'CUB', 192, 53, NULL, NULL, 0),
(56, 'CY', 'CYPRUS', 'Cyprus', 'CYP', 196, 357, NULL, NULL, 0),
(57, 'CZ', 'CZECH REPUBLIC', 'Czech Republic', 'CZE', 203, 420, NULL, NULL, 0),
(58, 'DK', 'DENMARK', 'Denmark', 'DNK', 208, 45, NULL, NULL, 0),
(59, 'DJ', 'DJIBOUTI', 'Djibouti', 'DJI', 262, 253, NULL, NULL, 0),
(60, 'DM', 'DOMINICA', 'Dominica', 'DMA', 212, 1767, NULL, NULL, 0),
(61, 'DO', 'DOMINICAN REPUBLIC', 'Dominican Republic', 'DOM', 214, 1809, NULL, NULL, 0),
(62, 'EC', 'ECUADOR', 'Ecuador', 'ECU', 218, 593, NULL, NULL, 0),
(63, 'EG', 'EGYPT', 'Egypt', 'EGY', 818, 20, NULL, NULL, 0),
(64, 'SV', 'EL SALVADOR', 'El Salvador', 'SLV', 222, 503, NULL, NULL, 0),
(65, 'GQ', 'EQUATORIAL GUINEA', 'Equatorial Guinea', 'GNQ', 226, 240, NULL, NULL, 0),
(66, 'ER', 'ERITREA', 'Eritrea', 'ERI', 232, 291, NULL, NULL, 0),
(67, 'EE', 'ESTONIA', 'Estonia', 'EST', 233, 372, NULL, NULL, 0),
(68, 'ET', 'ETHIOPIA', 'Ethiopia', 'ETH', 231, 251, NULL, NULL, 0),
(69, 'FK', 'FALKLAND ISLANDS (MALVINAS)', 'Falkland Islands (Malvinas)', 'FLK', 238, 500, NULL, NULL, 0),
(70, 'FO', 'FAROE ISLANDS', 'Faroe Islands', 'FRO', 234, 298, NULL, NULL, 0),
(71, 'FJ', 'FIJI', 'Fiji', 'FJI', 242, 679, NULL, NULL, 0),
(72, 'FI', 'FINLAND', 'Finland', 'FIN', 246, 358, NULL, NULL, 0),
(73, 'FR', 'FRANCE', 'France', 'FRA', 250, 33, NULL, NULL, 0),
(74, 'GF', 'FRENCH GUIANA', 'French Guiana', 'GUF', 254, 594, NULL, NULL, 0),
(75, 'PF', 'FRENCH POLYNESIA', 'French Polynesia', 'PYF', 258, 689, NULL, NULL, 0),
(76, 'TF', 'FRENCH SOUTHERN TERRITORIES', 'French Southern Territories', '', 0, 0, NULL, NULL, 0),
(77, 'GA', 'GABON', 'Gabon', 'GAB', 266, 241, NULL, NULL, 0),
(78, 'GM', 'GAMBIA', 'Gambia', 'GMB', 270, 220, NULL, NULL, 0),
(79, 'GE', 'GEORGIA', 'Georgia', 'GEO', 268, 995, NULL, NULL, 0),
(80, 'DE', 'GERMANY', 'Germany', 'DEU', 276, 49, NULL, NULL, 0),
(81, 'GH', 'GHANA', 'Ghana', 'GHA', 288, 233, NULL, NULL, 0),
(82, 'GI', 'GIBRALTAR', 'Gibraltar', 'GIB', 292, 350, NULL, NULL, 0),
(83, 'GR', 'GREECE', 'Greece', 'GRC', 300, 30, NULL, NULL, 0),
(84, 'GL', 'GREENLAND', 'Greenland', 'GRL', 304, 299, NULL, NULL, 0),
(85, 'GD', 'GRENADA', 'Grenada', 'GRD', 308, 1473, NULL, NULL, 0),
(86, 'GP', 'GUADELOUPE', 'Guadeloupe', 'GLP', 312, 590, NULL, NULL, 0),
(87, 'GU', 'GUAM', 'Guam', 'GUM', 316, 1671, NULL, NULL, 0),
(88, 'GT', 'GUATEMALA', 'Guatemala', 'GTM', 320, 502, NULL, NULL, 0),
(89, 'GN', 'GUINEA', 'Guinea', 'GIN', 324, 224, NULL, NULL, 0),
(90, 'GW', 'GUINEA-BISSAU', 'Guinea-Bissau', 'GNB', 624, 245, NULL, NULL, 0),
(91, 'GY', 'GUYANA', 'Guyana', 'GUY', 328, 592, NULL, NULL, 0),
(92, 'HT', 'HAITI', 'Haiti', 'HTI', 332, 509, NULL, NULL, 0),
(93, 'HM', 'HEARD ISLAND AND MCDONALD ISLANDS', 'Heard Island and Mcdonald Islands', '', 0, 0, NULL, NULL, 0),
(94, 'VA', 'HOLY SEE (VATICAN CITY STATE)', 'Holy See (Vatican City State)', 'VAT', 336, 39, NULL, NULL, 0),
(95, 'HN', 'HONDURAS', 'Honduras', 'HND', 340, 504, NULL, NULL, 0),
(96, 'HK', 'HONG KONG', 'Hong Kong', 'HKG', 344, 852, NULL, NULL, 0),
(97, 'HU', 'HUNGARY', 'Hungary', 'HUN', 348, 36, NULL, NULL, 0),
(98, 'IS', 'ICELAND', 'Iceland', 'ISL', 352, 354, NULL, NULL, 0),
(99, 'IN', 'INDIA', 'India', 'IND', 356, 91, NULL, NULL, 0),
(100, 'ID', 'INDONESIA', 'Indonesia', 'IDN', 360, 62, NULL, NULL, 0),
(101, 'IR', 'IRAN, ISLAMIC REPUBLIC OF', 'Iran, Islamic Republic of', 'IRN', 364, 98, NULL, NULL, 0),
(102, 'IQ', 'IRAQ', 'Iraq', 'IRQ', 368, 964, NULL, NULL, 0),
(103, 'IE', 'IRELAND', 'Ireland', 'IRL', 372, 353, NULL, NULL, 0),
(104, 'IL', 'ISRAEL', 'Israel', 'ISR', 376, 972, NULL, NULL, 0),
(105, 'IT', 'ITALY', 'Italy', 'ITA', 380, 39, NULL, NULL, 0),
(106, 'JM', 'JAMAICA', 'Jamaica', 'JAM', 388, 1876, NULL, NULL, 0),
(107, 'JP', 'JAPAN', 'Japan', 'JPN', 392, 81, NULL, NULL, 0),
(108, 'JO', 'JORDAN', 'Jordan', 'JOR', 400, 962, NULL, NULL, 0),
(109, 'KZ', 'KAZAKHSTAN', 'Kazakhstan', 'KAZ', 398, 7, NULL, NULL, 0),
(110, 'KE', 'KENYA', 'Kenya', 'KEN', 404, 254, NULL, NULL, 0),
(111, 'KI', 'KIRIBATI', 'Kiribati', 'KIR', 296, 686, NULL, NULL, 0),
(112, 'KP', 'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF', 'Korea, Democratic People\'s Republic of', 'PRK', 408, 850, NULL, NULL, 0),
(113, 'KR', 'KOREA, REPUBLIC OF', 'Korea, Republic of', 'KOR', 410, 82, NULL, NULL, 0),
(114, 'KW', 'KUWAIT', 'Kuwait', 'KWT', 414, 965, NULL, NULL, 0),
(115, 'KG', 'KYRGYZSTAN', 'Kyrgyzstan', 'KGZ', 417, 996, NULL, NULL, 0),
(116, 'LA', 'LAO PEOPLE\'S DEMOCRATIC REPUBLIC', 'Lao People\'s Democratic Republic', 'LAO', 418, 856, NULL, NULL, 0),
(117, 'LV', 'LATVIA', 'Latvia', 'LVA', 428, 371, NULL, NULL, 0),
(118, 'LB', 'LEBANON', 'Lebanon', 'LBN', 422, 961, NULL, NULL, 0),
(119, 'LS', 'LESOTHO', 'Lesotho', 'LSO', 426, 266, NULL, NULL, 0),
(120, 'LR', 'LIBERIA', 'Liberia', 'LBR', 430, 231, NULL, NULL, 0),
(121, 'LY', 'LIBYAN ARAB JAMAHIRIYA', 'Libyan Arab Jamahiriya', 'LBY', 434, 218, NULL, NULL, 0),
(122, 'LI', 'LIECHTENSTEIN', 'Liechtenstein', 'LIE', 438, 423, NULL, NULL, 0),
(123, 'LT', 'LITHUANIA', 'Lithuania', 'LTU', 440, 370, NULL, NULL, 0),
(124, 'LU', 'LUXEMBOURG', 'Luxembourg', 'LUX', 442, 352, NULL, NULL, 0),
(125, 'MO', 'MACAO', 'Macao', 'MAC', 446, 853, NULL, NULL, 0),
(126, 'MK', 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807, 389, NULL, NULL, 0),
(127, 'MG', 'MADAGASCAR', 'Madagascar', 'MDG', 450, 261, NULL, NULL, 0),
(128, 'MW', 'MALAWI', 'Malawi', 'MWI', 454, 265, NULL, NULL, 0),
(129, 'MY', 'MALAYSIA', 'Malaysia', 'MYS', 458, 60, NULL, NULL, 0),
(130, 'MV', 'MALDIVES', 'Maldives', 'MDV', 462, 960, NULL, NULL, 0),
(131, 'ML', 'MALI', 'Mali', 'MLI', 466, 223, NULL, NULL, 0),
(132, 'MT', 'MALTA', 'Malta', 'MLT', 470, 356, NULL, NULL, 0),
(133, 'MH', 'MARSHALL ISLANDS', 'Marshall Islands', 'MHL', 584, 692, NULL, NULL, 0),
(134, 'MQ', 'MARTINIQUE', 'Martinique', 'MTQ', 474, 596, NULL, NULL, 0),
(135, 'MR', 'MAURITANIA', 'Mauritania', 'MRT', 478, 222, NULL, NULL, 0),
(136, 'MU', 'MAURITIUS', 'Mauritius', 'MUS', 480, 230, NULL, NULL, 0),
(137, 'YT', 'MAYOTTE', 'Mayotte', '', 0, 269, NULL, NULL, 0),
(138, 'MX', 'MEXICO', 'Mexico', 'MEX', 484, 52, NULL, NULL, 0),
(139, 'FM', 'MICRONESIA, FEDERATED STATES OF', 'Micronesia, Federated States of', 'FSM', 583, 691, NULL, NULL, 0),
(140, 'MD', 'MOLDOVA, REPUBLIC OF', 'Moldova, Republic of', 'MDA', 498, 373, NULL, NULL, 0),
(141, 'MC', 'MONACO', 'Monaco', 'MCO', 492, 377, NULL, NULL, 0),
(142, 'MN', 'MONGOLIA', 'Mongolia', 'MNG', 496, 976, NULL, NULL, 0),
(143, 'MS', 'MONTSERRAT', 'Montserrat', 'MSR', 500, 1664, NULL, NULL, 0),
(144, 'MA', 'MOROCCO', 'Morocco', 'MAR', 504, 212, NULL, NULL, 0),
(145, 'MZ', 'MOZAMBIQUE', 'Mozambique', 'MOZ', 508, 258, NULL, NULL, 0),
(146, 'MM', 'MYANMAR', 'Myanmar', 'MMR', 104, 95, NULL, NULL, 0),
(147, 'NA', 'NAMIBIA', 'Namibia', 'NAM', 516, 264, NULL, NULL, 0),
(148, 'NR', 'NAURU', 'Nauru', 'NRU', 520, 674, NULL, NULL, 0),
(149, 'NP', 'NEPAL', 'Nepal', 'NPL', 524, 977, NULL, NULL, 0),
(150, 'NL', 'NETHERLANDS', 'Netherlands', 'NLD', 528, 31, NULL, NULL, 0),
(151, 'AN', 'NETHERLANDS ANTILLES', 'Netherlands Antilles', 'ANT', 530, 599, NULL, NULL, 0),
(152, 'NC', 'NEW CALEDONIA', 'New Caledonia', 'NCL', 540, 687, NULL, NULL, 0),
(153, 'NZ', 'NEW ZEALAND', 'New Zealand', 'NZL', 554, 64, NULL, NULL, 0),
(154, 'NI', 'NICARAGUA', 'Nicaragua', 'NIC', 558, 505, NULL, NULL, 0),
(155, 'NE', 'NIGER', 'Niger', 'NER', 562, 227, NULL, NULL, 0),
(156, 'NG', 'NIGERIA', 'Nigeria', 'NGA', 566, 234, NULL, NULL, 0),
(157, 'NU', 'NIUE', 'Niue', 'NIU', 570, 683, NULL, NULL, 0),
(158, 'NF', 'NORFOLK ISLAND', 'Norfolk Island', 'NFK', 574, 672, NULL, NULL, 0),
(159, 'MP', 'NORTHERN MARIANA ISLANDS', 'Northern Mariana Islands', 'MNP', 580, 1670, NULL, NULL, 0),
(160, 'NO', 'NORWAY', 'Norway', 'NOR', 578, 47, NULL, NULL, 0),
(161, 'OM', 'OMAN', 'Oman', 'OMN', 512, 968, NULL, NULL, 0),
(162, 'PK', 'PAKISTAN', 'Pakistan', 'PAK', 586, 92, NULL, NULL, 0),
(163, 'PW', 'PALAU', 'Palau', 'PLW', 585, 680, NULL, NULL, 0),
(164, 'PS', 'PALESTINIAN TERRITORY, OCCUPIED', 'Palestinian Territory, Occupied', '', 0, 970, NULL, NULL, 0),
(165, 'PA', 'PANAMA', 'Panama', 'PAN', 591, 507, NULL, NULL, 0),
(166, 'PG', 'PAPUA NEW GUINEA', 'Papua New Guinea', 'PNG', 598, 675, NULL, NULL, 0),
(167, 'PY', 'PARAGUAY', 'Paraguay', 'PRY', 600, 595, NULL, NULL, 0),
(168, 'PE', 'PERU', 'Peru', 'PER', 604, 51, NULL, NULL, 0),
(169, 'PH', 'PHILIPPINES', 'Philippines', 'PHL', 608, 63, NULL, NULL, 0),
(170, 'PN', 'PITCAIRN', 'Pitcairn', 'PCN', 612, 0, NULL, NULL, 0),
(171, 'PL', 'POLAND', 'Poland', 'POL', 616, 48, NULL, NULL, 0),
(172, 'PT', 'PORTUGAL', 'Portugal', 'PRT', 620, 351, NULL, NULL, 0),
(173, 'PR', 'PUERTO RICO', 'Puerto Rico', 'PRI', 630, 1787, NULL, NULL, 0),
(174, 'QA', 'QATAR', 'Qatar', 'QAT', 634, 974, NULL, NULL, 0),
(175, 'RE', 'REUNION', 'Reunion', 'REU', 638, 262, NULL, NULL, 0),
(176, 'RO', 'ROMANIA', 'Romania', 'ROM', 642, 40, NULL, NULL, 0),
(177, 'RU', 'RUSSIAN FEDERATION', 'Russian Federation', 'RUS', 643, 70, NULL, NULL, 0),
(178, 'RW', 'RWANDA', 'Rwanda', 'RWA', 646, 250, NULL, NULL, 0),
(179, 'SH', 'SAINT HELENA', 'Saint Helena', 'SHN', 654, 290, NULL, NULL, 0),
(180, 'KN', 'SAINT KITTS AND NEVIS', 'Saint Kitts and Nevis', 'KNA', 659, 1869, NULL, NULL, 0),
(181, 'LC', 'SAINT LUCIA', 'Saint Lucia', 'LCA', 662, 1758, NULL, NULL, 0),
(182, 'PM', 'SAINT PIERRE AND MIQUELON', 'Saint Pierre and Miquelon', 'SPM', 666, 508, NULL, NULL, 0),
(183, 'VC', 'SAINT VINCENT AND THE GRENADINES', 'Saint Vincent and the Grenadines', 'VCT', 670, 1784, NULL, NULL, 0),
(184, 'WS', 'SAMOA', 'Samoa', 'WSM', 882, 684, NULL, NULL, 0),
(185, 'SM', 'SAN MARINO', 'San Marino', 'SMR', 674, 378, NULL, NULL, 0),
(186, 'ST', 'SAO TOME AND PRINCIPE', 'Sao Tome and Principe', 'STP', 678, 239, NULL, NULL, 0),
(187, 'SA', 'SAUDI ARABIA', 'Saudi Arabia', 'SAU', 682, 966, NULL, NULL, 0),
(188, 'SN', 'SENEGAL', 'Senegal', 'SEN', 686, 221, NULL, NULL, 0),
(189, 'CS', 'SERBIA AND MONTENEGRO', 'Serbia and Montenegro', '', 0, 381, NULL, NULL, 0),
(190, 'SC', 'SEYCHELLES', 'Seychelles', 'SYC', 690, 248, NULL, NULL, 0),
(191, 'SL', 'SIERRA LEONE', 'Sierra Leone', 'SLE', 694, 232, NULL, NULL, 0),
(192, 'SG', 'SINGAPORE', 'Singapore', 'SGP', 702, 65, NULL, NULL, 0),
(193, 'SK', 'SLOVAKIA', 'Slovakia', 'SVK', 703, 421, NULL, NULL, 0),
(194, 'SI', 'SLOVENIA', 'Slovenia', 'SVN', 705, 386, NULL, NULL, 0),
(195, 'SB', 'SOLOMON ISLANDS', 'Solomon Islands', 'SLB', 90, 677, NULL, NULL, 0),
(196, 'SO', 'SOMALIA', 'Somalia', 'SOM', 706, 252, NULL, NULL, 0),
(197, 'ZA', 'SOUTH AFRICA', 'South Africa', 'ZAF', 710, 27, NULL, NULL, 0),
(198, 'GS', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'South Georgia and the South Sandwich Islands', '', 0, 0, NULL, NULL, 0),
(199, 'ES', 'SPAIN', 'Spain', 'ESP', 724, 34, NULL, NULL, 0),
(200, 'LK', 'SRI LANKA', 'Sri Lanka', 'LKA', 144, 94, NULL, NULL, 0),
(201, 'SD', 'SUDAN', 'Sudan', 'SDN', 736, 249, NULL, NULL, 0),
(202, 'SR', 'SURINAME', 'Suriname', 'SUR', 740, 597, NULL, NULL, 0),
(203, 'SJ', 'SVALBARD AND JAN MAYEN', 'Svalbard and Jan Mayen', 'SJM', 744, 47, NULL, NULL, 0),
(204, 'SZ', 'SWAZILAND', 'Swaziland', 'SWZ', 748, 268, NULL, NULL, 0),
(205, 'SE', 'SWEDEN', 'Sweden', 'SWE', 752, 46, NULL, NULL, 0),
(206, 'CH', 'SWITZERLAND', 'Switzerland', 'CHE', 756, 41, NULL, NULL, 0),
(207, 'SY', 'SYRIAN ARAB REPUBLIC', 'Syrian Arab Republic', 'SYR', 760, 963, NULL, NULL, 0),
(208, 'TW', 'TAIWAN, PROVINCE OF CHINA', 'Taiwan, Province of China', 'TWN', 158, 886, NULL, NULL, 0),
(209, 'TJ', 'TAJIKISTAN', 'Tajikistan', 'TJK', 762, 992, NULL, NULL, 0),
(210, 'TZ', 'TANZANIA, UNITED REPUBLIC OF', 'Tanzania, United Republic of', 'TZA', 834, 255, NULL, NULL, 0),
(211, 'TH', 'THAILAND', 'Thailand', 'THA', 764, 66, NULL, NULL, 0),
(212, 'TL', 'TIMOR-LESTE', 'Timor-Leste', '', 0, 670, NULL, NULL, 0),
(213, 'TG', 'TOGO', 'Togo', 'TGO', 768, 228, NULL, NULL, 0),
(214, 'TK', 'TOKELAU', 'Tokelau', 'TKL', 772, 690, NULL, NULL, 0),
(215, 'TO', 'TONGA', 'Tonga', 'TON', 776, 676, NULL, NULL, 0),
(216, 'TT', 'TRINIDAD AND TOBAGO', 'Trinidad and Tobago', 'TTO', 780, 1868, NULL, NULL, 0),
(217, 'TN', 'TUNISIA', 'Tunisia', 'TUN', 788, 216, NULL, NULL, 0),
(218, 'TR', 'TURKEY', 'Turkey', 'TUR', 792, 90, NULL, NULL, 0),
(219, 'TM', 'TURKMENISTAN', 'Turkmenistan', 'TKM', 795, 7370, NULL, NULL, 0),
(220, 'TC', 'TURKS AND CAICOS ISLANDS', 'Turks and Caicos Islands', 'TCA', 796, 1649, NULL, NULL, 0),
(221, 'TV', 'TUVALU', 'Tuvalu', 'TUV', 798, 688, NULL, NULL, 0),
(222, 'UG', 'UGANDA', 'Uganda', 'UGA', 800, 256, NULL, NULL, 0),
(223, 'UA', 'UKRAINE', 'Ukraine', 'UKR', 804, 380, NULL, NULL, 0),
(224, 'AE', 'UNITED ARAB EMIRATES', 'United Arab Emirates', 'ARE', 784, 971, NULL, NULL, 0),
(225, 'GB', 'UNITED KINGDOM', 'United Kingdom', 'GBR', 826, 44, NULL, NULL, 0),
(226, 'US', 'UNITED STATES', 'United States', 'USA', 840, 1, NULL, NULL, 0),
(227, 'UM', 'UNITED STATES MINOR OUTLYING ISLANDS', 'United States Minor Outlying Islands', '', 0, 1, NULL, NULL, 0),
(228, 'UY', 'URUGUAY', 'Uruguay', 'URY', 858, 598, NULL, NULL, 0),
(229, 'UZ', 'UZBEKISTAN', 'Uzbekistan', 'UZB', 860, 998, NULL, NULL, 0),
(230, 'VU', 'VANUATU', 'Vanuatu', 'VUT', 548, 678, NULL, NULL, 0),
(231, 'VE', 'VENEZUELA', 'Venezuela', 'VEN', 862, 58, NULL, NULL, 0),
(232, 'VN', 'VIET NAM', 'Viet Nam', 'VNM', 704, 84, NULL, NULL, 0),
(233, 'VG', 'VIRGIN ISLANDS, BRITISH', 'Virgin Islands, British', 'VGB', 92, 1284, NULL, NULL, 0),
(234, 'VI', 'VIRGIN ISLANDS, U.S.', 'Virgin Islands, U.s.', 'VIR', 850, 1340, NULL, NULL, 0),
(235, 'WF', 'WALLIS AND FUTUNA', 'Wallis and Futuna', 'WLF', 876, 681, NULL, NULL, 0),
(236, 'EH', 'WESTERN SAHARA', 'Western Sahara', 'ESH', 732, 212, NULL, NULL, 0),
(237, 'YE', 'YEMEN', 'Yemen', 'YEM', 887, 967, NULL, NULL, 0),
(238, 'ZM', 'ZAMBIA', 'Zambia', 'ZMB', 894, 260, NULL, NULL, 0),
(239, 'ZW', 'ZIMBABWE', 'Zimbabwe', 'ZWE', 716, 263, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `code` varchar(4) NOT NULL,
  `codeBdt` varchar(20) DEFAULT NULL,
  `minor_unit` int(11) NOT NULL,
  `symbol` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `country`, `currency`, `code`, `codeBdt`, `minor_unit`, `symbol`, `created_at`, `updated_at`, `status`) VALUES
(2, 'Afghanistan', 'Afghani', 'AFN', NULL, 2, '؋', NULL, NULL, 0),
(3, 'Åland Islands', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(4, 'Albania', 'Lek', 'ALL', NULL, 2, 'Lek', NULL, NULL, 0),
(5, 'Algeria', 'Algerian Dinar', 'DZD', NULL, 2, '', NULL, NULL, 0),
(6, 'American Samoa', 'US Dollar', 'USD', 'USD_BDT', 2, '$', NULL, NULL, 0),
(7, 'Andorra', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(8, 'Angola', 'Kwanza', 'AOA', NULL, 2, '', NULL, NULL, 0),
(9, 'Anguilla', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(10, 'Antigua And Barbuda', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(11, 'Argentina', 'Argentine Peso', 'ARS', NULL, 2, '$', NULL, NULL, 0),
(12, 'Armenia', 'Armenian Dram', 'AMD', NULL, 2, '', NULL, NULL, 0),
(13, 'Aruba', 'Aruban Florin', 'AWG', NULL, 2, '', NULL, NULL, 0),
(14, 'Australia', 'Australian Dollar', 'AUD', NULL, 2, '$', NULL, NULL, 0),
(15, 'Austria', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(16, 'Azerbaijan', 'Azerbaijan Manat', 'AZN', NULL, 2, '', NULL, NULL, 0),
(17, 'Bahamas', 'Bahamian Dollar', 'BSD', NULL, 2, '$', NULL, NULL, 0),
(18, 'Bahrain', 'Bahraini Dinar', 'BHD', NULL, 3, '', NULL, NULL, 0),
(19, 'Bangladesh', 'Taka', 'BDT', NULL, 2, '৳', NULL, NULL, 1),
(20, 'Barbados', 'Barbados Dollar', 'BBD', NULL, 2, '$', NULL, NULL, 0),
(21, 'Belarus', 'Belarusian Ruble', 'BYN', NULL, 2, '', NULL, NULL, 0),
(22, 'Belgium', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(23, 'Belize', 'Belize Dollar', 'BZD', NULL, 2, 'BZ$', NULL, NULL, 0),
(24, 'Benin', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(25, 'Bermuda', 'Bermudian Dollar', 'BMD', NULL, 2, '', NULL, NULL, 0),
(26, 'Bhutan', 'Indian Rupee', 'INR', NULL, 2, '₹', NULL, NULL, 0),
(27, 'Bhutan', 'Ngultrum', 'BTN', NULL, 2, '', NULL, NULL, 0),
(28, 'Bolivia', 'Boliviano', 'BOB', NULL, 2, '', NULL, NULL, 0),
(29, 'Bolivia', 'Mvdol', 'BOV', NULL, 2, '', NULL, NULL, 0),
(30, 'Bonaire, Sint Eustatius And Saba', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(31, 'Bosnia And Herzegovina', 'Convertible Mark', 'BAM', NULL, 2, '', NULL, NULL, 0),
(32, 'Botswana', 'Pula', 'BWP', NULL, 2, '', NULL, NULL, 0),
(33, 'Bouvet Island', 'Norwegian Krone', 'NOK', NULL, 2, '', NULL, NULL, 0),
(34, 'Brazil', 'Brazilian Real', 'BRL', NULL, 2, 'R$', NULL, NULL, 0),
(35, 'British Indian Ocean Territory', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(36, 'Brunei Darussalam', 'Brunei Dollar', 'BND', NULL, 2, '', NULL, NULL, 0),
(37, 'Bulgaria', 'Bulgarian Lev', 'BGN', NULL, 2, 'лв', NULL, NULL, 0),
(38, 'Burkina Faso', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(39, 'Burundi', 'Burundi Franc', 'BIF', NULL, 0, '', NULL, NULL, 0),
(40, 'Cabo Verde', 'Cabo Verde Escudo', 'CVE', NULL, 2, '', NULL, NULL, 0),
(41, 'Cambodia', 'Riel', 'KHR', NULL, 2, '៛', NULL, NULL, 0),
(42, 'Cameroon', 'CFA Franc BEAC', 'XAF', NULL, 0, '', NULL, NULL, 0),
(43, 'Canada', 'Canadian Dollar', 'CAD', NULL, 2, '$', NULL, NULL, 0),
(44, 'Cayman Islands', 'Cayman Islands Dollar', 'KYD', NULL, 2, '', NULL, NULL, 0),
(45, 'Central African Republic', 'CFA Franc BEAC', 'XAF', NULL, 0, '', NULL, NULL, 0),
(46, 'Chad', 'CFA Franc BEAC', 'XAF', NULL, 0, '', NULL, NULL, 0),
(47, 'Chile', 'Chilean Peso', 'CLP', NULL, 0, '$', NULL, NULL, 0),
(48, 'Chile', 'Unidad de Fomento', 'CLF', NULL, 4, '', NULL, NULL, 0),
(49, 'China', 'Yuan Renminbi', 'CNY', NULL, 2, '¥', NULL, NULL, 0),
(50, 'Christmas Island', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(51, 'Cocos (keeling) Islands', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(52, 'Colombia', 'Colombian Peso', 'COP', NULL, 2, '$', NULL, NULL, 0),
(53, 'Colombia', 'Unidad de Valor Real', 'COU', NULL, 2, '', NULL, NULL, 0),
(54, 'Comoros', 'Comorian Franc ', 'KMF', NULL, 0, '', NULL, NULL, 0),
(55, 'Congo (the Democratic Republic Of The)', 'Congolese Franc', 'CDF', NULL, 2, '', NULL, NULL, 0),
(56, 'Congo', 'CFA Franc BEAC', 'XAF', NULL, 0, '', NULL, NULL, 0),
(57, 'Cook Islands', 'New Zealand Dollar', 'NZD', NULL, 2, '$', NULL, NULL, 0),
(58, 'Costa Rica', 'Costa Rican Colon', 'CRC', NULL, 2, '', NULL, NULL, 0),
(59, 'Côte D\'ivoire', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(60, 'Croatia', 'Kuna', 'HRK', NULL, 2, 'kn', NULL, NULL, 0),
(61, 'Cuba', 'Cuban Peso', 'CUP', NULL, 2, '', NULL, NULL, 0),
(62, 'Cuba', 'Peso Convertible', 'CUC', NULL, 2, '', NULL, NULL, 0),
(63, 'Curaçao', 'Netherlands Antillean Guilder', 'ANG', NULL, 2, '', NULL, NULL, 0),
(64, 'Cyprus', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(65, 'Czechia', 'Czech Koruna', 'CZK', NULL, 2, 'Kč', NULL, NULL, 0),
(66, 'Denmark', 'Danish Krone', 'DKK', NULL, 2, 'kr', NULL, NULL, 0),
(67, 'Djibouti', 'Djibouti Franc', 'DJF', NULL, 0, '', NULL, NULL, 0),
(68, 'Dominica', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(69, 'Dominican Republic', 'Dominican Peso', 'DOP', NULL, 2, '', NULL, NULL, 0),
(70, 'Ecuador', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(71, 'Egypt', 'Egyptian Pound', 'EGP', NULL, 2, '', NULL, NULL, 0),
(72, 'El Salvador', 'El Salvador Colon', 'SVC', NULL, 2, '', NULL, NULL, 0),
(73, 'El Salvador', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(74, 'Equatorial Guinea', 'CFA Franc BEAC', 'XAF', NULL, 0, '', NULL, NULL, 0),
(75, 'Eritrea', 'Nakfa', 'ERN', NULL, 2, '', NULL, NULL, 0),
(76, 'Estonia', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(77, 'Eswatini', 'Lilangeni', 'SZL', NULL, 2, '', NULL, NULL, 0),
(78, 'Ethiopia', 'Ethiopian Birr', 'ETB', NULL, 2, '', NULL, NULL, 0),
(79, 'European Union', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(80, 'Falkland Islands [Malvinas]', 'Falkland Islands Pound', 'FKP', NULL, 2, '', NULL, NULL, 0),
(81, 'Faroe Islands', 'Danish Krone', 'DKK', NULL, 2, '', NULL, NULL, 0),
(82, 'Fiji', 'Fiji Dollar', 'FJD', NULL, 2, '', NULL, NULL, 0),
(83, 'Finland', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(84, 'France', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(85, 'French Guiana', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(86, 'French Polynesia', 'CFP Franc', 'XPF', NULL, 0, '', NULL, NULL, 0),
(87, 'French Southern Territories', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(88, 'Gabon', 'CFA Franc BEAC', 'XAF', NULL, 0, '', NULL, NULL, 0),
(89, 'Gambia', 'Dalasi', 'GMD', NULL, 2, '', NULL, NULL, 0),
(90, 'Georgia', 'Lari', 'GEL', NULL, 2, '₾', NULL, NULL, 0),
(91, 'Germany', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(92, 'Ghana', 'Ghana Cedi', 'GHS', NULL, 2, '', NULL, NULL, 0),
(93, 'Gibraltar', 'Gibraltar Pound', 'GIP', NULL, 2, '', NULL, NULL, 0),
(94, 'Greece', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(95, 'Greenland', 'Danish Krone', 'DKK', NULL, 2, '', NULL, NULL, 0),
(96, 'Grenada', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(97, 'Guadeloupe', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(98, 'Guam', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(99, 'Guatemala', 'Quetzal', 'GTQ', NULL, 2, '', NULL, NULL, 0),
(100, 'Guernsey', 'Pound Sterling', 'GBP', NULL, 2, '£', NULL, NULL, 0),
(101, 'Guinea', 'Guinean Franc', 'GNF', NULL, 0, '', NULL, NULL, 0),
(102, 'Guinea-bissau', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(103, 'Guyana', 'Guyana Dollar', 'GYD', NULL, 2, '', NULL, NULL, 0),
(104, 'Haiti', 'Gourde', 'HTG', NULL, 2, '', NULL, NULL, 0),
(105, 'Haiti', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(106, 'Heard Island And Mcdonald Islands', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(107, 'Holy See (Vatican)', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(108, 'Honduras', 'Lempira', 'HNL', NULL, 2, '', NULL, NULL, 0),
(109, 'Hong Kong', 'Hong Kong Dollar', 'HKD', NULL, 2, '$', NULL, NULL, 0),
(110, 'Hungary', 'Forint', 'HUF', NULL, 2, 'ft', NULL, NULL, 0),
(111, 'Iceland', 'Iceland Krona', 'ISK', NULL, 0, '', NULL, NULL, 0),
(112, 'India', 'Indian Rupee', 'INR', NULL, 2, '₹', NULL, NULL, 0),
(113, 'Indonesia', 'Rupiah', 'IDR', NULL, 2, 'Rp', NULL, NULL, 0),
(114, 'International Monetary Fund (IMF)', 'SDR (Special Drawing Right)', 'XDR', NULL, 0, '', NULL, NULL, 0),
(115, 'Iran', 'Iranian Rial', 'IRR', NULL, 2, '', NULL, NULL, 0),
(116, 'Iraq', 'Iraqi Dinar', 'IQD', NULL, 3, '', NULL, NULL, 0),
(117, 'Ireland', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(118, 'Isle Of Man', 'Pound Sterling', 'GBP', NULL, 2, '£', NULL, NULL, 0),
(119, 'Israel', 'New Israeli Sheqel', 'ILS', NULL, 2, '₪', NULL, NULL, 0),
(120, 'Italy', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(121, 'Jamaica', 'Jamaican Dollar', 'JMD', NULL, 2, '', NULL, NULL, 0),
(122, 'Japan', 'Yen', 'JPY', NULL, 0, '¥', NULL, NULL, 0),
(123, 'Jersey', 'Pound Sterling', 'GBP', NULL, 2, '£', NULL, NULL, 0),
(124, 'Jordan', 'Jordanian Dinar', 'JOD', NULL, 3, '', NULL, NULL, 0),
(125, 'Kazakhstan', 'Tenge', 'KZT', NULL, 2, '', NULL, NULL, 0),
(126, 'Kenya', 'Kenyan Shilling', 'KES', NULL, 2, 'Ksh', NULL, NULL, 0),
(127, 'Kiribati', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(128, 'Korea (the Democratic People’s Republic Of)', 'North Korean Won', 'KPW', NULL, 2, '', NULL, NULL, 0),
(129, 'Korea (the Republic Of)', 'Won', 'KRW', NULL, 0, '₩', NULL, NULL, 0),
(130, 'Kuwait', 'Kuwaiti Dinar', 'KWD', NULL, 3, '', NULL, NULL, 0),
(131, 'Kyrgyzstan', 'Som', 'KGS', NULL, 2, '', NULL, NULL, 0),
(132, 'Lao People’s Democratic Republic', 'Lao Kip', 'LAK', NULL, 2, '', NULL, NULL, 0),
(133, 'Latvia', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(134, 'Lebanon', 'Lebanese Pound', 'LBP', NULL, 2, '', NULL, NULL, 0),
(135, 'Lesotho', 'Loti', 'LSL', NULL, 2, '', NULL, NULL, 0),
(136, 'Lesotho', 'Rand', 'ZAR', NULL, 2, '', NULL, NULL, 0),
(137, 'Liberia', 'Liberian Dollar', 'LRD', NULL, 2, '', NULL, NULL, 0),
(138, 'Libya', 'Libyan Dinar', 'LYD', NULL, 3, '', NULL, NULL, 0),
(139, 'Liechtenstein', 'Swiss Franc', 'CHF', NULL, 2, '', NULL, NULL, 0),
(140, 'Lithuania', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(141, 'Luxembourg', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(142, 'Macao', 'Pataca', 'MOP', NULL, 2, '', NULL, NULL, 0),
(143, 'North Macedonia', 'Denar', 'MKD', NULL, 2, '', NULL, NULL, 0),
(144, 'Madagascar', 'Malagasy Ariary', 'MGA', NULL, 2, '', NULL, NULL, 0),
(145, 'Malawi', 'Malawi Kwacha', 'MWK', NULL, 2, '', NULL, NULL, 0),
(146, 'Malaysia', 'Malaysian Ringgit', 'MYR', NULL, 2, 'RM', NULL, NULL, 0),
(147, 'Maldives', 'Rufiyaa', 'MVR', NULL, 2, '', NULL, NULL, 0),
(148, 'Mali', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(149, 'Malta', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(150, 'Marshall Islands', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(151, 'Martinique', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(152, 'Mauritania', 'Ouguiya', 'MRU', NULL, 2, '', NULL, NULL, 0),
(153, 'Mauritius', 'Mauritius Rupee', 'MUR', NULL, 2, '', NULL, NULL, 0),
(154, 'Mayotte', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(155, 'Member Countries Of The African Development Bank Group', 'ADB Unit of Account', 'XUA', NULL, 0, '', NULL, NULL, 0),
(156, 'Mexico', 'Mexican Peso', 'MXN', NULL, 2, '$', NULL, NULL, 0),
(157, 'Mexico', 'Mexican Unidad de Inversion (UDI)', 'MXV', NULL, 2, '', NULL, NULL, 0),
(158, 'Micronesia', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(159, 'Moldova', 'Moldovan Leu', 'MDL', NULL, 2, '', NULL, NULL, 0),
(160, 'Monaco', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(161, 'Mongolia', 'Tugrik', 'MNT', NULL, 2, '', NULL, NULL, 0),
(162, 'Montenegro', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(163, 'Montserrat', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(164, 'Morocco', 'Moroccan Dirham', 'MAD', NULL, 2, ' .د.م ', NULL, NULL, 0),
(165, 'Mozambique', 'Mozambique Metical', 'MZN', NULL, 2, '', NULL, NULL, 0),
(166, 'Myanmar', 'Kyat', 'MMK', NULL, 2, '', NULL, NULL, 0),
(167, 'Namibia', 'Namibia Dollar', 'NAD', NULL, 2, '', NULL, NULL, 0),
(168, 'Namibia', 'Rand', 'ZAR', NULL, 2, '', NULL, NULL, 0),
(169, 'Nauru', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(170, 'Nepal', 'Nepalese Rupee', 'NPR', NULL, 2, '', NULL, NULL, 0),
(171, 'Netherlands', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(172, 'New Caledonia', 'CFP Franc', 'XPF', NULL, 0, '', NULL, NULL, 0),
(173, 'New Zealand', 'New Zealand Dollar', 'NZD', NULL, 2, '$', NULL, NULL, 0),
(174, 'Nicaragua', 'Cordoba Oro', 'NIO', NULL, 2, '', NULL, NULL, 0),
(175, 'Niger', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(176, 'Nigeria', 'Naira', 'NGN', NULL, 2, '₦', NULL, NULL, 0),
(177, 'Niue', 'New Zealand Dollar', 'NZD', NULL, 2, '$', NULL, NULL, 0),
(178, 'Norfolk Island', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(179, 'Northern Mariana Islands', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(180, 'Norway', 'Norwegian Krone', 'NOK', NULL, 2, 'kr', NULL, NULL, 0),
(181, 'Oman', 'Rial Omani', 'OMR', NULL, 3, '', NULL, NULL, 0),
(182, 'Pakistan', 'Pakistan Rupee', 'PKR', NULL, 2, 'Rs', NULL, NULL, 0),
(183, 'Palau', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(184, 'Panama', 'Balboa', 'PAB', NULL, 2, '', NULL, NULL, 0),
(185, 'Panama', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(186, 'Papua New Guinea', 'Kina', 'PGK', NULL, 2, '', NULL, NULL, 0),
(187, 'Paraguay', 'Guarani', 'PYG', NULL, 0, '', NULL, NULL, 0),
(188, 'Peru', 'Sol', 'PEN', NULL, 2, 'S', NULL, NULL, 0),
(189, 'Philippines', 'Philippine Peso', 'PHP', NULL, 2, '₱', NULL, NULL, 0),
(190, 'Pitcairn', 'New Zealand Dollar', 'NZD', NULL, 2, '$', NULL, NULL, 0),
(191, 'Poland', 'Zloty', 'PLN', NULL, 2, 'zł', NULL, NULL, 0),
(192, 'Portugal', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(193, 'Puerto Rico', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(194, 'Qatar', 'Qatari Rial', 'QAR', NULL, 2, '', NULL, NULL, 0),
(195, 'Réunion', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(196, 'Romania', 'Romanian Leu', 'RON', NULL, 2, 'lei', NULL, NULL, 0),
(197, 'Russian Federation', 'Russian Ruble', 'RUB', NULL, 2, '₽', NULL, NULL, 0),
(198, 'Rwanda', 'Rwanda Franc', 'RWF', NULL, 0, '', NULL, NULL, 0),
(199, 'Saint Barthélemy', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(200, 'Saint Helena, Ascension And Tristan Da Cunha', 'Saint Helena Pound', 'SHP', NULL, 2, '', NULL, NULL, 0),
(201, 'Saint Kitts And Nevis', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(202, 'Saint Lucia', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(203, 'Saint Martin (French Part)', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(204, 'Saint Pierre And Miquelon', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(205, 'Saint Vincent And The Grenadines', 'East Caribbean Dollar', 'XCD', NULL, 2, '', NULL, NULL, 0),
(206, 'Samoa', 'Tala', 'WST', NULL, 2, '', NULL, NULL, 0),
(207, 'San Marino', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(208, 'Sao Tome And Principe', 'Dobra', 'STN', NULL, 2, '', NULL, NULL, 0),
(209, 'Saudi Arabia', 'Saudi Riyal', 'SAR', NULL, 2, '', NULL, NULL, 0),
(210, 'Senegal', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(211, 'Serbia', 'Serbian Dinar', 'RSD', NULL, 2, '', NULL, NULL, 0),
(212, 'Seychelles', 'Seychelles Rupee', 'SCR', NULL, 2, '', NULL, NULL, 0),
(213, 'Sierra Leone', 'Leone', 'SLL', NULL, 2, '', NULL, NULL, 0),
(214, 'Singapore', 'Singapore Dollar', 'SGD', NULL, 2, '$', NULL, NULL, 0),
(215, 'Sint Maarten (Dutch Part)', 'Netherlands Antillean Guilder', 'ANG', NULL, 2, '', NULL, NULL, 0),
(216, 'Sistema Unitario De Compensacion Regional De Pagos \"sucre\"\"\"', 'Sucre', 'XSU', NULL, 0, '', NULL, NULL, 0),
(217, 'Slovakia', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(218, 'Slovenia', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(219, 'Solomon Islands', 'Solomon Islands Dollar', 'SBD', NULL, 2, '', NULL, NULL, 0),
(220, 'Somalia', 'Somali Shilling', 'SOS', NULL, 2, '', NULL, NULL, 0),
(221, 'South Africa', 'Rand', 'ZAR', NULL, 2, 'R', NULL, NULL, 0),
(222, 'South Sudan', 'South Sudanese Pound', 'SSP', NULL, 2, '', NULL, NULL, 0),
(223, 'Spain', 'Euro', 'EUR', NULL, 2, '€', NULL, NULL, 0),
(224, 'Sri Lanka', 'Sri Lanka Rupee', 'LKR', NULL, 2, 'Rs', NULL, NULL, 0),
(225, 'Sudan (the)', 'Sudanese Pound', 'SDG', NULL, 2, '', NULL, NULL, 0),
(226, 'Suriname', 'Surinam Dollar', 'SRD', NULL, 2, '', NULL, NULL, 0),
(227, 'Svalbard And Jan Mayen', 'Norwegian Krone', 'NOK', NULL, 2, '', NULL, NULL, 0),
(228, 'Sweden', 'Swedish Krona', 'SEK', NULL, 2, 'kr', NULL, NULL, 0),
(229, 'Switzerland', 'Swiss Franc', 'CHF', NULL, 2, '', NULL, NULL, 0),
(230, 'Switzerland', 'WIR Euro', 'CHE', NULL, 2, '', NULL, NULL, 0),
(231, 'Switzerland', 'WIR Franc', 'CHW', NULL, 2, '', NULL, NULL, 0),
(232, 'Syrian Arab Republic', 'Syrian Pound', 'SYP', NULL, 2, '', NULL, NULL, 0),
(233, 'Taiwan', 'New Taiwan Dollar', 'TWD', NULL, 2, '', NULL, NULL, 0),
(234, 'Tajikistan', 'Somoni', 'TJS', NULL, 2, '', NULL, NULL, 0),
(235, 'Tanzania, United Republic Of', 'Tanzanian Shilling', 'TZS', NULL, 2, '', NULL, NULL, 0),
(236, 'Thailand', 'Baht', 'THB', NULL, 2, '฿', NULL, NULL, 0),
(237, 'Timor-leste', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(238, 'Togo', 'CFA Franc BCEAO', 'XOF', NULL, 0, '', NULL, NULL, 0),
(239, 'Tokelau', 'New Zealand Dollar', 'NZD', NULL, 2, '$', NULL, NULL, 0),
(240, 'Tonga', 'Pa’anga', 'TOP', NULL, 2, '', NULL, NULL, 0),
(241, 'Trinidad And Tobago', 'Trinidad and Tobago Dollar', 'TTD', NULL, 2, '', NULL, NULL, 0),
(242, 'Tunisia', 'Tunisian Dinar', 'TND', NULL, 3, '', NULL, NULL, 0),
(243, 'Turkey', 'Turkish Lira', 'TRY', NULL, 2, '₺', NULL, NULL, 0),
(244, 'Turkmenistan', 'Turkmenistan New Manat', 'TMT', NULL, 2, '', NULL, NULL, 0),
(245, 'Turks And Caicos Islands', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(246, 'Tuvalu', 'Australian Dollar', 'AUD', NULL, 2, '', NULL, NULL, 0),
(247, 'Uganda', 'Uganda Shilling', 'UGX', NULL, 0, '', NULL, NULL, 0),
(248, 'Ukraine', 'Hryvnia', 'UAH', NULL, 2, '₴', NULL, NULL, 0),
(249, 'United Arab Emirates', 'UAE Dirham', 'AED', NULL, 2, 'د.إ', NULL, NULL, 0),
(250, 'United Kingdom Of Great Britain And Northern Ireland', 'Pound Sterling', 'GBP', NULL, 2, '£', NULL, NULL, 0),
(251, 'United States Minor Outlying Islands', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(252, 'United States Of America', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(253, 'United States Of America', 'US Dollar (Next day)', 'USN', NULL, 2, '', NULL, NULL, 0),
(254, 'Uruguay', 'Peso Uruguayo', 'UYU', NULL, 2, '', NULL, NULL, 0),
(255, 'Uruguay', 'Uruguay Peso en Unidades Indexadas (UI)', 'UYI', NULL, 0, '', NULL, NULL, 0),
(256, 'Uruguay', 'Unidad Previsional', 'UYW', NULL, 4, '', NULL, NULL, 0),
(257, 'Uzbekistan', 'Uzbekistan Sum', 'UZS', NULL, 2, '', NULL, NULL, 0),
(258, 'Vanuatu', 'Vatu', 'VUV', NULL, 0, '', NULL, NULL, 0),
(259, 'Venezuela', 'Bolívar Soberano', 'VES', NULL, 2, '', NULL, NULL, 0),
(260, 'Vietnam', 'Dong', 'VND', NULL, 0, '₫', NULL, NULL, 0),
(261, 'Virgin Islands (British)', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(262, 'Virgin Islands (U.S.)', 'US Dollar', 'USD', NULL, 2, '$', NULL, NULL, 0),
(263, 'Wallis And Futuna', 'CFP Franc', 'XPF', NULL, 0, '', NULL, NULL, 0),
(264, 'Western Sahara', 'Moroccan Dirham', 'MAD', NULL, 2, '', NULL, NULL, 0),
(265, 'Yemen', 'Yemeni Rial', 'YER', NULL, 2, '', NULL, NULL, 0),
(266, 'Zambia', 'Zambian Kwacha', 'ZMW', NULL, 2, '', NULL, NULL, 0),
(267, 'Zimbabwe', 'Zimbabwe Dollar', 'ZWL', NULL, 2, '', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `division_id` int(11) NOT NULL,
  `district_name` varchar(191) NOT NULL,
  `district_bn_name` varchar(191) NOT NULL,
  `lat` varchar(191) NOT NULL,
  `lon` varchar(191) NOT NULL,
  `website` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `division_id`, `district_name`, `district_bn_name`, `lat`, `lon`, `website`, `created_at`, `updated_at`) VALUES
(1, 3, 'Dhaka', 'ঢাকা', '23.7115253', '90.4111451', 'www.dhaka.gov.bd', NULL, NULL),
(2, 3, 'Faridpur', 'ফরিদপুর', '23.6070822', '89.8429406', 'www.faridpur.gov.bd', NULL, NULL),
(3, 3, 'Gazipur', 'গাজীপুর', '24.0022858', '90.4264283', 'www.gazipur.gov.bd', NULL, NULL),
(4, 3, 'Gopalganj', 'গোপালগঞ্জ', '23.0050857', '89.8266059', 'www.gopalganj.gov.bd', NULL, NULL),
(5, 3, 'Jamalpur', 'জামালপুর', '24.937533', '89.937775', 'www.jamalpur.gov.bd', NULL, NULL),
(6, 3, 'Kishoreganj', 'কিশোরগঞ্জ', '24.444937', '90.776575', 'www.kishoreganj.gov.bd', NULL, NULL),
(7, 3, 'Madaripur', 'মাদারীপুর', '23.164102', '90.1896805', 'www.madaripur.gov.bd', NULL, NULL),
(8, 3, 'Manikganj', 'মানিকগঞ্জ', '0', '0', 'www.manikganj.gov.bd', NULL, NULL),
(9, 3, 'Munshiganj', 'মুন্সিগঞ্জ', '0', '0', 'www.munshiganj.gov.bd', NULL, NULL),
(10, 3, 'Mymensingh', 'ময়মনসিং', '0', '0', 'www.mymensingh.gov.bd', NULL, NULL),
(11, 3, 'Narayanganj', 'নারায়াণগঞ্জ', '23.63366', '90.496482', 'www.narayanganj.gov.bd', NULL, NULL),
(12, 3, 'Narsingdi', 'নরসিংদী', '23.932233', '90.71541', 'www.narsingdi.gov.bd', NULL, NULL),
(13, 3, 'Netrokona', 'নেত্রকোনা', '24.870955', '90.727887', 'www.netrokona.gov.bd', NULL, NULL),
(14, 3, 'Rajbari', 'রাজবাড়ি', '23.7574305', '89.6444665', 'www.rajbari.gov.bd', NULL, NULL),
(15, 3, 'Shariatpur', 'শরীয়তপুর', '0', '0', 'www.shariatpur.gov.bd', NULL, NULL),
(16, 3, 'Sherpur', 'শেরপুর', '25.0204933', '90.0152966', 'www.sherpur.gov.bd', NULL, NULL),
(17, 3, 'Tangail', 'টাঙ্গাইল', '0', '0', 'www.tangail.gov.bd', NULL, NULL),
(18, 5, 'Bogra', 'বগুড়া', '24.8465228', '89.377755', 'www.bogra.gov.bd', NULL, NULL),
(19, 5, 'Joypurhat', 'জয়পুরহাট', '0', '0', 'www.joypurhat.gov.bd', NULL, NULL),
(20, 5, 'Naogaon', 'নওগাঁ', '0', '0', 'www.naogaon.gov.bd', NULL, NULL),
(21, 5, 'Natore', 'নাটোর', '24.420556', '89.000282', 'www.natore.gov.bd', NULL, NULL),
(22, 5, 'Nawabganj', 'নবাবগঞ্জ', '24.5965034', '88.2775122', 'www.chapainawabganj.gov.bd', NULL, NULL),
(23, 5, 'Pabna', 'পাবনা', '23.998524', '89.233645', 'www.pabna.gov.bd', NULL, NULL),
(24, 5, 'Rajshahi', 'রাজশাহী', '0', '0', 'www.rajshahi.gov.bd', NULL, NULL),
(25, 5, 'Sirajgonj', 'সিরাজগঞ্জ', '24.4533978', '89.7006815', 'www.sirajganj.gov.bd', NULL, NULL),
(26, 6, 'Dinajpur', 'দিনাজপুর', '25.6217061', '88.6354504', 'www.dinajpur.gov.bd', NULL, NULL),
(27, 6, 'Gaibandha', 'গাইবান্ধা', '25.328751', '89.528088', 'www.gaibandha.gov.bd', NULL, NULL),
(28, 6, 'Kurigram', 'কুড়িগ্রাম', '25.805445', '89.636174', 'www.kurigram.gov.bd', NULL, NULL),
(29, 6, 'Lalmonirhat', 'লালমনিরহাট', '0', '0', 'www.lalmonirhat.gov.bd', NULL, NULL),
(30, 6, 'Nilphamari', 'নীলফামারী', '25.931794', '88.856006', 'www.nilphamari.gov.bd', NULL, NULL),
(31, 6, 'Panchagarh', 'পঞ্চগড়', '26.3411', '88.5541606', 'www.panchagarh.gov.bd', NULL, NULL),
(32, 6, 'Rangpur', 'রংপুর', '25.7558096', '89.244462', 'www.rangpur.gov.bd', NULL, NULL),
(33, 6, 'Thakurgaon', 'ঠাকুরগাঁও', '26.0336945', '88.4616834', 'www.thakurgaon.gov.bd', NULL, NULL),
(34, 1, 'Barguna', 'বরগুনা', '0', '0', 'www.barguna.gov.bd', NULL, NULL),
(35, 1, 'Barisal', 'বরিশাল', '0', '0', 'www.barisal.gov.bd', NULL, NULL),
(36, 1, 'Bhola', 'ভোলা', '22.685923', '90.648179', 'www.bhola.gov.bd', NULL, NULL),
(37, 1, 'Jhalokati', 'ঝালকাঠি', '0', '0', 'www.jhalakathi.gov.bd', NULL, NULL),
(38, 1, 'Patuakhali', 'পটুয়াখালী', '22.3596316', '90.3298712', 'www.patuakhali.gov.bd', NULL, NULL),
(39, 1, 'Pirojpur', 'পিরোজপুর', '0', '0', 'www.pirojpur.gov.bd', NULL, NULL),
(40, 2, 'Bandarban', 'বান্দরবান', '22.1953275', '92.2183773', 'www.bandarban.gov.bd', NULL, NULL),
(41, 2, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', '23.9570904', '91.1119286', 'www.brahmanbaria.gov.bd', NULL, NULL),
(42, 2, 'Chandpur', 'চাঁদপুর', '23.2332585', '90.6712912', 'www.chandpur.gov.bd', NULL, NULL),
(43, 2, 'Chittagong', 'চট্টগ্রাম', '22.335109', '91.834073', 'www.chittagong.gov.bd', NULL, NULL),
(44, 2, 'Comilla', 'কুমিল্লা', '23.4682747', '91.1788135', 'www.comilla.gov.bd', NULL, NULL),
(45, 2, 'Cox\'s Bazar', 'কক্স বাজার', '0', '0', 'www.coxsbazar.gov.bd', NULL, NULL),
(46, 2, 'Feni', 'ফেনী', '23.023231', '91.3840844', 'www.feni.gov.bd', NULL, NULL),
(47, 2, 'Khagrachari', 'খাগড়াছড়ি', '23.119285', '91.984663', 'www.khagrachhari.gov.bd', NULL, NULL),
(48, 2, 'Lakshmipur', 'লক্ষ্মীপুর', '22.942477', '90.841184', 'www.lakshmipur.gov.bd', NULL, NULL),
(49, 2, 'Noakhali', 'নোয়াখালী', '22.869563', '91.099398', 'www.noakhali.gov.bd', NULL, NULL),
(50, 2, 'Rangamati', 'রাঙ্গামাটি', '0', '0', 'www.rangamati.gov.bd', NULL, NULL),
(51, 7, 'Habiganj', 'হবিগঞ্জ', '24.374945', '91.41553', 'www.habiganj.gov.bd', NULL, NULL),
(52, 7, 'Maulvibazar', 'মৌলভীবাজার', '24.482934', '91.777417', 'www.moulvibazar.gov.bd', NULL, NULL),
(53, 7, 'Sunamganj', 'সুনামগঞ্জ', '25.0658042', '91.3950115', 'www.sunamganj.gov.bd', NULL, NULL),
(54, 7, 'Sylhet', 'সিলেট', '24.8897956', '91.8697894', 'www.sylhet.gov.bd', NULL, NULL),
(55, 4, 'Bagerhat', 'বাগেরহাট', '22.651568', '89.785938', 'www.bagerhat.gov.bd', NULL, NULL),
(56, 4, 'Chuadanga', 'চুয়াডাঙ্গা', '23.6401961', '88.841841', 'www.chuadanga.gov.bd', NULL, NULL),
(57, 4, 'Jessore', 'যশোর', '23.16643', '89.2081126', 'www.jessore.gov.bd', NULL, NULL),
(58, 4, 'Jhenaidah', 'ঝিনাইদহ', '23.5448176', '89.1539213', 'www.jhenaidah.gov.bd', NULL, NULL),
(59, 4, 'Khulna', 'খুলনা', '22.815774', '89.568679', 'www.khulna.gov.bd', NULL, NULL),
(60, 4, 'Kushtia', 'কুষ্টিয়া', '23.901258', '89.120482', 'www.kushtia.gov.bd', NULL, NULL),
(61, 4, 'Magura', 'মাগুরা', '23.487337', '89.419956', 'www.magura.gov.bd', NULL, NULL),
(62, 4, 'Meherpur', 'মেহেরপুর', '23.762213', '88.631821', 'www.meherpur.gov.bd', NULL, NULL),
(63, 4, 'Narail', 'নড়াইল', '23.172534', '89.512672', 'www.narail.gov.bd', NULL, NULL),
(64, 4, 'Satkhira', 'সাতক্ষীরা', '0', '0', 'www.satkhira.gov.bd', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `division_name` varchar(191) NOT NULL,
  `division_bn_name` varchar(191) NOT NULL,
  `country_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `division_name`, `division_bn_name`, `country_id`, `created_at`, `updated_at`) VALUES
(1, 'Barisal', 'বরিশাল', 19, NULL, NULL),
(2, 'Chittagong', 'চট্টগ্রাম', 19, NULL, NULL),
(3, 'Dhaka', 'ঢাকা', 19, NULL, NULL),
(4, 'Khulna', 'খুলনা', 19, NULL, NULL),
(5, 'Rajshahi', 'রাজশাহী', 19, NULL, NULL),
(6, 'Rangpur', 'রংপুর', 19, NULL, NULL),
(7, 'Sylhet', 'সিলেট', 19, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `home_categories`
--

CREATE TABLE `home_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_categories`
--

INSERT INTO `home_categories` (`id`, `category_id`) VALUES
(1, 16),
(2, 19);

-- --------------------------------------------------------

--
-- Table structure for table `htl_bank_information`
--

CREATE TABLE `htl_bank_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_type_id` int(11) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `routing_number` varchar(255) DEFAULT NULL,
  `swift_code` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `htl_bank_infos`
--

CREATE TABLE `htl_bank_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `bank_payment_type_id` int(11) NOT NULL,
  `account_details` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `htl_bookings`
--

CREATE TABLE `htl_bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_bookings`
--

INSERT INTO `htl_bookings` (`id`, `hotel_info_id`, `room_id`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 24, 27, 9, 9, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_booking_information`
--

CREATE TABLE `htl_booking_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoiceNo` int(11) NOT NULL,
  `salesDate` datetime NOT NULL,
  `customerTypeId` int(11) NOT NULL,
  `salesCustomerId` int(11) NOT NULL,
  `currentTotalAmount` double NOT NULL,
  `currentPaidAmount` double NOT NULL,
  `currentDue` double NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_booking_information`
--

INSERT INTO `htl_booking_information` (`id`, `invoiceNo`, `salesDate`, `customerTypeId`, `salesCustomerId`, `currentTotalAmount`, `currentPaidAmount`, `currentDue`, `status`, `company_id`, `create_by`, `update_by`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-02-27 00:00:00', 1, 2, 1400, 0, 1400, 0, 9, 9, NULL, '2023-02-27 13:49:59', NULL),
(2, 2, '2023-02-27 00:00:00', 1, 2, 700, 100, 600, 0, 9, 9, NULL, '2023-02-27 14:51:44', NULL),
(6, 3, '2023-02-27 00:00:00', 1, 2, 500, 100, 400, 0, 9, 9, NULL, '2023-02-27 14:59:26', NULL),
(7, 4, '2023-03-16 00:00:00', 1, 2, 20, 0, 0, 0, 9, 9, NULL, '2023-03-15 20:14:26', NULL),
(8, 5, '2023-03-16 00:00:00', 1, 2, 46, 0, 0, 0, 9, 9, NULL, '2023-03-16 05:00:41', NULL),
(9, 6, '2023-03-16 00:00:00', 1, 2, 12, 0, 0, 0, 9, 9, NULL, '2023-03-16 07:28:35', NULL),
(10, 7, '2023-03-16 00:00:00', 1, 2, 12, 12, 0, 0, 9, 9, NULL, '2023-03-16 08:01:09', NULL),
(11, 8, '2023-03-16 00:00:00', 1, 2, 12, 12, 0, 0, 9, 9, NULL, '2023-03-16 08:46:40', NULL),
(12, 9, '2023-03-19 00:00:00', 1, 2, 170, 170, 0, 0, 9, 9, NULL, '2023-03-19 09:25:49', NULL),
(13, 9, '2023-03-19 00:00:00', 1, 2, 170, 170, 0, 0, 9, 9, NULL, '2023-03-19 09:35:39', NULL),
(14, 9, '2023-03-19 00:00:00', 1, 2, 170, 170, 0, 0, 9, 9, NULL, '2023-03-19 09:36:59', NULL),
(15, 9, '2023-03-19 00:00:00', 1, 2, 170, 170, 0, 0, 9, 9, NULL, '2023-03-19 09:37:38', NULL),
(16, 10, '2023-03-19 00:00:00', 1, 2, 20, 20, 0, 0, 9, 9, NULL, '2023-03-19 10:18:16', NULL),
(17, 11, '2023-03-19 00:00:00', 1, 2, 60, 60, 0, 0, 9, 9, NULL, '2023-03-19 10:19:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_booking_invoice_no_generates`
--

CREATE TABLE `htl_booking_invoice_no_generates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `company_id` int(11) NOT NULL,
  `invoice_no` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_booking_invoice_no_generates`
--

INSERT INTO `htl_booking_invoice_no_generates` (`id`, `company_id`, `invoice_no`, `status`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 9, 1, 1, 9, NULL, NULL, '2023-02-26 06:09:21', NULL, NULL),
(2, 9, 2, 1, 9, 9, NULL, '2023-02-27 14:50:36', '2023-02-27 14:55:33', NULL),
(3, 9, 3, 1, 9, 9, NULL, '2023-02-27 14:55:34', '2023-02-27 14:59:26', NULL),
(4, 9, 4, 1, 9, 9, NULL, '2023-02-27 14:59:29', '2023-03-15 20:14:27', NULL),
(5, 9, 5, 1, 9, 9, NULL, '2023-03-15 20:14:30', '2023-03-16 05:00:41', NULL),
(6, 9, 6, 1, 9, 9, NULL, '2023-03-16 05:00:42', '2023-03-16 07:28:35', NULL),
(7, 9, 7, 1, 9, 9, NULL, '2023-03-16 07:28:39', '2023-03-16 08:01:09', NULL),
(8, 9, 8, 1, 9, 9, NULL, '2023-03-16 08:01:12', '2023-03-16 08:46:40', NULL),
(9, 9, 9, 1, 9, 9, NULL, '2023-03-16 08:46:42', '2023-03-19 09:37:38', NULL),
(10, 9, 10, 1, 9, 9, NULL, '2023-03-19 09:37:39', '2023-03-19 10:18:16', NULL),
(11, 9, 11, 1, 9, 9, NULL, '2023-03-19 10:18:17', '2023-03-19 10:19:04', NULL),
(12, 9, 12, 0, 9, NULL, NULL, '2023-03-19 10:19:05', NULL, NULL),
(13, 15, 1, 0, 15, NULL, NULL, '2023-05-25 08:42:54', NULL, NULL),
(14, 16, 1, 0, 16, NULL, NULL, '2023-06-03 20:10:36', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_booking_product_lists`
--

CREATE TABLE `htl_booking_product_lists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoiceNo` int(11) DEFAULT NULL,
  `hotelId` int(11) NOT NULL,
  `checkIn` datetime NOT NULL,
  `checkOut` datetime NOT NULL,
  `room_type_id` int(11) NOT NULL,
  `bed_type_id` int(11) NOT NULL,
  `adult` int(11) NOT NULL,
  `child` int(11) DEFAULT NULL,
  `noOfRoom` int(11) NOT NULL,
  `extraBed` int(11) DEFAULT NULL,
  `extraBedPrice` int(11) DEFAULT NULL,
  `night` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `totalPrice` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_booking_product_lists`
--

INSERT INTO `htl_booking_product_lists` (`id`, `invoiceNo`, `hotelId`, `checkIn`, `checkOut`, `room_type_id`, `bed_type_id`, `adult`, `child`, `noOfRoom`, `extraBed`, `extraBedPrice`, `night`, `price`, `totalPrice`, `status`, `company_id`, `create_by`, `update_by`, `created_at`, `updated_at`) VALUES
(11, 1, 26, '2023-01-29 00:00:00', '2023-02-07 00:00:00', 2, 9, 1, NULL, 1, 1, 200, 9, 500, 700, 0, 9, 9, NULL, '2023-02-27 13:45:27', NULL),
(12, 1, 26, '2023-01-29 00:00:00', '2023-02-01 00:00:00', 2, 9, 1, NULL, 1, 1, 200, 3, 500, 700, 0, 9, 9, NULL, '2023-02-27 13:48:57', NULL),
(13, 2, 26, '2023-02-01 00:00:00', '2023-02-04 00:00:00', 2, 9, 1, NULL, 1, 1, 200, 3, 500, 700, 1, 9, 9, 9, '2023-02-27 14:51:28', '2023-02-27 14:55:33'),
(14, 3, 26, '2023-01-29 00:00:00', '2023-02-02 00:00:00', 2, 9, 1, NULL, 1, NULL, 200, 4, 500, 500, 1, 9, 9, 9, '2023-02-27 14:59:15', '2023-02-27 14:59:26'),
(15, 8, 26, '2023-03-01 00:00:00', '2023-03-15 00:00:00', 2, 9, 1, 1, 1, 1, 10, 14, 2, 12, 1, 9, 9, NULL, '2023-03-16 08:46:40', NULL),
(16, 9, 26, '2023-03-08 00:00:00', '2023-03-23 00:00:00', 2, 9, 1, 1, 4, 5, 10, 15, 2, 170, 1, 9, 9, NULL, '2023-03-19 09:37:38', NULL),
(17, 10, 26, '2023-03-19 00:00:00', '2023-03-24 00:00:00', 2, 9, 1, 1, 2, 12, 10, 5, 2, 20, 1, 9, 9, NULL, '2023-03-19 10:18:16', NULL),
(18, 11, 26, '2023-03-01 00:00:00', '2023-03-31 00:00:00', 2, 9, 1, NULL, 1, NULL, 10, 30, 2, 60, 1, 9, 9, NULL, '2023-03-19 10:19:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_cancelation_policies`
--

CREATE TABLE `htl_cancelation_policies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cancel_policy_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_cancelation_policies`
--

INSERT INTO `htl_cancelation_policies` (`id`, `cancel_policy_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Non Refundable', 1, 9, 9, 9, NULL, NULL, '2023-02-06 05:46:17', '2023-01-21 12:36:49'),
(2, 'Cancel 1D prior arrival 1N charge, No Show 1N charge', 1, 1, 9, 1, NULL, NULL, '2023-02-08 04:25:05', '2023-01-21 12:36:49'),
(3, 'Cancel 1D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(4, 'Cancel 3D prior arrival 1N charge, No Show 1N charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(5, 'Cancel 3D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(6, 'Cancel 7D prior arrival 1N charge, No Show 1N charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(7, 'Cancel 7D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(8, 'Cancel 14D prior arrival 1N charge, No Show 1N charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(9, 'Cancel 14D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(10, 'Cancel 60D prior arrival 50% charge, 31D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(11, 'Cancel 3D prior arrival 50% charge, 2D prior arrival 75% charge, No Show 1N charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(12, 'Cancel 2D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(13, 'Cancel 2D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(14, 'Cancel 3D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(15, 'Cancel 14D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(16, 'Cancel 5D prior arrival 1N charge, No Show 1N charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(17, 'Cancel 21D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(18, 'Cancel 7D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(19, 'Cancel 1D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(20, 'Cancel 7D prior arrival 50% charge, 1D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(21, 'Cancel 7D prior arrival 25% charge, 3D prior arrival 50% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(22, 'Cancel 15D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(23, 'Cancel 31D prior arrival 1N charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(24, 'Cancel 21D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(25, 'Cancel 3D prior arrival 50% charge, No Show 50% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(26, 'Cancel 4D prior arrival 1D charge, No Show 1D charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(27, 'Cancel 5D prior arrival 50% charge, No Show 50% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(28, 'Cancel 7D prior arrival 30% charge, No Show 30% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(29, 'Cancel 7D prior arrival 50% charge, No Show 50% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(30, 'Cancel 10D prior arrival 1D charge, No Show 1D charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(31, 'Cancel 14D prior arrival 50% charge, No Show 50% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(32, 'Cancel 21D prior arrival 50% charge, No Show 50% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(33, 'Cancel 30D prior arrival 100% charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(34, 'Cancel 2D prior arrival 1D charge, No Show 1D charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(35, 'Cancel 10D prior arrival 1D charge, No Show 100% charge', 1, 9, 9, NULL, NULL, NULL, NULL, '2023-01-21 12:36:49'),
(38, 'c-policy', 1, 9, 9, 9, NULL, '2023-01-28 12:32:33', '2023-02-06 05:49:42', NULL),
(42, 'Update Cancellation Policy', 1, 9, 9, 9, NULL, '2023-02-06 06:37:57', '2023-02-06 06:38:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_contact_information`
--

CREATE TABLE `htl_contact_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `contact_type_id` int(11) NOT NULL,
  `position_type_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_no` varchar(255) DEFAULT NULL,
  `office_phone_no` varchar(255) DEFAULT NULL,
  `extension` varchar(255) DEFAULT NULL,
  `contact_hour_from` time DEFAULT NULL,
  `contact_hour_to` time DEFAULT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_contact_information`
--

INSERT INTO `htl_contact_information` (`id`, `hotel_info_id`, `contact_type_id`, `position_type_id`, `full_name`, `email`, `mobile_no`, `office_phone_no`, `extension`, `contact_hour_from`, `contact_hour_to`, `position`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(20, 24, 1, 1, 'asdfgh', 'dfghj', 'azsxdfg', 'asdf', 'xdcv', '12:12:00', '11:01:00', 1, 1, 9, 9, 9, NULL, '2023-02-09 12:07:14', '2023-02-09 12:07:38', NULL),
(21, 25, 1, 1, 'edrfvgb', 'dcfv', NULL, NULL, NULL, NULL, NULL, 1, 1, 9, 9, 9, NULL, '2023-02-09 12:41:28', '2023-02-09 12:41:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_contact_position_types`
--

CREATE TABLE `htl_contact_position_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `position_type_name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_contact_position_types`
--

INSERT INTO `htl_contact_position_types` (`id`, `position_type_name`, `position`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'General Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(2, 'Hotel Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(3, 'Executive Assistant Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(4, 'Director of Sales and Marketing', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(5, 'Director of Sales', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(6, 'Director of Revenue', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(7, 'Senior Sales Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(8, 'Sales Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(9, 'Assistant Sales Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(10, 'Sales Executive', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(11, 'Front Office Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(12, 'Assistant Front Office Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(13, 'Front Desk Agent', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(14, 'Reservation Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(15, 'Reservation', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(16, 'Ecommerce Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(17, 'Ecommerce Executive', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(18, 'Revenue Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(19, 'Financial Controller', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(20, 'Chief Accountant', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(21, 'Credit Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(22, 'Finance Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(23, 'Account Receivable', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(24, 'Corporate Director of Revenue', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(25, 'Corporate Director of Sales and Marketing', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(26, 'Corporate Director of Ecommerce', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(27, 'Corporate Ecommerce Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(28, 'Corporate Digital Marketing Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(29, 'E-Commerce &amp; Digital Marketing Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(30, 'Regional Revenue Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(31, 'Regional Director of Revenue', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(32, 'Regional Ecommerce Manager', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(33, 'Ecommerce Consultant', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16'),
(34, 'Others', 1, 1, 1, 1, NULL, NULL, NULL, NULL, '2023-01-04 13:49:16');

-- --------------------------------------------------------

--
-- Table structure for table `htl_contact_types`
--

CREATE TABLE `htl_contact_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contact_type_name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_contact_types`
--

INSERT INTO `htl_contact_types` (`id`, `contact_type_name`, `position`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Main Contact', 1, 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-04 13:46:52'),
(2, 'Reservation', 2, 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-04 13:46:52'),
(3, 'Accounts', 1, 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-04 13:46:52'),
(4, 'Manager', 2, 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-04 13:46:52');

-- --------------------------------------------------------

--
-- Table structure for table `htl_customer_information`
--

CREATE TABLE `htl_customer_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customerTypeId` int(11) NOT NULL,
  `accountCode` varchar(50) DEFAULT NULL,
  `customerName` varchar(191) NOT NULL,
  `customerEmail` varchar(191) DEFAULT NULL,
  `customerPhone` varchar(191) NOT NULL,
  `customerImoNumber` varchar(191) DEFAULT NULL,
  `customerFacebookID` varchar(191) DEFAULT NULL,
  `customerAddress` text DEFAULT NULL,
  `referenceName` varchar(191) DEFAULT NULL,
  `referenceEmail` varchar(191) DEFAULT NULL,
  `referencePhone` varchar(191) DEFAULT NULL,
  `customerStatus` varchar(191) NOT NULL DEFAULT '1',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_customer_information`
--

INSERT INTO `htl_customer_information` (`id`, `customerTypeId`, `accountCode`, `customerName`, `customerEmail`, `customerPhone`, `customerImoNumber`, `customerFacebookID`, `customerAddress`, `referenceName`, `referenceEmail`, `referencePhone`, `customerStatus`, `company_id`, `create_by`, `update_by`, `created_at`, `updated_at`) VALUES
(1, 1, '102020101001', 'ew', NULL, '32', NULL, NULL, NULL, NULL, NULL, NULL, '1', 9, 9, NULL, NULL, NULL),
(2, 1, '102020101002', 'Md Nazmul Huda', NULL, '01812454358', NULL, NULL, NULL, NULL, NULL, NULL, '1', 9, 9, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_facilities`
--

CREATE TABLE `htl_facilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `facility_type_id` int(11) NOT NULL,
  `facility_name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_facilities`
--

INSERT INTO `htl_facilities` (`id`, `facility_type_id`, `facility_name`, `position`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(18, 14, 'Conference and meeting', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:18:38', NULL, NULL),
(19, 11, 'Swimming Pool.', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:19:37', NULL, NULL),
(20, 12, 'Spa Facilities.', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:20:19', NULL, NULL),
(21, 10, 'Food & Beverage', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:21:36', NULL, NULL),
(22, 13, 'Fitness', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:27:59', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_facility_masters`
--

CREATE TABLE `htl_facility_masters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `facility_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_facility_masters`
--

INSERT INTO `htl_facility_masters` (`id`, `hotel_info_id`, `facility_id`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(183, 24, 18, 1, 9, 9, NULL, NULL, '2023-02-09 12:07:37', NULL, NULL),
(184, 24, 19, 1, 9, 9, NULL, NULL, '2023-02-09 12:07:37', NULL, NULL),
(185, 24, 20, 1, 9, 9, NULL, NULL, '2023-02-09 12:07:37', NULL, NULL),
(186, 24, 21, 1, 9, 9, NULL, NULL, '2023-02-09 12:07:38', NULL, NULL),
(187, 24, 22, 1, 9, 9, NULL, NULL, '2023-02-09 12:07:38', NULL, NULL),
(188, 25, 18, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(189, 25, 19, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(190, 25, 20, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(191, 25, 21, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(192, 25, 22, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(193, 26, 18, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:04', NULL, NULL),
(194, 26, 19, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:04', NULL, NULL),
(195, 26, 20, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:04', NULL, NULL),
(196, 26, 21, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:04', NULL, NULL),
(197, 26, 22, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:05', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_facility_types`
--

CREATE TABLE `htl_facility_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `facility_type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_facility_types`
--

INSERT INTO `htl_facility_types` (`id`, `facility_type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(10, 'Food & Beverage', 1, 9, 9, NULL, NULL, '2023-02-09 06:12:46', NULL, NULL),
(11, 'Swimming Pool', 1, 9, 9, NULL, NULL, '2023-02-09 06:12:57', NULL, NULL),
(12, 'Spa', 1, 9, 9, NULL, NULL, '2023-02-09 06:13:08', NULL, NULL),
(13, 'Fitness', 1, 9, 9, NULL, NULL, '2023-02-09 06:13:24', NULL, NULL),
(14, 'Conference/Meeting', 1, 9, 9, NULL, NULL, '2023-02-09 06:13:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_images`
--

CREATE TABLE `htl_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `image_title_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_images`
--

INSERT INTO `htl_images` (`id`, `hotel_info_id`, `image_title_id`, `image_path`, `image_name`, `alt_text`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 0, 1, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/hotel_image/', '1678603389.jpeg', 'Hotel Image', 0, 9, 9, NULL, NULL, '2023-03-12 06:43:09', NULL, NULL),
(2, 0, 1, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/hotel_image/', '1678604046.jpeg', 'Hotel Image', 0, 9, 9, NULL, NULL, '2023-03-12 06:54:06', NULL, NULL),
(3, 0, 1, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/hotel_image/', '1678604159.jpeg', 'Hotel Image', 0, 9, 9, NULL, NULL, '2023-03-12 06:56:00', NULL, NULL),
(4, 0, 1, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/hotel_image/', '1678604192.jpeg', 'Hotel Image', 0, 9, 9, NULL, NULL, '2023-03-12 06:56:32', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_image_titles`
--

CREATE TABLE `htl_image_titles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_image_titles`
--

INSERT INTO `htl_image_titles` (`id`, `type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lobby', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-21 17:57:23'),
(2, 'Bed Room', 2, 0, 0, NULL, NULL, NULL, NULL, '2023-01-21 17:57:23'),
(3, 'Bath Room', 2, 0, 0, NULL, NULL, NULL, NULL, '2023-01-21 17:57:23'),
(4, 'Valcuni', 2, 0, 0, NULL, NULL, NULL, NULL, '2023-01-21 17:57:23');

-- --------------------------------------------------------

--
-- Table structure for table `htl_information`
--

CREATE TABLE `htl_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_id` int(11) NOT NULL,
  `hotel_code_serial_no` int(11) NOT NULL,
  `hotel_code` varchar(255) NOT NULL COMMENT 'Formate = H country2char 001 = H BA 001',
  `hotel_name` varchar(255) NOT NULL,
  `property_type_id` int(11) NOT NULL,
  `location_map_url` varchar(255) DEFAULT NULL,
  `street_address` varchar(255) NOT NULL,
  `post_code` varchar(255) NOT NULL,
  `star` int(11) DEFAULT NULL,
  `commission_type` int(11) DEFAULT NULL,
  `commission_amount` double DEFAULT NULL,
  `vat_type` int(11) DEFAULT NULL,
  `vat_amount` int(11) DEFAULT NULL,
  `related_hotel` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_information`
--

INSERT INTO `htl_information` (`id`, `country_id`, `hotel_code_serial_no`, `hotel_code`, `hotel_name`, `property_type_id`, `location_map_url`, `street_address`, `post_code`, `star`, `commission_type`, `commission_amount`, `vat_type`, `vat_amount`, `related_hotel`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(24, 4, 1, 'SHH09230001', 'Hotel One', 10, 'awsedrfgthj', 'asdfhn', 'asxdfn', 5, 1, NULL, 1, NULL, 'asdfghj', 1, 9, 9, NULL, NULL, '2023-02-09 12:07:37', NULL, NULL),
(25, 15, 2, 'SHH09230002', 'Rojonigondha', 6, 'sdcv', 'aszxcv', 'xcv', 5, 1, NULL, 1, NULL, NULL, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(26, 19, 3, 'SHH09230003', 'hotel the cox today', 4, NULL, 'coxsbazar', '1232', 5, 2, 2, 2, 3, NULL, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:04', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_language_information`
--

CREATE TABLE `htl_language_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `language_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_language_information`
--

INSERT INTO `htl_language_information` (`id`, `language_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'English', 1, 9, 9, NULL, NULL, NULL, NULL, NULL),
(2, 'Arabic', 1, 9, 9, NULL, NULL, NULL, NULL, NULL),
(3, 'Thai', 1, 9, 9, NULL, NULL, NULL, NULL, NULL),
(4, 'Bangla', 1, 9, 9, NULL, NULL, NULL, NULL, NULL),
(5, 'Hindi', 1, 9, 9, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_locations`
--

CREATE TABLE `htl_locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `countryId` int(11) NOT NULL,
  `cityName` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `postCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_locations`
--

INSERT INTO `htl_locations` (`id`, `countryId`, `cityName`, `place`, `postCode`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'ds', 'sd', 'sd', 1, 1, 1, NULL, NULL, '2022-12-29 09:24:37', NULL, NULL),
(2, 1, 'sdf', 'sdf', 'sdf', 1, 1, 1, NULL, NULL, '2022-12-29 09:54:56', NULL, NULL),
(3, 19, 'Dhaka', 'Banasree', '1219', 1, 1, 1, NULL, NULL, '2022-12-29 09:55:28', NULL, NULL),
(4, 6, 'dfdfdf', 'ewewweew', '323', 1, 1, 1, NULL, NULL, '2022-12-29 10:05:27', NULL, NULL),
(5, 2, 'dfs', 'fds', 'sfd', 0, 1, 1, NULL, NULL, '2022-12-29 10:05:41', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_meta_information`
--

CREATE TABLE `htl_meta_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_meta_information`
--

INSERT INTO `htl_meta_information` (`id`, `hotel_info_id`, `meta_title`, `meta_keyword`, `meta_description`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(24, 24, 'wedrftgh', 'wsedrf', 'dfgbh', 1, 9, 9, NULL, NULL, '2023-02-09 12:07:38', NULL, NULL),
(25, 25, 'azsx', 'sxdc', 'sxdc', 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(26, 26, NULL, NULL, NULL, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:05', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_payment_types`
--

CREATE TABLE `htl_payment_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payment_type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_payment_types`
--

INSERT INTO `htl_payment_types` (`id`, `payment_type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Bank', 1, 1, 0, 1, NULL, NULL, '2023-02-06 04:54:07', NULL),
(2, 'Card', 1, 0, 0, NULL, NULL, NULL, NULL, NULL),
(5, 'bkash', 1, 9, 9, 9, NULL, '2023-01-28 12:32:08', '2023-02-06 05:25:33', NULL),
(10, 'Credit Card', 1, 9, 9, 9, NULL, '2023-02-06 06:37:27', '2023-02-06 06:37:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_policy_extra_information`
--

CREATE TABLE `htl_policy_extra_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_policy_extra_information`
--

INSERT INTO `htl_policy_extra_information` (`id`, `hotel_info_id`, `title`, `description`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(6, 0, 'kkkjkkkk', 'llllklllll', 0, 9, 9, NULL, NULL, '2023-03-13 18:43:24', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_policy_information`
--

CREATE TABLE `htl_policy_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `check_in_time` time DEFAULT NULL,
  `check_out_time` time DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `policy_terms` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_policy_information`
--

INSERT INTO `htl_policy_information` (`id`, `hotel_info_id`, `check_in_time`, `check_out_time`, `payment_method_id`, `policy_terms`, `position`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(24, 24, '12:12:00', '05:05:00', 1, 'asxfvgbnm', 1, 1, 9, 9, NULL, NULL, '2023-02-09 12:07:38', NULL, NULL),
(25, 25, NULL, NULL, 1, 'swdcfv', 1, 1, 9, 9, NULL, NULL, '2023-02-09 12:41:45', NULL, NULL),
(26, 26, NULL, NULL, NULL, NULL, 1, 1, 9, 9, NULL, NULL, '2023-02-27 07:27:05', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_property_types`
--

CREATE TABLE `htl_property_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `property_type_name` varchar(255) NOT NULL,
  `property_type_description` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_property_types`
--

INSERT INTO `htl_property_types` (`id`, `property_type_name`, `property_type_description`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Hotel', 'Establishment that provides accommodations, meals, and other services for paying guests (travellers, tourists)', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-20 07:01:34'),
(2, 'Hostel', 'Budget accommodation (usually shared-room type) rent by individual travellers (backpackers) or groups', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-20 07:01:35'),
(3, 'Villa', 'Furnished country house located in countryside area that is often rented for vacation purpose', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-20 07:01:35'),
(4, 'Resort', 'A fancy accommodation that is located in a very scenic or sometimes remote location without compromising modern technology and amenities', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-20 07:01:35'),
(5, 'Apartment', 'Serviced apartment complex with hotel-style booking system that enables travellers to stay for a period of time', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-20 07:01:35'),
(6, 'Guest house / B&B', 'An establishment that offers a spare room in private accommodation (e.g. private house, boarding house). It also provides breakfast', 1, 0, 0, NULL, NULL, NULL, NULL, '2023-01-20 07:01:35');

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_bed_types`
--

CREATE TABLE `htl_rom_bed_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bed_type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_bed_types`
--

INSERT INTO `htl_rom_bed_types` (`id`, `bed_type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(9, 'Queen', 1, 9, 9, NULL, NULL, '2023-02-09 06:06:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_facilities`
--

CREATE TABLE `htl_rom_facilities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_facility_type_id` int(11) NOT NULL,
  `room_facility_name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_facilities`
--

INSERT INTO `htl_rom_facilities` (`id`, `room_facility_type_id`, `room_facility_name`, `position`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(8, 9, 'Toiletries', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:23:54', NULL, NULL),
(9, 10, 'Personal care', 1, 1, 9, 9, NULL, NULL, '2023-02-09 06:24:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_facility_types`
--

CREATE TABLE `htl_rom_facility_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_facility_type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_facility_types`
--

INSERT INTO `htl_rom_facility_types` (`id`, `room_facility_type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(9, 'Single', 1, 9, 9, NULL, NULL, '2023-02-09 06:23:16', NULL, NULL),
(10, 'Double', 1, 9, 9, NULL, NULL, '2023-02-09 06:23:30', NULL, NULL),
(11, 'Triple', 1, 9, 9, NULL, NULL, '2023-02-09 06:23:36', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_images`
--

CREATE TABLE `htl_rom_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `image_title_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_images`
--

INSERT INTO `htl_rom_images` (`id`, `hotel_info_id`, `room_id`, `image_title_id`, `image_path`, `image_name`, `alt_text`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(11, 7, 7, 1, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/room_image/', '1675435932.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-02-03 14:52:13', '2023-02-03 14:57:00', NULL),
(12, 8, 1, 3, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/room_image/', '1675510031.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-02-04 11:27:12', '2023-02-04 11:27:52', NULL),
(13, 10, 7, 2, 'E:\\apon\\htdocs\\siyam\\public/images/room_image/', '1675682278.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-02-06 11:17:59', '2023-02-07 10:54:03', NULL),
(35, 17, 25, 3, 'E:\\apon\\htdocs\\siyam\\public/images/room_image/', '1675935306.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-02-09 09:35:06', '2023-02-09 09:35:45', NULL),
(36, 24, 27, 1, 'E:\\apon\\htdocs\\siyam\\public/images/room_image/', '1675944512.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-02-09 12:08:32', '2023-02-09 12:08:45', NULL),
(40, 0, 0, 1, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/room_image/', '1678595021.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-03-12 04:23:41', NULL, NULL),
(41, 0, 0, 2, 'D:\\xampp\\htdocs\\siyamholidays\\public/images/room_image/', '1678595050.jpeg', 'Room Image', 0, 9, 9, NULL, NULL, '2023-03-12 04:24:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_information`
--

CREATE TABLE `htl_rom_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `room_type_id` int(11) NOT NULL,
  `room_title` longtext NOT NULL,
  `bed_type_id` int(11) NOT NULL,
  `room_description` longtext DEFAULT NULL,
  `cancellation_policy` longtext DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `minimum_stay` int(11) DEFAULT NULL,
  `free_breakfast_status` int(11) DEFAULT NULL,
  `max_adult` int(11) DEFAULT NULL,
  `re_schedule_status` int(11) DEFAULT NULL,
  `max_child` int(11) DEFAULT NULL,
  `child_age` int(11) DEFAULT NULL,
  `no_of_extra_bed` int(11) DEFAULT NULL,
  `extra_bed_payment_status` int(11) DEFAULT NULL,
  `extra_bed_charge` int(11) DEFAULT NULL,
  `extra_bed_charge_status` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_information`
--

INSERT INTO `htl_rom_information` (`id`, `hotel_info_id`, `room_type_id`, `room_title`, `bed_type_id`, `room_description`, `cancellation_policy`, `quantity`, `minimum_stay`, `free_breakfast_status`, `max_adult`, `re_schedule_status`, `max_child`, `child_age`, `no_of_extra_bed`, `extra_bed_payment_status`, `extra_bed_charge`, `extra_bed_charge_status`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 26, 2, 'hyjiuuhjj', 9, 'yjyhjjk', NULL, 1, 2, NULL, 3, NULL, 4, 8, 9, NULL, 10, NULL, 0, 9, 9, NULL, NULL, '2023-03-14 12:47:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_price_types`
--

CREATE TABLE `htl_rom_price_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_price_type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_price_types`
--

INSERT INTO `htl_rom_price_types` (`id`, `room_price_type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'All Date', 0, 0, 0, NULL, NULL, NULL, NULL, '2023-01-14 15:40:19'),
(2, 'Fixed Date', 0, 0, 0, NULL, NULL, NULL, NULL, '2023-01-14 15:40:19');

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_pricings`
--

CREATE TABLE `htl_rom_pricings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `room_id` int(11) DEFAULT NULL,
  `room_type_id` int(11) NOT NULL,
  `bed_type_id` int(11) NOT NULL,
  `day_price_type_id` int(11) NOT NULL,
  `fixed_date_from` varchar(55) DEFAULT NULL,
  `fixed_date_to` varchar(55) DEFAULT NULL,
  `agent_price` double NOT NULL,
  `vendor_price` double NOT NULL,
  `customer_price` double NOT NULL,
  `showing_price` double NOT NULL,
  `currency_id` int(11) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_pricings`
--

INSERT INTO `htl_rom_pricings` (`id`, `hotel_info_id`, `room_id`, `room_type_id`, `bed_type_id`, `day_price_type_id`, `fixed_date_from`, `fixed_date_to`, `agent_price`, `vendor_price`, `customer_price`, `showing_price`, `currency_id`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 26, 1, 2, 9, 1, NULL, NULL, 3, 1, 2, 4, 0, 0, 9, 9, NULL, NULL, '2023-03-14 12:44:42', '2023-03-14 12:47:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_rom_types`
--

CREATE TABLE `htl_rom_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `room_type_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_rom_types`
--

INSERT INTO `htl_rom_types` (`id`, `room_type_name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Deluxe Rooms', 1, 9, 9, 9, NULL, '2023-01-01 05:48:10', '2023-02-09 06:05:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_room_facility_masters`
--

CREATE TABLE `htl_room_facility_masters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `room_facility_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_room_facility_masters`
--

INSERT INTO `htl_room_facility_masters` (`id`, `hotel_id`, `room_id`, `room_facility_id`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 10, 5, 1, 1, 9, 9, NULL, NULL, '2023-02-06 12:18:35', NULL, NULL),
(2, 10, 5, 5, 1, 9, 9, NULL, NULL, '2023-02-06 12:18:35', NULL, NULL),
(3, 4, 6, 1, 1, 9, 9, NULL, NULL, '2023-02-07 05:17:24', NULL, NULL),
(4, 4, 6, 6, 1, 9, 9, NULL, NULL, '2023-02-07 05:17:24', NULL, NULL),
(5, 10, 7, 4, 1, 9, 9, NULL, NULL, '2023-02-07 10:54:03', NULL, NULL),
(6, 10, 7, 5, 1, 9, 9, NULL, NULL, '2023-02-07 10:54:03', NULL, NULL),
(7, 10, 7, 6, 1, 9, 9, NULL, NULL, '2023-02-07 10:54:03', NULL, NULL),
(8, 10, 7, 7, 1, 9, 9, NULL, NULL, '2023-02-07 10:54:03', NULL, NULL),
(37, 13, 15, 1, 1, 9, 9, NULL, NULL, '2023-02-08 07:34:51', NULL, NULL),
(38, 13, 15, 4, 1, 9, 9, NULL, NULL, '2023-02-08 07:34:51', NULL, NULL),
(39, 13, 15, 5, 1, 9, 9, NULL, NULL, '2023-02-08 07:34:51', NULL, NULL),
(40, 13, 15, 6, 1, 9, 9, NULL, NULL, '2023-02-08 07:34:51', NULL, NULL),
(41, 13, 15, 7, 1, 9, 9, NULL, NULL, '2023-02-08 07:34:51', NULL, NULL),
(116, 17, 25, 8, 1, 9, 9, NULL, NULL, '2023-02-09 09:35:45', NULL, NULL),
(117, 24, 27, 8, 1, 9, 9, NULL, NULL, '2023-02-09 12:08:45', NULL, NULL),
(118, 24, 27, 9, 1, 9, 9, NULL, NULL, '2023-02-09 12:08:45', NULL, NULL),
(123, 26, 1, 8, 1, 9, 9, NULL, NULL, '2023-03-14 12:47:14', NULL, NULL),
(124, 26, 1, 9, 1, 9, 9, NULL, NULL, '2023-03-14 12:47:14', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_settings_generals`
--

CREATE TABLE `htl_settings_generals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `target` varchar(255) NOT NULL,
  `header_title` varchar(255) NOT NULL,
  `home_featured_hotel` int(11) NOT NULL,
  `home_featured_hotel_display_order` int(11) NOT NULL,
  `listing_hotels` int(11) NOT NULL,
  `listing_hotels_display_order` int(11) NOT NULL,
  `search_result_hotel` int(11) NOT NULL,
  `search_result_hotel_display_order` int(11) NOT NULL,
  `related_hotels` int(11) NOT NULL,
  `search_min_price` double NOT NULL,
  `search_max_price` double NOT NULL,
  `check_in_time` varchar(55) NOT NULL,
  `check_out_time` varchar(55) NOT NULL,
  `meta_keyword` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_settings_generals`
--

INSERT INTO `htl_settings_generals` (`id`, `target`, `header_title`, `home_featured_hotel`, `home_featured_hotel_display_order`, `listing_hotels`, `listing_hotels_display_order`, `search_result_hotel`, `search_result_hotel_display_order`, `related_hotels`, `search_min_price`, `search_max_price`, `check_in_time`, `check_out_time`, `meta_keyword`, `meta_description`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, '_self', 'Hotel Listing', 6, 1, 6, 1, 20, 1, 10, 1000, 5000, '11:50:23', '12:50:23', 'Meta Keyword', 'Meta Description', 0, 9, 9, NULL, NULL, '2023-01-28 15:50:41', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_settings_general_order_bies`
--

CREATE TABLE `htl_settings_general_order_bies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_settings_general_order_bies`
--

INSERT INTO `htl_settings_general_order_bies` (`id`, `name`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'By Latest First', 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(2, 'By Oldest First', 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(3, 'Ascending Order (A-Z)', 0, 0, 0, NULL, NULL, NULL, NULL, NULL),
(4, 'Descending  Order (Z-A)', 0, 0, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `htl_translate_information`
--

CREATE TABLE `htl_translate_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hotel_info_id` int(11) NOT NULL,
  `language_id` int(11) DEFAULT NULL,
  `hotel_name` varchar(255) DEFAULT NULL,
  `hotel_description` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL COMMENT '0=inactive, 1=active',
  `company_id` int(11) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) DEFAULT NULL,
  `delete_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htl_translate_information`
--

INSERT INTO `htl_translate_information` (`id`, `hotel_info_id`, `language_id`, `hotel_name`, `hotel_description`, `meta_title`, `meta_keyword`, `meta_description`, `status`, `company_id`, `create_by`, `update_by`, `delete_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(49, 24, 1, 'dfvgbhnjm', 'sxdcfgvbh', 'sdfgbhnj', 'asdfgbhn', 'azsxdcfvgb', 0, 9, 9, 9, NULL, '2023-02-09 12:07:34', '2023-02-09 12:07:38', NULL),
(50, 24, 1, 'werftgyh', 'wsdcfv', 'sxdcfv', 'sxdc v', 'azsxc', 0, 9, 9, NULL, NULL, '2023-02-09 12:08:42', NULL, NULL),
(51, 25, 2, 'sdcfv', 'dcfv', 'xdcf v', 'sxdc', 'szx c', 0, 9, 9, 9, NULL, '2023-02-09 12:41:42', '2023-02-09 12:41:45', NULL),
(52, 25, 1, 'wed', 'dcfv', 'dcf', 'sxdc', 'sxdc', 0, 9, 9, NULL, NULL, '2023-02-09 12:42:50', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_02_03_045618_create_brand_entries_table', 1),
(5, '2020_02_03_063049_create_admin_types_table', 1),
(6, '2020_02_03_090508_create_admin_sub_menus_table', 1),
(7, '2020_02_03_090730_create_admin_menus_table', 1),
(8, '2020_02_03_100621_create_admin_menu_permissions_table', 1),
(9, '2020_02_05_164421_create_admin_entries_table', 1),
(10, '2020_02_05_175229_create_admin_setups_table', 1),
(12, '2020_02_13_153156_create_bank_entries_table', 1),
(14, '2020_02_15_102600_create_shop_customer_type_entries_table', 1),
(15, '2020_02_15_113621_create_admin_bussiness_types_table', 1),
(16, '2020_02_15_153841_create_commission_type_entries_table', 1),
(17, '2020_02_15_163930_create_admin_holiday_types_table', 1),
(19, '2020_02_16_100426_create_adminlicence_types_table', 1),
(20, '2020_02_16_111531_create_admin_meta_key_descriptions_table', 1),
(21, '2020_03_03_182955_create_shop_menu_permissions_table', 1),
(22, '2020_03_08_120334_create_shop_loan_provider_entries_table', 1),
(23, '2020_03_08_170427_create_shop_loan_entries_table', 1),
(24, '2020_03_09_120607_create_shop_expence_type_entries_table', 1),
(25, '2020_03_09_150634_create_shop_income_type_entries_table', 1),
(26, '2020_03_09_180509_create_shop_employee_login_time_entries_table', 1),
(28, '2020_03_15_152314_create_shop_add_income_types_table', 1),
(30, '2020_03_21_174828_create_admin_purchase_types_table', 1),
(32, '2020_03_21_195710_create_product_names_table', 1),
(34, '2020_03_26_173752_create_product_price_setup_details_table', 1),
(35, '2020_04_06_163655_create_grade_entries_table', 1),
(36, '2020_04_15_142827_create_admin_name_of_institutes_table', 1),
(37, '2020_04_15_142908_create_admin_name_of_degrees_table', 1),
(38, '2020_04_15_142925_create_admin_grades_table', 1),
(39, '2020_04_15_142949_create_admin_skill_grades_table', 1),
(40, '2020_04_16_165452_create_employee_education_entries_table', 1),
(41, '2020_04_16_173239_create_employee_professional_entries_table', 1),
(42, '2020_04_16_175112_create_employee_skill_entries_table', 1),
(43, '2020_04_16_192416_create_employee_banking_entries_table', 1),
(44, '2020_04_18_185504_create_salary_grade_setups_table', 1),
(45, '2020_03_02_152213_create_shop_employee_types_table', 1),
(46, '2020_02_16_095356_create_job_department_entries_table', 1),
(47, '2020_06_27_170923_create_employee_leave_entries_table', 1),
(48, '2020_06_29_103652_create_employee_attendances_table', 1),
(49, '2020_07_04_120134_create_asset_code_entries_table', 1),
(52, '2020_07_08_224919_create_asset_statuses_table', 1),
(54, '2020_07_14_122004_create_purchase_product_total_quantities_table', 1),
(57, '2021_03_03_160420_create_admin_menu_title_name1s_table', 1),
(58, '2021_03_03_194018_create_company_logos_table', 1),
(59, '2021_03_05_214750_create_websites_table', 1),
(60, '2021_03_06_093402_create_website_infos_table', 1),
(61, '2021_03_06_172359_create_vendors_table', 1),
(62, '2021_03_06_201553_create_purchase_types_table', 1),
(63, '2021_03_07_122915_create_basic_infos_table', 1),
(64, '2021_03_07_123325_create_religiouses_table', 1),
(65, '2021_03_08_170156_create_qr_code_setups_table', 1),
(66, '2021_03_09_110312_create_invoice_for_type_lists_table', 1),
(67, '2021_03_09_125342_create_invoice_type_lists_table', 1),
(69, '2021_03_12_215830_create_invoice_setups_table', 1),
(70, '2021_03_30_151502_create_divisions_table', 1),
(71, '2021_03_30_153536_create_districts_table', 1),
(72, '2021_03_31_111242_create_upazilas_table', 1),
(74, '2021_03_31_111613_create_wards_table', 1),
(75, '2021_03_30_151355_create_countries_table', 1),
(77, '2021_04_02_212604_create_shop_information_table', 1),
(78, '2020_02_09_193833_create_admin_menu_title_names_table', 1),
(79, '2021_04_05_142658_create_shops_table', 1),
(81, '2021_04_09_175423_create_branch_information_table', 1),
(82, '2021_03_24_134624_create_shop_owner_information_table', 1),
(83, '2021_04_03_000408_create_shop_contact_person_information_table', 1),
(84, '2021_04_03_004116_create_shop_representative_information_table', 1),
(85, '2021_04_03_012254_create_shop_address_locations_table', 1),
(86, '2021_04_11_213716_create_shop_statuses_table', 1),
(87, '2021_04_11_225024_create_shop_payment_statuses_table', 1),
(89, '2021_04_12_142738_create_shop_account_intormations_table', 1),
(90, '2021_04_13_004559_create_currencies_table', 1),
(91, '2021_04_17_100207_create_shop_billing_grace_information_table', 1),
(92, '2020_07_11_171219_create_purchase_product_more_fields_table', 1),
(93, '2021_04_25_112753_create_chart_of_accounts_table', 1),
(94, '2021_04_25_225940_create_account_groups_table', 1),
(95, '2021_04_26_104415_create_chart_of_account_group_types_table', 1),
(96, '2021_04_29_073309_create_voucher_types_table', 1),
(97, '2021_04_29_114640_create_account_setup_head_lists_table', 1),
(98, '2021_04_29_114846_create_account_setup_placement_lists_table', 1),
(99, '2021_04_29_113901_create_account_setups_table', 1),
(100, '2021_05_04_163551_create_grace_date_entries_table', 1),
(101, '2021_05_05_141024_create_trainings_table', 1),
(102, '2021_05_06_170646_create_expire_date_notifications_table', 1),
(103, '2021_05_08_145346_create_catagories_table', 1),
(104, '2021_06_06_164401_create_price_setup_histories_table', 1),
(105, '2021_06_08_142421_create_product_low_quantities_table', 1),
(109, '2021_06_15_132733_create_sales_price_types_table', 1),
(112, '2021_06_17_125212_create_vat_setups_table', 1),
(114, '2021_06_17_171407_create_due_limit_setups_table', 1),
(116, '2021_05_07_232053_create_receive_payment_statements_table', 1),
(117, '2021_06_29_140937_create_tmp_opening_vouchers_table', 1),
(118, '2020_02_13_150905_create_bank_type_entries_table', 1),
(119, '2020_03_09_094942_create_shop_add_bank_entries_table', 1),
(120, '2021_07_02_190131_create_corporate_bank_types_table', 1),
(121, '2021_07_02_191948_create_mobile_bank_types_table', 1),
(122, '2021_07_02_222944_create_loan_provider_types_table', 1),
(123, '2021_07_03_212651_create_loan_interest_types_table', 1),
(124, '2021_07_03_213812_create_loan_interest_time_types_table', 1),
(125, '2021_07_03_221805_create_loan_pay_types_table', 1),
(126, '2021_07_04_203523_create_payment_types_table', 1),
(136, '2021_07_17_030029_create_income_expense_bill_payment_receives_table', 1),
(144, '2021_07_30_063644_create_advance_payments_table', 1),
(149, '2021_08_05_034345_create_chart_of_account_balances_table', 1),
(152, '2021_08_06_204356_create_chart_of_account_relations_table', 1),
(153, '2021_08_06_211958_create_relation_table_lists_table', 1),
(154, '2021_08_06_212750_create_relation_table_head_lists_table', 1),
(155, '2020_04_04_113741_create_shop_asset_categories_table', 1),
(162, '2020_02_15_183557_create_admin_holiday_setups_table', 1),
(196, '2021_08_19_152656_create_price_type_setups_table', 1),
(199, '2021_08_22_152353_create_product_expire_date_soons_table', 1),
(205, '2021_08_24_103953_create_sales_payments_table', 1),
(206, '2020_07_26_181559_create_sales_invoices_table', 1),
(209, '2021_08_24_134946_create_sales_invoice_temps_table', 1),
(247, '2020_03_02_191519_create_shop_employee_entries_table', 1),
(259, '2021_09_09_112728_create_supplier_payments_table', 1),
(263, '2021_08_24_124046_create_chart_of_account_registers_table', 1),
(264, '2021_07_11_034741_create_expense_provider_entries_table', 1),
(265, '2021_08_27_035709_create_expense_information_entry_logs_table', 1),
(266, '2021_07_12_020702_create_expense_information_entries_table', 1),
(267, '2021_07_11_210755_create_expense_details_items_table', 1),
(268, '2021_08_03_182225_create_expense_budgets_table', 1),
(269, '2021_07_09_213257_create_expence_types_table', 1),
(272, '2021_07_13_152153_create_income_details_items_table', 1),
(273, '2021_07_16_065432_create_income_expense_statement_information_table', 1),
(274, '2021_07_13_160329_create_income_information_entries_table', 1),
(276, '2021_07_10_020924_create_income_types_table', 1),
(277, '2021_07_10_214014_create_income_provider_entries_table', 1),
(280, '2021_08_26_224649_create_income_provider_entry_logs_table', 1),
(281, '2021_08_26_165747_create_expense_provider_entry_logs_table', 1),
(282, '2021_07_02_235111_create_loan_provider_entries_table', 1),
(285, '2021_07_06_014052_create_loan_provider_installment_histories_table', 1),
(287, '2021_07_08_161336_create_loan_reveiver_installment_histories_table', 1),
(288, '2021_07_30_052123_create_security_money_table', 1),
(289, '2021_08_30_012422_create_bill_payment_receives_table', 1),
(291, '2020_02_13_115001_create_unite_entries_table', 1),
(292, '2020_02_17_161955_create_product_brand_entries_table', 1),
(293, '2020_03_08_160800_create_shop_add_asset_supplier_entries_table', 1),
(296, '2020_03_12_114805_create_categories_table', 1),
(299, '2021_08_01_011411_create_security_money_withdraw_or_adjustments_table', 1),
(300, '2020_06_26_171056_create_start_salary_setups_table', 1),
(301, '2021_08_17_145605_create_salary_sheets_table', 1),
(303, '2020_07_14_175224_create_purchase_product_total_prices_table', 1),
(304, '2021_05_01_121723_create_voucher_information_table', 1),
(305, '2021_05_01_122532_create_voucher_information_reports_table', 1),
(308, '2021_10_05_131919_create_sales_settings_table', 1),
(309, '2021_10_06_161449_create_stock_summery_temps_table', 1),
(317, '2021_10_09_111559_create_cheque_types_table', 1),
(321, '2021_10_09_132705_create_cheque_statuses_table', 1),
(325, '2021_10_07_141233_create_bank_checks_table', 1),
(326, '2021_10_07_153443_create_bank_check_details_table', 1),
(327, '2021_10_09_113440_create_cheque_postings_table', 1),
(328, '2021_06_12_160205_create_purchase_return_histories_table', 1),
(329, '2021_08_18_123821_create_salary_pays_table', 1),
(330, '2021_10_21_124842_create_admin_reffer_temps_table', 1),
(332, '2021_09_05_150527_create_admin_temps_table', 1),
(333, '2021_10_23_104227_create_admin_open_temps_table', 1),
(334, '2021_10_23_132459_create_regi_phones_table', 1),
(335, '2021_04_07_114506_create_admins_table', 1),
(336, '2020_02_13_155043_create_asset_brand_entries_table', 1),
(340, '2021_03_12_224758_create_invoice_setup_details_table', 1),
(341, '2021_11_08_150903_create_billing_information_table', 1),
(342, '2021_11_09_112612_create_billing_details_infos_table', 1),
(343, '2021_08_30_002947_create_statement_information_table', 1),
(345, '2021_11_25_183249_create_asset_status_lists_table', 1),
(346, '2020_03_08_111707_create_add_product_supplier_entries_table', 1),
(348, '2020_07_11_151012_create_purchase_product_details_table', 1),
(350, '2021_12_01_214359_create_demo_link_codes_table', 1),
(353, '2020_02_15_124421_create_shop_type_entries_table', 1),
(354, '2021_12_02_114841_create_demo_user_lists_table', 1),
(355, '2021_12_04_121120_create_demo_user_email_mobile_histories_table', 1),
(356, '2020_03_22_123533_create_purchase_invoices_table', 1),
(359, '2021_12_07_113031_create_user_login_histories_table', 1),
(360, '2021_11_25_144737_create_asset_status_histories_table', 1),
(361, '2021_03_31_111443_create_unions_table', 1),
(364, '2021_12_14_204010_create_discount_type_entries_table', 1),
(365, '2021_12_14_210745_create_discount_type_by_shops_table', 1),
(368, '2021_12_25_231034_create_invoice_no_generates_table', 1),
(373, '2020_07_22_163558_create_sales_customer_entries_table', 1),
(377, '2021_12_29_163043_create_shop_bill_month_lists_table', 1),
(378, '2022_01_02_114759_create_company_bank_accounts_table', 1),
(383, '2021_12_29_121537_create_shop_billing_requests_table', 1),
(384, '2022_01_02_115251_create_company_bank_information_table', 1),
(385, '2021_07_04_160346_create_provider_loan_receive_entries_table', 1),
(386, '2021_07_08_141740_create_receiver_loan_pays_table', 1),
(387, '2022_01_06_140517_create_warehouse_information_table', 1),
(410, '2021_10_05_110256_create_stock_summeries_table', 1),
(412, '2022_01_07_160344_create_product_colors_table', 1),
(413, '2022_01_07_164821_create_product_sizes_table', 1),
(414, '2022_02-05_190131_create_bank_card_types_table', 1),
(415, '2022_03_22_120012_create_product_barcode_information_table', 1),
(417, '2022_04_04_012001_create_sales_product_discount_date_information_table', 1),
(419, '2020_07_18_132048_create_sales_product_discount_price_entries_table', 1),
(420, '2022_04_15_202329_create_shop_price_type_configures_table', 1),
(421, '2022_04_18_232407_create_loan_provider_installment_history_details_table', 1),
(422, '2022_04_19_113720_create_loan_receiver_installment_history_details_table', 1),
(429, '2022_04_26_213454_create_sales_return_invoice_tmps_table', 1),
(430, '2021_04_12_135904_create_shop_billing_amounts_table', 1),
(441, '2020_07_15_193338_create_sales_product_price_entries_table', 1),
(443, '2022_05_19_091606_create_sales_product_price_entry_histories_table', 1),
(444, '2022_04_24_104428_create_purchase_return_invoice_tmps_table', 1),
(445, '2021_07_10_140934_create_income_expense_companies_table', 1),
(448, '2021_08_03_151946_create_income_targets_table', 1),
(450, '2022_04_26_175004_create_sales_return_product_list_tmps_table', 1),
(453, '2020_03_22_124356_create_purchase_product_entries_table', 1),
(454, '2022_04_23_035721_create_purchase_return_product_list_tmps_table', 1),
(459, '2022_05_10_103735_create_purchase_product_unit_infos_table', 1),
(460, '2022_05_19_093221_create_purchase_product_unit_info_histories_table', 1),
(461, '2022_05_31_121956_create_purchase_invoice_unit_infos_table', 1),
(462, '2022_06_04_143036_create_purchase_return_invoice_unit_infos_table', 1),
(463, '2022_06_12_030847_create_sales_return_invoice_unit_infos_table', 1),
(465, '2020_07_25_171317_create_sales_product_entries_table', 1),
(466, '2021_12_26_222113_create_s_r_information_table', 1),
(488, '2020_07_04_154302_create_asset_code_entries_table', 1),
(489, '2020_07_04_185904_create_shop_asset_entries_table', 1),
(490, '2022_07_02_184108_create_user_details_table', 1),
(491, '2022_07_15_211736_create_dealer_sales_orders_table', 1),
(492, '2022_07_16_121234_create_dealer_sales_order_submits_table', 1),
(494, '2022_07_22_085803_create_dealer_sales_order_receive_submits_table', 1),
(496, '2022_07_29_213248_create_dealer_sales_supplier_search_infos_table', 1),
(498, '2022_12_27_171723_create_htl_property_types_table', 7),
(500, '2022_12_29_132731_create_htl_locations_table', 7),
(501, '2022_12_31_131100_create_htl_facility_types_table', 7),
(502, '2022_12_31_140957_create_htl_facilities_table', 7),
(503, '2022_12_31_150433_create_htl_cancelation_policies_table', 7),
(507, '2023_01_01_112626_create_htl_rom_types_table', 7),
(508, '2023_01_01_120320_create_htl_rom_bed_types_table', 7),
(509, '2023_01_01_124018_create_htl_rom_facility_types_table', 7),
(511, '2023_01_01_130650_create_htl_rom_facilities_table', 7),
(516, '2023_01_04_145321_create_htl_bank_infos_table', 7),
(517, '2023_01_04_183315_create_htl_contact_types_table', 7),
(518, '2023_01_04_184347_create_htl_contact_position_types_table', 7),
(530, '2023_01_14_144027_create_htl_rom_price_types_table', 7),
(535, '2023_01_21_220621_create_htl_image_titles_table', 7),
(536, '2023_01_11_112139_create_htl_rom_images_table', 6),
(538, '2023_01_22_151114_create_htl_payment_types_table', 7),
(540, '2023_01_23_230559_create_product_categories_table', 1),
(541, '2023_01_23_231408_create_home_categories_table', 1),
(542, '2023_01_26_121330_create_htl_settings_general_order_bies_table', 7),
(544, '2023_01_26_121849_create_htl_settings_generals_table', 7),
(547, '2022_12_31_155849_create_htl_information_table', 8),
(548, '2023_01_03_145335_create_htl_meta_information_table', 8),
(549, '2023_01_03_155322_create_htl_policy_information_table', 8),
(551, '2023_01_04_210200_create_htl_translate_information_table', 8),
(552, '2023_01_04_214107_create_htl_language_information_table', 8),
(553, '2023_01_05_135956_create_htl_facility_masters_table', 8),
(554, '2023_01_22_153621_create_htl_bank_information_table', 8),
(557, '2023_01_04_191801_create_htl_contact_information_table', 10),
(559, '2023_02_06_173313_create_htl_room_facility_masters_table', 12),
(560, '2023_02_08_173603_create_htl_bookings_table', 13),
(561, '2023_02_25_144822_create_htl_booking_invoice_no_generates_table', 14),
(562, '2023_02_26_125705_create_htl_customer_information_table', 15),
(564, '2023_02_26_230339_create_htl_booking_product_lists_table', 16),
(565, '2023_02_27_190047_create_htl_booking_information_table', 17),
(566, '2023_03_12_120714_create_htl_images_table', 18),
(568, '2023_03_13_133651_create_htl_policy_extra_information_table', 19),
(569, '2023_01_15_152659_create_htl_rom_information_table', 20),
(570, '2023_01_15_120252_create_htl_rom_pricings_table', 21);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('doofaz@gmail.com', '$2y$10$2mj/XX5obV07RjDGCNjhTu6UaX80yvv9TF/wYN2V7hNuBzxOhAawy', '2021-10-17 12:02:55');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `productNameId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `createby` int(11) NOT NULL,
  `updateby` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `productNameId`, `categoryId`, `createby`, `updateby`, `created_at`, `updated_at`) VALUES
(143, 4, 16, 0, 0, '2021-05-05 16:26:31', '2021-05-05 16:26:31'),
(144, 4, 17, 0, 0, '2021-05-05 16:26:31', '2021-05-05 16:26:31'),
(145, 5, 16, 0, 0, '2021-05-05 16:35:43', '2021-05-05 16:35:43'),
(146, 5, 17, 0, 0, '2021-05-05 16:35:43', '2021-05-05 16:35:43'),
(147, 6, 16, 0, 0, '2021-05-05 16:40:03', '2021-05-05 16:40:03'),
(148, 6, 18, 0, 0, '2021-05-05 16:40:03', '2021-05-05 16:40:03'),
(149, 6, 19, 0, 0, '2021-05-05 16:40:03', '2021-05-05 16:40:03'),
(150, 7, 16, 0, 0, '2021-05-05 16:44:05', '2021-05-05 16:44:05'),
(151, 7, 18, 0, 0, '2021-05-05 16:44:05', '2021-05-05 16:44:05'),
(152, 7, 19, 0, 0, '2021-05-05 16:44:05', '2021-05-05 16:44:05'),
(153, 8, 16, 0, 0, '2021-05-05 16:47:24', '2021-05-05 16:47:24'),
(154, 8, 18, 0, 0, '2021-05-05 16:47:24', '2021-05-05 16:47:24'),
(155, 8, 20, 0, 0, '2021-05-05 16:47:24', '2021-05-05 16:47:24'),
(156, 9, 16, 0, 0, '2021-05-05 16:51:07', '2021-05-05 16:51:07'),
(157, 9, 18, 0, 0, '2021-05-05 16:51:07', '2021-05-05 16:51:07'),
(158, 9, 20, 0, 0, '2021-05-05 16:51:07', '2021-05-05 16:51:07'),
(159, 10, 16, 0, 0, '2021-05-05 16:52:32', '2021-05-05 16:52:32'),
(160, 10, 105, 0, 0, '2021-05-05 16:52:32', '2021-05-05 16:52:32'),
(161, 11, 16, 0, 0, '2021-05-05 16:56:11', '2021-05-05 16:56:11'),
(162, 11, 105, 0, 0, '2021-05-05 16:56:11', '2021-05-05 16:56:11'),
(163, 12, 16, 0, 0, '2021-05-05 17:02:28', '2021-05-05 17:02:28'),
(164, 12, 21, 0, 0, '2021-05-05 17:02:28', '2021-05-05 17:02:28'),
(165, 12, 167, 0, 0, '2021-05-05 17:02:28', '2021-05-05 17:02:28'),
(166, 13, 16, 0, 0, '2021-05-05 17:06:42', '2021-05-05 17:06:42'),
(167, 13, 21, 0, 0, '2021-05-05 17:06:42', '2021-05-05 17:06:42'),
(168, 13, 22, 0, 0, '2021-05-05 17:06:42', '2021-05-05 17:06:42'),
(169, 14, 16, 0, 0, '2021-05-05 17:09:17', '2021-05-05 17:09:17'),
(170, 14, 21, 0, 0, '2021-05-05 17:09:17', '2021-05-05 17:09:17'),
(171, 14, 23, 0, 0, '2021-05-05 17:09:17', '2021-05-05 17:09:17'),
(172, 15, 16, 0, 0, '2021-05-05 17:12:23', '2021-05-05 17:12:23'),
(173, 15, 106, 0, 0, '2021-05-05 17:12:23', '2021-05-05 17:12:23'),
(174, 16, 16, 0, 0, '2021-05-05 17:13:47', '2021-05-05 17:13:47'),
(175, 16, 107, 0, 0, '2021-05-05 17:13:47', '2021-05-05 17:13:47'),
(176, 17, 16, 0, 0, '2021-05-05 17:15:26', '2021-05-05 17:15:26'),
(177, 17, 108, 0, 0, '2021-05-05 17:15:26', '2021-05-05 17:15:26'),
(178, 18, 24, 0, 0, '2021-05-05 17:17:00', '2021-05-05 17:17:00'),
(179, 18, 25, 0, 0, '2021-05-05 17:17:00', '2021-05-05 17:17:00'),
(180, 18, 26, 0, 0, '2021-05-05 17:17:00', '2021-05-05 17:17:00'),
(181, 19, 24, 0, 0, '2021-05-05 17:19:07', '2021-05-05 17:19:07'),
(182, 19, 25, 0, 0, '2021-05-05 17:19:07', '2021-05-05 17:19:07'),
(183, 19, 27, 0, 0, '2021-05-05 17:19:07', '2021-05-05 17:19:07'),
(184, 20, 24, 0, 0, '2021-05-05 17:20:27', '2021-05-05 17:20:27'),
(185, 20, 40, 0, 0, '2021-05-05 17:20:27', '2021-05-05 17:20:27'),
(186, 20, 41, 0, 0, '2021-05-05 17:20:27', '2021-05-05 17:20:27'),
(187, 21, 24, 0, 0, '2021-05-05 17:22:25', '2021-05-05 17:22:25'),
(188, 21, 40, 0, 0, '2021-05-05 17:22:25', '2021-05-05 17:22:25'),
(189, 21, 42, 0, 0, '2021-05-05 17:22:25', '2021-05-05 17:22:25'),
(190, 22, 24, 0, 0, '2021-05-05 17:24:03', '2021-05-05 17:24:03'),
(191, 22, 40, 0, 0, '2021-05-05 17:24:03', '2021-05-05 17:24:03'),
(192, 22, 43, 0, 0, '2021-05-05 17:24:03', '2021-05-05 17:24:03'),
(193, 23, 24, 0, 0, '2021-05-05 17:25:21', '2021-05-05 17:25:21'),
(194, 23, 40, 0, 0, '2021-05-05 17:25:21', '2021-05-05 17:25:21'),
(195, 23, 44, 0, 0, '2021-05-05 17:25:21', '2021-05-05 17:25:21'),
(196, 24, 24, 0, 0, '2021-05-05 17:26:47', '2021-05-05 17:26:47'),
(197, 24, 45, 0, 0, '2021-05-05 17:26:47', '2021-05-05 17:26:47'),
(198, 24, 46, 0, 0, '2021-05-05 17:26:47', '2021-05-05 17:26:47'),
(199, 25, 24, 0, 0, '2021-05-05 17:28:27', '2021-05-05 17:28:27'),
(200, 25, 45, 0, 0, '2021-05-05 17:28:27', '2021-05-05 17:28:27'),
(201, 25, 47, 0, 0, '2021-05-05 17:28:27', '2021-05-05 17:28:27'),
(202, 26, 24, 0, 0, '2021-05-05 17:29:46', '2021-05-05 17:29:46'),
(203, 26, 45, 0, 0, '2021-05-05 17:29:46', '2021-05-05 17:29:46'),
(204, 26, 48, 0, 0, '2021-05-05 17:29:46', '2021-05-05 17:29:46'),
(205, 27, 24, 0, 0, '2021-05-05 17:31:02', '2021-05-05 17:31:02'),
(206, 27, 45, 0, 0, '2021-05-05 17:31:02', '2021-05-05 17:31:02'),
(207, 27, 49, 0, 0, '2021-05-05 17:31:02', '2021-05-05 17:31:02'),
(208, 28, 24, 0, 0, '2021-05-05 17:32:24', '2021-05-05 17:32:24'),
(209, 28, 45, 0, 0, '2021-05-05 17:32:24', '2021-05-05 17:32:24'),
(210, 28, 50, 0, 0, '2021-05-05 17:32:24', '2021-05-05 17:32:24'),
(211, 29, 24, 0, 0, '2021-05-05 17:37:01', '2021-05-05 17:37:01'),
(212, 29, 45, 0, 0, '2021-05-05 17:37:01', '2021-05-05 17:37:01'),
(213, 29, 51, 0, 0, '2021-05-05 17:37:01', '2021-05-05 17:37:01'),
(214, 30, 24, 0, 0, '2021-05-05 17:39:05', '2021-05-05 17:39:05'),
(215, 30, 52, 0, 0, '2021-05-05 17:39:05', '2021-05-05 17:39:05'),
(216, 30, 53, 0, 0, '2021-05-05 17:39:05', '2021-05-05 17:39:05'),
(217, 31, 24, 0, 0, '2021-05-05 17:41:08', '2021-05-05 17:41:08'),
(218, 31, 52, 0, 0, '2021-05-05 17:41:08', '2021-05-05 17:41:08'),
(219, 31, 54, 0, 0, '2021-05-05 17:41:09', '2021-05-05 17:41:09'),
(220, 32, 24, 0, 0, '2021-05-05 17:43:14', '2021-05-05 17:43:14'),
(221, 32, 52, 0, 0, '2021-05-05 17:43:14', '2021-05-05 17:43:14'),
(222, 32, 55, 0, 0, '2021-05-05 17:43:14', '2021-05-05 17:43:14'),
(223, 33, 24, 0, 0, '2021-05-05 17:45:06', '2021-05-05 17:45:06'),
(224, 33, 52, 0, 0, '2021-05-05 17:45:06', '2021-05-05 17:45:06'),
(225, 33, 56, 0, 0, '2021-05-05 17:45:06', '2021-05-05 17:45:06'),
(226, 34, 24, 0, 0, '2021-05-05 17:47:10', '2021-05-05 17:47:10'),
(227, 34, 57, 0, 0, '2021-05-05 17:47:10', '2021-05-05 17:47:10'),
(228, 34, 58, 0, 0, '2021-05-05 17:47:10', '2021-05-05 17:47:10'),
(229, 35, 24, 0, 0, '2021-05-05 17:48:31', '2021-05-05 17:48:31'),
(230, 35, 57, 0, 0, '2021-05-05 17:48:31', '2021-05-05 17:48:31'),
(231, 35, 59, 0, 0, '2021-05-05 17:48:31', '2021-05-05 17:48:31'),
(232, 36, 24, 0, 0, '2021-05-05 17:50:51', '2021-05-05 17:50:51'),
(233, 36, 57, 0, 0, '2021-05-05 17:50:51', '2021-05-05 17:50:51'),
(234, 36, 60, 0, 0, '2021-05-05 17:50:51', '2021-05-05 17:50:51'),
(235, 37, 24, 0, 0, '2021-05-05 17:53:14', '2021-05-05 17:53:14'),
(236, 37, 57, 0, 0, '2021-05-05 17:53:14', '2021-05-05 17:53:14'),
(237, 37, 61, 0, 0, '2021-05-05 17:53:14', '2021-05-05 17:53:14'),
(238, 38, 24, 0, 0, '2021-05-05 17:54:53', '2021-05-05 17:54:53'),
(239, 38, 57, 0, 0, '2021-05-05 17:54:53', '2021-05-05 17:54:53'),
(240, 38, 62, 0, 0, '2021-05-05 17:54:53', '2021-05-05 17:54:53'),
(241, 39, 24, 0, 0, '2021-05-05 17:55:59', '2021-05-05 17:55:59'),
(242, 39, 57, 0, 0, '2021-05-05 17:55:59', '2021-05-05 17:55:59'),
(243, 39, 63, 0, 0, '2021-05-05 17:55:59', '2021-05-05 17:55:59'),
(244, 40, 24, 0, 0, '2021-05-05 17:57:27', '2021-05-05 17:57:27'),
(245, 40, 57, 0, 0, '2021-05-05 17:57:27', '2021-05-05 17:57:27'),
(246, 40, 64, 0, 0, '2021-05-05 17:57:27', '2021-05-05 17:57:27'),
(247, 41, 24, 0, 0, '2021-05-05 17:59:06', '2021-05-05 17:59:06'),
(248, 41, 57, 0, 0, '2021-05-05 17:59:06', '2021-05-05 17:59:06'),
(249, 41, 65, 0, 0, '2021-05-05 17:59:06', '2021-05-05 17:59:06'),
(250, 42, 24, 0, 0, '2021-05-05 18:01:46', '2021-05-05 18:01:46'),
(251, 42, 57, 0, 0, '2021-05-05 18:01:46', '2021-05-05 18:01:46'),
(252, 42, 66, 0, 0, '2021-05-05 18:01:46', '2021-05-05 18:01:46'),
(253, 43, 24, 0, 0, '2021-05-05 18:03:40', '2021-05-05 18:03:40'),
(254, 43, 57, 0, 0, '2021-05-05 18:03:40', '2021-05-05 18:03:40'),
(255, 43, 67, 0, 0, '2021-05-05 18:03:40', '2021-05-05 18:03:40'),
(256, 44, 24, 0, 0, '2021-05-05 18:05:09', '2021-05-05 18:05:09'),
(257, 44, 68, 0, 0, '2021-05-05 18:05:09', '2021-05-05 18:05:09'),
(258, 44, 69, 0, 0, '2021-05-05 18:05:09', '2021-05-05 18:05:09'),
(259, 45, 24, 0, 0, '2021-05-05 18:06:51', '2021-05-05 18:06:51'),
(260, 45, 68, 0, 0, '2021-05-05 18:06:51', '2021-05-05 18:06:51'),
(261, 45, 70, 0, 0, '2021-05-05 18:06:51', '2021-05-05 18:06:51'),
(262, 46, 24, 0, 0, '2021-05-05 18:08:03', '2021-05-05 18:08:03'),
(263, 46, 68, 0, 0, '2021-05-05 18:08:03', '2021-05-05 18:08:03'),
(264, 46, 71, 0, 0, '2021-05-05 18:08:03', '2021-05-05 18:08:03'),
(265, 47, 24, 0, 0, '2021-05-05 18:09:14', '2021-05-05 18:09:14'),
(266, 47, 68, 0, 0, '2021-05-05 18:09:14', '2021-05-05 18:09:14'),
(267, 47, 72, 0, 0, '2021-05-05 18:09:14', '2021-05-05 18:09:14'),
(268, 48, 24, 0, 0, '2021-05-05 18:11:06', '2021-05-05 18:11:06'),
(269, 48, 68, 0, 0, '2021-05-05 18:11:06', '2021-05-05 18:11:06'),
(270, 48, 73, 0, 0, '2021-05-05 18:11:06', '2021-05-05 18:11:06'),
(271, 49, 24, 0, 0, '2021-05-05 18:12:26', '2021-05-05 18:12:26'),
(272, 49, 68, 0, 0, '2021-05-05 18:12:26', '2021-05-05 18:12:26'),
(273, 49, 74, 0, 0, '2021-05-05 18:12:26', '2021-05-05 18:12:26'),
(274, 50, 24, 0, 0, '2021-05-05 18:13:59', '2021-05-05 18:13:59'),
(275, 50, 75, 0, 0, '2021-05-05 18:13:59', '2021-05-05 18:13:59'),
(276, 50, 76, 0, 0, '2021-05-05 18:13:59', '2021-05-05 18:13:59'),
(277, 51, 24, 0, 0, '2021-05-05 18:15:06', '2021-05-05 18:15:06'),
(278, 51, 75, 0, 0, '2021-05-05 18:15:06', '2021-05-05 18:15:06'),
(279, 51, 77, 0, 0, '2021-05-05 18:15:06', '2021-05-05 18:15:06'),
(280, 52, 24, 0, 0, '2021-05-05 18:16:23', '2021-05-05 18:16:23'),
(281, 52, 78, 0, 0, '2021-05-05 18:16:23', '2021-05-05 18:16:23'),
(282, 52, 79, 0, 0, '2021-05-05 18:16:23', '2021-05-05 18:16:23'),
(283, 53, 24, 0, 0, '2021-05-05 18:17:26', '2021-05-05 18:17:26'),
(284, 53, 78, 0, 0, '2021-05-05 18:17:26', '2021-05-05 18:17:26'),
(285, 53, 80, 0, 0, '2021-05-05 18:17:27', '2021-05-05 18:17:27'),
(286, 54, 24, 0, 0, '2021-05-05 18:18:16', '2021-05-05 18:18:16'),
(287, 54, 78, 0, 0, '2021-05-05 18:18:16', '2021-05-05 18:18:16'),
(288, 54, 81, 0, 0, '2021-05-05 18:18:16', '2021-05-05 18:18:16'),
(289, 55, 24, 0, 0, '2021-05-05 18:19:24', '2021-05-05 18:19:24'),
(290, 55, 78, 0, 0, '2021-05-05 18:19:24', '2021-05-05 18:19:24'),
(291, 55, 82, 0, 0, '2021-05-05 18:19:24', '2021-05-05 18:19:24'),
(292, 56, 24, 0, 0, '2021-05-05 18:20:51', '2021-05-05 18:20:51'),
(293, 56, 78, 0, 0, '2021-05-05 18:20:51', '2021-05-05 18:20:51'),
(294, 56, 83, 0, 0, '2021-05-05 18:20:51', '2021-05-05 18:20:51'),
(295, 57, 24, 0, 0, '2021-05-05 18:22:51', '2021-05-05 18:22:51'),
(296, 57, 78, 0, 0, '2021-05-05 18:22:51', '2021-05-05 18:22:51'),
(297, 57, 84, 0, 0, '2021-05-05 18:22:51', '2021-05-05 18:22:51'),
(298, 58, 24, 0, 0, '2021-05-05 18:24:22', '2021-05-05 18:24:22'),
(299, 58, 85, 0, 0, '2021-05-05 18:24:22', '2021-05-05 18:24:22'),
(300, 58, 86, 0, 0, '2021-05-05 18:24:22', '2021-05-05 18:24:22'),
(301, 59, 24, 0, 0, '2021-05-05 18:25:43', '2021-05-05 18:25:43'),
(302, 59, 85, 0, 0, '2021-05-05 18:25:43', '2021-05-05 18:25:43'),
(303, 59, 87, 0, 0, '2021-05-05 18:25:43', '2021-05-05 18:25:43'),
(304, 60, 24, 0, 0, '2021-05-05 18:27:05', '2021-05-05 18:27:05'),
(305, 60, 78, 0, 0, '2021-05-05 18:27:05', '2021-05-05 18:27:05'),
(306, 60, 88, 0, 0, '2021-05-05 18:27:05', '2021-05-05 18:27:05'),
(307, 61, 24, 0, 0, '2021-05-05 18:28:54', '2021-05-05 18:28:54'),
(308, 61, 85, 0, 0, '2021-05-05 18:28:54', '2021-05-05 18:28:54'),
(309, 61, 89, 0, 0, '2021-05-05 18:28:54', '2021-05-05 18:28:54'),
(310, 62, 24, 0, 0, '2021-05-05 19:05:03', '2021-05-05 19:05:03'),
(311, 62, 85, 0, 0, '2021-05-05 19:05:03', '2021-05-05 19:05:03'),
(312, 62, 90, 0, 0, '2021-05-05 19:05:03', '2021-05-05 19:05:03'),
(313, 63, 24, 0, 0, '2021-05-05 19:06:19', '2021-05-05 19:06:19'),
(314, 63, 91, 0, 0, '2021-05-05 19:06:19', '2021-05-05 19:06:19'),
(315, 63, 92, 0, 0, '2021-05-05 19:06:19', '2021-05-05 19:06:19'),
(316, 64, 24, 0, 0, '2021-05-05 19:07:28', '2021-05-05 19:07:28'),
(317, 64, 91, 0, 0, '2021-05-05 19:07:28', '2021-05-05 19:07:28'),
(318, 64, 93, 0, 0, '2021-05-05 19:07:28', '2021-05-05 19:07:28'),
(319, 65, 24, 0, 0, '2021-05-05 19:08:39', '2021-05-05 19:08:39'),
(320, 65, 91, 0, 0, '2021-05-05 19:08:39', '2021-05-05 19:08:39'),
(321, 65, 94, 0, 0, '2021-05-05 19:08:39', '2021-05-05 19:08:39'),
(322, 66, 24, 0, 0, '2021-05-05 19:09:36', '2021-05-05 19:09:36'),
(323, 66, 91, 0, 0, '2021-05-05 19:09:36', '2021-05-05 19:09:36'),
(324, 66, 95, 0, 0, '2021-05-05 19:09:36', '2021-05-05 19:09:36'),
(325, 67, 24, 0, 0, '2021-05-05 19:10:32', '2021-05-05 19:10:32'),
(326, 67, 91, 0, 0, '2021-05-05 19:10:32', '2021-05-05 19:10:32'),
(327, 67, 96, 0, 0, '2021-05-05 19:10:32', '2021-05-05 19:10:32'),
(328, 68, 24, 0, 0, '2021-05-05 19:11:40', '2021-05-05 19:11:40'),
(329, 68, 91, 0, 0, '2021-05-05 19:11:40', '2021-05-05 19:11:40'),
(330, 68, 97, 0, 0, '2021-05-05 19:11:40', '2021-05-05 19:11:40'),
(331, 69, 24, 0, 0, '2021-05-05 19:12:37', '2021-05-05 19:12:37'),
(332, 69, 91, 0, 0, '2021-05-05 19:12:37', '2021-05-05 19:12:37'),
(333, 69, 98, 0, 0, '2021-05-05 19:12:37', '2021-05-05 19:12:37'),
(334, 70, 24, 0, 0, '2021-05-05 19:13:29', '2021-05-05 19:13:29'),
(335, 70, 91, 0, 0, '2021-05-05 19:13:29', '2021-05-05 19:13:29'),
(336, 70, 99, 0, 0, '2021-05-05 19:13:29', '2021-05-05 19:13:29'),
(337, 71, 24, 0, 0, '2021-05-05 19:14:29', '2021-05-05 19:14:29'),
(338, 71, 91, 0, 0, '2021-05-05 19:14:29', '2021-05-05 19:14:29'),
(339, 71, 100, 0, 0, '2021-05-05 19:14:29', '2021-05-05 19:14:29'),
(340, 72, 24, 0, 0, '2021-05-05 19:15:29', '2021-05-05 19:15:29'),
(341, 72, 91, 0, 0, '2021-05-05 19:15:29', '2021-05-05 19:15:29'),
(342, 72, 101, 0, 0, '2021-05-05 19:15:29', '2021-05-05 19:15:29'),
(343, 73, 24, 0, 0, '2021-05-05 19:16:18', '2021-05-05 19:16:18'),
(344, 73, 91, 0, 0, '2021-05-05 19:16:18', '2021-05-05 19:16:18'),
(345, 73, 102, 0, 0, '2021-05-05 19:16:18', '2021-05-05 19:16:18'),
(346, 74, 24, 0, 0, '2021-05-05 19:18:00', '2021-05-05 19:18:00'),
(347, 74, 104, 0, 0, '2021-05-05 19:18:00', '2021-05-05 19:18:00'),
(348, 75, 166, 0, 0, '2021-05-05 19:19:51', '2021-05-05 19:19:51'),
(349, 76, 162, 0, 0, '2021-05-05 19:20:37', '2021-05-05 19:20:37'),
(350, 76, 163, 0, 0, '2021-05-05 19:20:37', '2021-05-05 19:20:37'),
(351, 77, 162, 0, 0, '2021-05-05 19:21:20', '2021-05-05 19:21:20'),
(352, 77, 164, 0, 0, '2021-05-05 19:21:20', '2021-05-05 19:21:20'),
(353, 78, 162, 0, 0, '2021-05-05 19:22:10', '2021-05-05 19:22:10'),
(354, 78, 165, 0, 0, '2021-05-05 19:22:10', '2021-05-05 19:22:10'),
(355, 79, 128, 0, 0, '2021-05-05 19:23:17', '2021-05-05 19:23:17'),
(356, 79, 129, 0, 0, '2021-05-05 19:23:17', '2021-05-05 19:23:17'),
(357, 79, 130, 0, 0, '2021-05-05 19:23:17', '2021-05-05 19:23:17'),
(358, 80, 128, 0, 0, '2021-05-05 19:24:06', '2021-05-05 19:24:06'),
(359, 80, 129, 0, 0, '2021-05-05 19:24:06', '2021-05-05 19:24:06'),
(360, 80, 131, 0, 0, '2021-05-05 19:24:06', '2021-05-05 19:24:06'),
(361, 81, 128, 0, 0, '2021-05-05 19:24:56', '2021-05-05 19:24:56'),
(362, 81, 129, 0, 0, '2021-05-05 19:24:56', '2021-05-05 19:24:56'),
(363, 81, 132, 0, 0, '2021-05-05 19:24:56', '2021-05-05 19:24:56'),
(364, 82, 128, 0, 0, '2021-05-05 19:26:33', '2021-05-05 19:26:33'),
(365, 82, 129, 0, 0, '2021-05-05 19:26:33', '2021-05-05 19:26:33'),
(366, 82, 133, 0, 0, '2021-05-05 19:26:33', '2021-05-05 19:26:33'),
(367, 83, 128, 0, 0, '2021-05-05 19:27:34', '2021-05-05 19:27:34'),
(368, 83, 129, 0, 0, '2021-05-05 19:27:34', '2021-05-05 19:27:34'),
(369, 83, 134, 0, 0, '2021-05-05 19:27:34', '2021-05-05 19:27:34'),
(370, 84, 128, 0, 0, '2021-05-05 19:29:00', '2021-05-05 19:29:00'),
(371, 84, 129, 0, 0, '2021-05-05 19:29:00', '2021-05-05 19:29:00'),
(372, 84, 135, 0, 0, '2021-05-05 19:29:00', '2021-05-05 19:29:00'),
(373, 85, 128, 0, 0, '2021-05-05 19:30:05', '2021-05-05 19:30:05'),
(374, 85, 129, 0, 0, '2021-05-05 19:30:05', '2021-05-05 19:30:05'),
(375, 85, 136, 0, 0, '2021-05-05 19:30:05', '2021-05-05 19:30:05'),
(376, 86, 128, 0, 0, '2021-05-05 19:31:08', '2021-05-05 19:31:08'),
(377, 86, 137, 0, 0, '2021-05-05 19:31:08', '2021-05-05 19:31:08'),
(378, 86, 138, 0, 0, '2021-05-05 19:31:08', '2021-05-05 19:31:08'),
(379, 87, 128, 0, 0, '2021-05-05 19:32:17', '2021-05-05 19:32:17'),
(380, 87, 137, 0, 0, '2021-05-05 19:32:17', '2021-05-05 19:32:17'),
(381, 87, 139, 0, 0, '2021-05-05 19:32:17', '2021-05-05 19:32:17'),
(382, 88, 128, 0, 0, '2021-05-05 19:34:11', '2021-05-05 19:34:11'),
(383, 88, 137, 0, 0, '2021-05-05 19:34:11', '2021-05-05 19:34:11'),
(384, 88, 139, 0, 0, '2021-05-05 19:34:11', '2021-05-05 19:34:11'),
(385, 89, 128, 0, 0, '2021-05-05 19:35:30', '2021-05-05 19:35:30'),
(386, 89, 137, 0, 0, '2021-05-05 19:35:30', '2021-05-05 19:35:30'),
(387, 89, 147, 0, 0, '2021-05-05 19:35:30', '2021-05-05 19:35:30'),
(388, 90, 128, 0, 0, '2021-05-05 19:36:44', '2021-05-05 19:36:44'),
(389, 90, 137, 0, 0, '2021-05-05 19:36:44', '2021-05-05 19:36:44'),
(390, 90, 156, 0, 0, '2021-05-05 19:36:44', '2021-05-05 19:36:44'),
(391, 91, 128, 0, 0, '2021-05-05 19:37:39', '2021-05-05 19:37:39'),
(392, 91, 137, 0, 0, '2021-05-05 19:37:39', '2021-05-05 19:37:39'),
(393, 91, 157, 0, 0, '2021-05-05 19:37:39', '2021-05-05 19:37:39'),
(394, 92, 128, 0, 0, '2021-05-05 19:38:30', '2021-05-05 19:38:30'),
(395, 92, 137, 0, 0, '2021-05-05 19:38:30', '2021-05-05 19:38:30'),
(396, 92, 158, 0, 0, '2021-05-05 19:38:30', '2021-05-05 19:38:30'),
(397, 93, 128, 0, 0, '2021-05-05 19:39:19', '2021-05-05 19:39:19'),
(398, 93, 137, 0, 0, '2021-05-05 19:39:19', '2021-05-05 19:39:19'),
(399, 93, 159, 0, 0, '2021-05-05 19:39:19', '2021-05-05 19:39:19'),
(400, 94, 128, 0, 0, '2021-05-05 19:40:09', '2021-05-05 19:40:09'),
(401, 94, 137, 0, 0, '2021-05-05 19:40:09', '2021-05-05 19:40:09'),
(402, 94, 160, 0, 0, '2021-05-05 19:40:09', '2021-05-05 19:40:09'),
(403, 95, 128, 0, 0, '2021-05-05 19:41:06', '2021-05-05 19:41:06'),
(404, 95, 137, 0, 0, '2021-05-05 19:41:06', '2021-05-05 19:41:06'),
(405, 95, 161, 0, 0, '2021-05-05 19:41:06', '2021-05-05 19:41:06'),
(406, 96, 109, 0, 0, '2021-05-05 19:42:17', '2021-05-05 19:42:17'),
(407, 97, 110, 0, 0, '2021-05-05 19:43:17', '2021-05-05 19:43:17'),
(408, 97, 111, 0, 0, '2021-05-05 19:43:17', '2021-05-05 19:43:17'),
(409, 98, 110, 0, 0, '2021-05-05 19:44:10', '2021-05-05 19:44:10'),
(410, 98, 112, 0, 0, '2021-05-05 19:44:10', '2021-05-05 19:44:10'),
(411, 98, 113, 0, 0, '2021-05-05 19:44:10', '2021-05-05 19:44:10'),
(412, 99, 110, 0, 0, '2021-05-05 19:45:18', '2021-05-05 19:45:18'),
(413, 99, 112, 0, 0, '2021-05-05 19:45:18', '2021-05-05 19:45:18'),
(414, 99, 114, 0, 0, '2021-05-05 19:45:18', '2021-05-05 19:45:18'),
(415, 100, 110, 0, 0, '2021-05-05 19:46:32', '2021-05-05 19:46:32'),
(416, 100, 112, 0, 0, '2021-05-05 19:46:32', '2021-05-05 19:46:32'),
(417, 100, 115, 0, 0, '2021-05-05 19:46:32', '2021-05-05 19:46:32'),
(418, 101, 28, 0, 0, '2021-05-05 19:47:44', '2021-05-05 19:47:44'),
(419, 101, 29, 0, 0, '2021-05-05 19:47:44', '2021-05-05 19:47:44'),
(420, 102, 28, 0, 0, '2021-05-05 19:48:51', '2021-05-05 19:48:51'),
(421, 102, 30, 0, 0, '2021-05-05 19:48:51', '2021-05-05 19:48:51'),
(422, 103, 28, 0, 0, '2021-05-05 19:50:19', '2021-05-05 19:50:19'),
(423, 103, 31, 0, 0, '2021-05-05 19:50:19', '2021-05-05 19:50:19'),
(424, 104, 166, 0, 0, '2021-05-08 20:33:49', '2021-05-08 20:33:49'),
(425, 105, 166, 0, 0, '2021-05-21 18:20:09', '2021-05-21 18:20:09'),
(426, 106, 24, 0, 0, '2021-05-21 18:28:33', '2021-05-21 18:28:33'),
(427, 106, 25, 0, 0, '2021-05-21 18:28:33', '2021-05-21 18:28:33'),
(428, 106, 26, 0, 0, '2021-05-21 18:28:33', '2021-05-21 18:28:33'),
(429, 107, 24, 0, 0, '2021-05-21 19:13:17', '2021-05-21 19:13:17'),
(430, 107, 25, 0, 0, '2021-05-21 19:13:17', '2021-05-21 19:13:17'),
(431, 107, 26, 0, 0, '2021-05-21 19:13:17', '2021-05-21 19:13:17'),
(432, 108, 171, 0, 0, '2022-03-08 18:34:08', '2022-03-08 18:34:08'),
(433, 108, 173, 0, 0, '2022-03-08 18:34:08', '2022-03-08 18:34:08'),
(434, 109, 28, 0, 0, '2022-06-28 06:43:55', '2022-06-28 06:43:55'),
(435, 109, 29, 0, 0, '2022-06-28 06:43:55', '2022-06-28 06:43:55'),
(436, 110, 28, 0, 0, '2022-06-28 06:50:24', '2022-06-28 06:50:24'),
(437, 110, 38, 0, 0, '2022-06-28 06:50:24', '2022-06-28 06:50:24'),
(438, 111, 16, 0, 0, '2022-10-29 13:57:03', '2022-10-29 13:57:03'),
(439, 111, 21, 0, 0, '2022-10-29 13:57:03', '2022-10-29 13:57:03'),
(440, 111, 167, 0, 0, '2022-10-29 13:57:03', '2022-10-29 13:57:03');

-- --------------------------------------------------------

--
-- Table structure for table `shop_account_intormations`
--

CREATE TABLE `shop_account_intormations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `billingDate` datetime DEFAULT NULL,
  `billingGraceDate` varchar(50) DEFAULT NULL,
  `billAmount` double DEFAULT NULL,
  `totalMonth` double DEFAULT NULL,
  `totalPaid` double DEFAULT NULL,
  `currentDue` double DEFAULT NULL,
  `topupCurrentBalance` double DEFAULT NULL,
  `topupTotalBalance` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_account_intormations`
--

INSERT INTO `shop_account_intormations` (`id`, `shopId`, `billingDate`, `billingGraceDate`, `billAmount`, `totalMonth`, `totalPaid`, `currentDue`, `topupCurrentBalance`, `topupTotalBalance`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-01-31 09:47:19', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-06-16 09:46:30', '2022-06-16 09:47:20'),
(2, 3, '2022-07-20 09:55:07', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-06-20 09:54:38', '2022-06-20 09:55:08'),
(3, 4, '2022-07-24 20:35:11', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-06-24 20:34:28', '2022-06-24 20:35:12'),
(4, 5, '2022-07-27 16:56:44', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-06-27 16:54:08', '2022-06-27 16:56:45'),
(5, 6, '2022-07-28 19:12:35', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-06-28 19:12:00', '2022-06-28 19:12:35'),
(6, 7, '2022-09-17 12:23:02', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-17 12:22:16', '2022-07-17 12:23:07'),
(7, 8, '2022-08-18 13:43:15', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-18 13:40:45', '2022-07-18 13:43:15'),
(8, 9, '2022-08-18 13:43:28', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-18 13:41:14', '2022-07-18 13:43:29'),
(9, 10, '2022-08-18 13:47:56', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-18 13:47:00', '2022-07-18 13:47:57'),
(10, 11, '2022-08-18 13:52:22', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-18 13:51:49', '2022-07-18 13:52:23'),
(11, 12, '2022-08-18 13:56:50', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-18 13:56:13', '2022-07-18 13:56:51'),
(12, 13, '2022-08-18 23:12:51', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-18 23:10:53', '2022-07-18 23:12:51'),
(13, 15, '2022-09-20 12:33:04', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-20 12:32:22', '2022-12-26 05:11:58'),
(14, 20, '2022-08-25 16:10:33', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-25 16:09:49', '2022-07-25 16:12:40'),
(15, 21, '2022-08-25 16:17:39', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-25 16:16:45', '2022-07-25 16:19:47'),
(16, 22, '2022-08-26 15:12:00', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-26 15:09:16', '2022-07-26 15:14:07'),
(17, 24, '2022-12-01 15:33:28', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-07-30 15:31:43', '2022-07-30 15:33:29'),
(18, 26, '2022-09-10 15:16:23', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-08-10 15:12:31', '2022-08-10 15:18:30'),
(19, 27, '2022-10-27 15:21:55', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 15:20:27', '2022-09-27 15:21:55'),
(20, 28, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:09:43', '2022-09-27 17:09:43'),
(21, 29, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:10:00', '2022-09-27 17:10:00'),
(22, 30, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:11:12', '2022-09-27 17:11:12'),
(23, 31, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:12:58', '2022-09-27 17:12:58'),
(24, 32, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:14:23', '2022-09-27 17:14:23'),
(25, 33, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:17:40', '2022-09-27 17:17:40'),
(26, 34, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:18:58', '2022-09-27 17:18:58'),
(27, 35, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 17:29:16', '2022-09-27 17:29:16'),
(28, 36, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 20:01:48', '2022-09-27 20:01:48'),
(29, 37, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 20:08:21', '2022-09-27 20:08:21'),
(30, 38, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 20:10:22', '2022-09-27 20:10:22'),
(31, 39, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 20:49:55', '2022-09-27 20:49:55'),
(32, 40, '2022-10-27 21:32:45', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 21:32:00', '2022-09-27 21:32:45'),
(33, 41, '2022-10-27 21:55:39', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-09-27 21:55:01', '2022-09-27 21:55:39'),
(34, 42, '2022-10-28 22:10:31', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-09-28 22:08:12', '2022-09-28 22:10:32'),
(35, 43, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-01 15:51:57', '2022-10-01 15:51:57'),
(36, 44, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-01 15:53:45', '2022-10-01 15:53:45'),
(37, 45, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-01 16:05:45', '2022-10-01 16:05:45'),
(38, 46, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-01 16:14:14', '2022-10-01 16:14:14'),
(39, 47, '2022-11-01 16:31:25', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-01 16:20:58', '2022-10-01 16:31:25'),
(40, 48, '2022-11-04 22:43:06', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-04 22:39:39', '2022-10-04 22:43:06'),
(41, 49, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-06 21:53:55', '2022-10-06 21:53:55'),
(42, 50, '2022-11-07 00:39:32', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-06 22:12:37', '2022-10-07 00:39:32'),
(43, 51, '2022-11-07 00:22:50', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-06 23:31:10', '2022-10-07 00:22:50'),
(44, 52, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-07 00:01:56', '2022-10-07 00:01:56'),
(45, 53, '2022-11-07 00:55:55', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-07 00:54:53', '2022-10-07 00:55:55'),
(46, 54, '2022-11-07 09:55:46', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-07 09:53:59', '2022-10-07 09:55:46'),
(47, 57, '2022-11-07 18:15:14', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-07 18:12:44', '2022-10-07 18:15:14'),
(48, 58, '2022-11-07 19:59:23', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-07 19:58:34', '2022-10-07 19:59:23'),
(49, 59, '2022-11-08 20:12:04', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-08 20:11:07', '2022-10-08 20:12:04'),
(50, 60, '2022-12-08 21:24:06', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-08 21:23:21', '2022-10-08 21:24:07'),
(51, 61, '2022-11-08 23:32:29', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-08 23:32:00', '2022-10-08 23:32:29'),
(52, 62, '2022-11-09 10:36:27', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-09 10:34:02', '2022-10-09 10:36:27'),
(53, 63, '2022-11-15 01:17:52', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-10-15 01:17:15', '2022-10-15 01:17:52'),
(54, 64, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-25 08:10:55', '2022-10-25 08:10:55'),
(55, 65, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-10-25 08:11:56', '2022-10-25 08:11:56'),
(56, 2, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:44:01', '2022-12-14 14:44:01'),
(57, 3, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:45:36', '2022-12-14 14:45:36'),
(58, 4, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:46:14', '2022-12-14 14:46:14'),
(59, 5, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:46:50', '2022-12-14 14:46:50'),
(60, 6, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:48:31', '2022-12-14 14:48:31'),
(61, 7, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:51:28', '2022-12-14 14:51:28'),
(62, 8, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:55:49', '2022-12-14 14:55:49'),
(63, 9, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-14 14:56:15', '2022-12-14 14:56:15'),
(64, 10, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-17 12:07:45', '2022-12-17 12:07:45'),
(65, 11, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-17 12:09:02', '2022-12-17 12:09:02'),
(66, 12, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-17 12:11:07', '2022-12-17 12:11:07'),
(67, 13, NULL, NULL, 500, NULL, NULL, NULL, NULL, NULL, '2022-12-17 12:12:00', '2022-12-17 12:12:00'),
(68, 14, '2023-01-17 18:43:32', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-12-17 12:41:53', '2022-12-17 12:43:32'),
(69, 15, '2022-09-20 12:33:04', '', 500, NULL, NULL, NULL, NULL, NULL, '2022-12-26 05:11:12', '2022-12-26 05:11:58'),
(70, 16, '2023-03-03 19:29:22', '', 500, NULL, NULL, NULL, NULL, NULL, '2023-02-03 13:28:34', '2023-02-03 13:29:22');

-- --------------------------------------------------------

--
-- Table structure for table `shop_address_locations`
--

CREATE TABLE `shop_address_locations` (
  `shopALId` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `branchId` int(11) NOT NULL,
  `countryId` int(11) NOT NULL,
  `divisionId` int(11) NOT NULL,
  `districtId` int(11) NOT NULL,
  `thanaId` int(11) NOT NULL,
  `unionId` int(11) DEFAULT NULL,
  `wardId` int(11) DEFAULT NULL,
  `addressLine1` varchar(191) NOT NULL,
  `addressLine2` varchar(191) DEFAULT NULL,
  `front` varchar(255) DEFAULT NULL,
  `back` varchar(255) DEFAULT NULL,
  `left` varchar(255) DEFAULT NULL,
  `right` varchar(255) DEFAULT NULL,
  `shopSize` varchar(255) DEFAULT NULL,
  `marketName` varchar(255) DEFAULT NULL,
  `shopNo` varchar(255) DEFAULT NULL,
  `areaKnownName` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `deleteStatus` tinyint(1) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_address_locations`
--

INSERT INTO `shop_address_locations` (`shopALId`, `shopId`, `branchId`, `countryId`, `divisionId`, `districtId`, `thanaId`, `unionId`, `wardId`, `addressLine1`, `addressLine2`, `front`, `back`, `left`, `right`, `shopSize`, `marketName`, `shopNo`, `areaKnownName`, `status`, `deleteStatus`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `delete_at`) VALUES
(1, 1, 1, 19, 3, 1, 528, NULL, NULL, 'House#20,Block#G,Main Road,Banasree,Dhaka-1219', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-16 09:46:30', '2022-06-16 09:46:30', NULL),
(2, 3, 1, 19, 1, 36, 18, NULL, NULL, 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-20 09:54:38', '2022-06-20 09:54:38', NULL),
(3, 4, 1, 19, 3, 1, 545, NULL, NULL, 'Shop No# 8, 89 B.C.C Road, Wari, Dhaka-1203.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-24 20:34:28', '2022-06-24 20:34:28', NULL),
(4, 5, 1, 19, 3, 1, 527, NULL, NULL, 'Shop#201,(2nd Floor) Baily Fista,1/2 New Baily Road,Dhaka - 1205', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-27 16:54:08', '2022-06-27 16:54:08', NULL),
(5, 6, 1, 19, 3, 13, 238, NULL, NULL, 'sddsf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-28 19:12:00', '2022-06-28 19:12:00', NULL),
(6, 7, 1, 19, 3, 1, 494, NULL, NULL, 'House#20,Block#G,Main Road,Banasree,Dhaka-1219', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-17 12:22:16', '2022-07-17 12:22:16', NULL),
(7, 8, 1, 19, 3, 1, 541, NULL, NULL, 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:40:45', '2022-07-18 13:40:45', NULL),
(8, 9, 1, 19, 3, 1, 528, NULL, NULL, 'Rampura banasree dhaka 1219', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:41:14', '2022-07-18 13:41:14', NULL),
(9, 10, 1, 19, 3, 1, 500, NULL, NULL, 'Dhaka Motijheel.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:47:00', '2022-07-18 13:47:00', NULL),
(10, 11, 1, 19, 3, 1, 541, NULL, NULL, 'Uttara Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:51:49', '2022-07-18 13:51:49', NULL),
(11, 12, 1, 19, 2, 47, 115, NULL, NULL, 'Rampura banasree dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:56:13', '2022-07-18 13:56:13', NULL),
(12, 13, 1, 19, 3, 4, 166, NULL, NULL, 'sdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 23:10:53', '2022-07-18 23:10:53', NULL),
(13, 15, 1, 19, 3, 1, 495, NULL, NULL, 'sdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-20 12:32:22', '2022-07-20 12:32:22', NULL),
(14, 20, 1, 19, 3, 1, 494, NULL, NULL, 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:09:49', '2022-07-25 16:09:49', NULL),
(15, 21, 1, 19, 3, 5, 171, NULL, NULL, 'dsfsd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:16:45', '2022-07-25 16:16:45', NULL),
(16, 22, 1, 19, 1, 34, 1, NULL, NULL, 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-26 15:09:16', '2022-07-26 15:09:16', NULL),
(17, 24, 1, 19, 3, 1, 515, NULL, NULL, 'Banasree,Dhaka-1219', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-30 15:31:43', '2022-07-30 15:31:43', NULL),
(18, 26, 1, 19, 3, 1, 531, 17, NULL, 'D 3/7, Talbag\nSavar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-08-10 15:12:31', '2022-08-10 15:12:31', NULL),
(19, 27, 1, 19, 3, 1, 493, NULL, NULL, 'd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 15:20:27', '2022-09-27 15:20:27', NULL),
(20, 37, 1, 19, 3, 2, 151, NULL, NULL, 'cc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:08:21', '2022-09-27 20:08:21', NULL),
(21, 38, 1, 19, 2, 42, 61, NULL, NULL, 'dd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:10:22', '2022-09-27 20:10:22', NULL),
(22, 39, 1, 19, 2, 41, 52, NULL, NULL, 'zx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:49:55', '2022-09-27 20:49:55', NULL),
(23, 40, 1, 19, 3, 11, 221, NULL, NULL, 'classictest', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:32:00', '2022-09-27 21:32:00', NULL),
(24, 41, 1, 19, 3, 1, 501, NULL, NULL, 'sdemo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:55:01', '2022-09-27 21:55:01', NULL),
(25, 42, 1, 19, 3, 5, 172, NULL, NULL, 'xx', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-28 22:08:12', '2022-09-28 22:08:12', NULL),
(26, 46, 1, 19, 3, 6, 184, NULL, NULL, 'Hshshd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:14:14', '2022-10-01 16:14:14', NULL),
(27, 47, 1, 19, 1, 34, 1, NULL, NULL, 'ffff', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:20:58', '2022-10-01 16:20:58', NULL),
(28, 48, 1, 19, 3, 1, 508, NULL, NULL, 'dddd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-04 22:39:39', '2022-10-04 22:39:39', NULL),
(29, 49, 1, 19, 3, 6, 181, NULL, NULL, 'dd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 21:53:55', '2022-10-06 21:53:55', NULL),
(30, 50, 1, 19, 3, 1, 506, NULL, NULL, 'House#20,Block#G,Main Road,Banasree', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 22:12:37', '2022-10-06 22:12:37', NULL),
(31, 51, 1, 19, 1, 34, 1, NULL, NULL, 'nnn', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 23:31:10', '2022-10-06 23:31:10', NULL),
(32, 52, 1, 19, 1, 35, 7, NULL, NULL, 'dsa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:01:56', '2022-10-07 00:01:56', NULL),
(33, 53, 1, 19, 3, 1, 505, NULL, NULL, 'ass', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:54:53', '2022-10-07 00:54:53', NULL),
(34, 54, 1, 19, 3, 13, 234, NULL, NULL, 'House#99,1st floor,Sher Shah Suri Road,Mohammadpur Dhaka-1207', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 09:53:59', '2022-10-07 09:53:59', NULL),
(35, 57, 1, 19, 1, 34, 1, NULL, NULL, 'sfdfsd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 18:12:44', '2022-10-07 18:12:44', NULL),
(36, 58, 1, 19, 3, 1, 494, NULL, NULL, 'd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 19:58:34', '2022-10-07 19:58:34', NULL),
(37, 59, 1, 19, 1, 34, 1, NULL, NULL, 'sdfdsf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 20:11:07', '2022-10-08 20:11:07', NULL),
(38, 60, 1, 19, 3, 1, 496, NULL, NULL, 'd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 21:23:21', '2022-10-08 21:23:21', NULL),
(39, 61, 1, 19, 3, 1, 508, NULL, NULL, 'xc', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 23:32:00', '2022-10-08 23:32:00', NULL),
(40, 62, 1, 19, 3, 1, 507, NULL, NULL, 'gdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-09 10:34:02', '2022-10-09 10:34:02', NULL),
(41, 63, 1, 19, 3, 8, 197, NULL, NULL, 'z', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-15 01:17:15', '2022-10-15 01:17:15', NULL),
(42, 64, 1, 19, 1, 34, 1, NULL, NULL, 'dsfdsf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:10:56', '2022-10-25 08:10:56', NULL),
(43, 65, 1, 19, 1, 34, 1, NULL, NULL, 'dsfdsf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:11:56', '2022-10-25 08:11:56', NULL),
(44, 9, 1, 19, 1, 34, 4, NULL, NULL, 'sdfa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-14 14:56:16', '2022-12-14 14:56:16', NULL),
(45, 10, 1, 19, 3, 1, 494, NULL, NULL, 'dsasdsa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:07:45', '2022-12-17 12:07:45', NULL),
(46, 11, 1, 19, 3, 1, 494, NULL, NULL, 'dsasdsa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:09:02', '2022-12-17 12:09:02', NULL),
(47, 12, 1, 19, 1, 34, 1, NULL, NULL, 'sdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:11:07', '2022-12-17 12:11:07', NULL),
(48, 13, 1, 19, 3, 5, 176, NULL, NULL, 'zddsf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:12:01', '2022-12-17 12:12:01', NULL),
(49, 14, 1, 19, 3, 3, 161, NULL, NULL, 'sdfds', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:41:53', '2022-12-17 12:41:53', NULL),
(50, 15, 1, 19, 3, 1, 493, NULL, NULL, 'Tajmahal road, dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-26 05:11:13', '2022-12-26 05:11:13', NULL),
(51, 16, 1, 19, 3, 1, 497, NULL, NULL, 'd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2023-02-03 13:28:36', '2023-02-03 13:28:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_billing_amounts`
--

CREATE TABLE `shop_billing_amounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `billType` int(11) NOT NULL COMMENT '1.Shop/2.Branch',
  `countryId` int(11) NOT NULL,
  `billAmount` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_billing_amounts`
--

INSERT INTO `shop_billing_amounts` (`id`, `billType`, `countryId`, `billAmount`, `created_at`, `updated_at`) VALUES
(1, 1, 19, 500, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_billing_grace_information`
--

CREATE TABLE `shop_billing_grace_information` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `message` varchar(255) NOT NULL,
  `create_by` int(11) NOT NULL,
  `update_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shop_billing_requests`
--

CREATE TABLE `shop_billing_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `totalMonth` int(11) NOT NULL,
  `amount` double NOT NULL,
  `bankTypeEntryId` int(11) NOT NULL,
  `bankAccountId` int(11) NOT NULL,
  `bankDetils` varchar(255) NOT NULL,
  `mbAccountNo` varchar(255) DEFAULT NULL,
  `mbTrNo` varchar(255) DEFAULT NULL,
  `bankName` varchar(255) DEFAULT NULL,
  `accountName` varchar(255) DEFAULT NULL,
  `accountNumber` varchar(255) DEFAULT NULL,
  `branchName` varchar(255) DEFAULT NULL,
  `paySlip` varchar(255) DEFAULT NULL,
  `lastBillDate` varchar(255) DEFAULT NULL,
  `shopId` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0 COMMENT '0=pending, 1=waiting, 2=approved, 3=cancel',
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_billing_requests`
--

INSERT INTO `shop_billing_requests` (`id`, `totalMonth`, `amount`, `bankTypeEntryId`, `bankAccountId`, `bankDetils`, `mbAccountNo`, `mbTrNo`, `bankName`, `accountName`, `accountNumber`, `branchName`, `paySlip`, `lastBillDate`, `shopId`, `status`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(2, 1, 500, 1, 2, 'A/C Name : 2212222211221<br>A/C Number : doofazit<br>Branch Name : banasree', NULL, NULL, 'sa', 'as', 'as', 'as', 'images/bill_payment/', '2022-01-10 12:53:35', 6, 0, 6, NULL, '2022-01-03 07:12:30', '2022-01-12 20:37:37'),
(3, 1, 500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '121212', '121212', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-02-10 12:53:35', 6, 0, 6, NULL, '2022-01-03 07:21:29', '2022-01-12 20:37:36'),
(4, 6, 2500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '433433', '344', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-03-10 12:53:35', 6, 0, 6, NULL, '2022-01-03 07:22:29', '2022-01-12 20:37:32'),
(5, 1, 500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '231123', '123123', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-09-10 12:53:35', 6, 2, 6, 1, '2022-01-03 07:24:19', '2022-01-12 20:38:14'),
(6, 1, 500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '31-1', '01737970757', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-03-07 11:16:24', 5, 0, 5, NULL, '2022-02-20 06:10:03', NULL),
(7, 1, 500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '01739818523', 'txr44', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-03-02 23:29:24', 1, 2, 1, NULL, '2022-02-22 12:54:33', '2022-02-22 12:58:33'),
(8, 1, 500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '01749818523', 'tf3434', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-04-02 23:29:24', 1, 2, 1, NULL, '2022-02-22 13:00:38', '2022-02-22 13:23:14'),
(9, 6, 2500, 1, 2, 'A/C Name : 2212222211221<br>A/C Number : doofazit<br>Branch Name : banasree', NULL, NULL, 'Md Saiful', 'Doo', '898989', 'feni', 'images/bill_payment/1645536311.png', '2022-05-02 23:29:24', 1, 2, 1, NULL, '2022-02-22 13:25:11', '2022-02-22 13:26:13'),
(10, 1, 500, 2, 1, 'A/C Type : Agent<br>A/C Number : 01812454358', '34', 'ff', NULL, NULL, NULL, NULL, 'images/bill_payment/', '2022-11-02 23:29:24', 1, 3, 1, 1, '2022-02-22 13:29:07', '2022-02-22 13:29:18');

-- --------------------------------------------------------

--
-- Table structure for table `shop_bill_month_lists`
--

CREATE TABLE `shop_bill_month_lists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `month` int(11) NOT NULL,
  `discountAmount` double NOT NULL DEFAULT 0,
  `discountText` varchar(100) DEFAULT NULL,
  `shopId` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1 COMMENT '1=Active, 2=Inactive',
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_bill_month_lists`
--

INSERT INTO `shop_bill_month_lists` (`id`, `title`, `month`, `discountAmount`, `discountText`, `shopId`, `status`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(2, 'Six Month', 6, 500, '500 tk off', 0, 1, 0, NULL, NULL, NULL),
(3, 'One Year', 12, 1000, '1000 tk off', 0, 1, 0, NULL, NULL, NULL),
(5, 'One Month', 1, 0, NULL, 0, 1, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_contact_person_information`
--

CREATE TABLE `shop_contact_person_information` (
  `shopCPInfoId` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `CPName` varchar(100) NOT NULL,
  `CPMobileNo` varchar(50) NOT NULL,
  `CPEmail` varchar(100) DEFAULT NULL,
  `CPAddress` varchar(191) DEFAULT NULL,
  `CPPhoneNo` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `deleteStatus` tinyint(1) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_contact_person_information`
--

INSERT INTO `shop_contact_person_information` (`shopCPInfoId`, `shopId`, `CPName`, `CPMobileNo`, `CPEmail`, `CPAddress`, `CPPhoneNo`, `status`, `deleteStatus`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `delete_at`) VALUES
(1, 1, 'Md Saiful Islam', '01884724029', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-16 09:46:30', '2022-06-16 09:46:30', NULL),
(2, 3, 'demo', '4234', 'info@dailysodai.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-20 09:54:38', '2022-06-20 09:54:38', NULL),
(3, 4, 'Sayful Islam', '0172155630', 'membersit360@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-24 20:34:28', '2022-06-24 20:34:28', NULL),
(4, 5, 'Mosarraf Hossain Jinna', '01827693721', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-27 16:54:08', '2022-06-27 16:54:08', NULL),
(5, 6, 'demo', '2423', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-28 19:12:00', '2022-06-28 19:12:00', NULL),
(6, 7, 'demo', '09877', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-17 12:22:16', '2022-07-17 12:22:16', NULL),
(7, 8, 'Shakil Razve', '01799766764', 'S.shakilrezve@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:40:45', '2022-07-18 13:40:45', NULL),
(8, 9, 'Atik ALif', '01633303676', 'atikalif676@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:41:14', '2022-07-18 13:41:14', NULL),
(9, 10, 'Babul', '+8801600313121', 'md.babul2865@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:47:00', '2022-07-18 13:47:00', NULL),
(10, 11, 'Shakil razve', '01799766764', 'S.shakilrezve@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:51:49', '2022-07-18 13:51:49', NULL),
(11, 12, 'AtikAlif', '01633303676', 'atikalif676@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:56:13', '2022-07-18 13:56:13', NULL),
(12, 13, 's', '42324', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 23:10:53', '2022-07-18 23:10:53', NULL),
(13, 15, 'fds', '4543', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-20 12:32:22', '2022-07-20 12:32:22', NULL),
(14, 20, 'saiful', '89898', 'info@dailysodai.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:09:49', '2022-07-25 16:09:49', NULL),
(15, 21, 'ddds', '24343', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:16:45', '2022-07-25 16:16:45', NULL),
(16, 22, 'nazmul', '232323', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-26 15:09:16', '2022-07-26 15:09:16', NULL),
(17, 24, 'Md', '01760550958', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-30 15:31:43', '2022-07-30 15:31:43', NULL),
(18, 26, 'Masud Kamal', '01796587512', 'rehab.bangladesh2015@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-08-10 15:12:31', '2022-08-10 15:12:31', NULL),
(19, 27, 'baba', '1884724029', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 15:20:27', '2022-09-27 15:20:27', NULL),
(20, 37, 'classic2022', '34545', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:08:21', '2022-09-27 20:08:21', NULL),
(21, 38, 'dalal', '4242343', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:10:22', '2022-09-27 20:10:22', NULL),
(22, 39, 'af', '33333333', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:49:55', '2022-09-27 20:49:55', NULL),
(23, 40, 'classictest', '2454', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:32:00', '2022-09-27 21:32:00', NULL),
(24, 41, 'sdemo', '545', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:55:01', '2022-09-27 21:55:01', NULL),
(25, 42, 'ma', '7878787878', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-28 22:08:12', '2022-09-28 22:08:12', NULL),
(26, 46, 'Good2', '7666667', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:14:14', '2022-10-01 16:14:14', NULL),
(27, 47, 't', '3', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:20:58', '2022-10-01 16:20:58', NULL),
(28, 48, 'nokia', '8989898989', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-04 22:39:39', '2022-10-04 22:39:39', NULL),
(29, 49, 'bigdemo', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 21:53:55', '2022-10-06 21:53:55', NULL),
(30, 50, 'aklima', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 22:12:37', '2022-10-06 22:12:37', NULL),
(31, 51, 'Mr ayat islam', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 23:31:10', '2022-10-06 23:31:10', NULL),
(32, 52, 'sfd', '3232', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:01:56', '2022-10-07 00:01:56', NULL),
(33, 53, 'saiful islam', '988989', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:54:53', '2022-10-07 00:54:53', NULL),
(34, 54, 'father', '98989', 'doofazinfo@gmail.com', 'House#25,Road#5,Block#J,Rampura,Banasree,Dhaka', NULL, 1, 1, 1, NULL, NULL, '2022-10-07 09:53:59', '2022-10-07 09:53:59', NULL),
(35, 57, 'a', 'adfs', 'infonazmulfci@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 18:12:44', '2022-10-07 18:12:44', NULL),
(36, 58, 'tapos', '8998', 'saifulinfo.glob@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 19:58:34', '2022-10-07 19:58:34', NULL),
(37, 59, 'test', '3234', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 20:11:07', '2022-10-08 20:11:07', NULL),
(38, 60, 'special', '354', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 21:23:21', '2022-10-08 21:23:21', NULL),
(39, 61, 'gudda', '45345', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 23:32:00', '2022-10-08 23:32:00', NULL),
(40, 62, 'maro', '45435', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-09 10:34:02', '2022-10-09 10:34:02', NULL),
(41, 63, 'shop', '234234', 'doofazinfo@gmail.com', 'House#99,1st floor,Sher Shah Suri Road,Mohammadpur Dhaka-1207', NULL, 1, 1, 1, NULL, NULL, '2022-10-15 01:17:15', '2022-10-15 01:17:15', NULL),
(42, 64, 'jk', '458', 'info@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:10:55', '2022-10-25 08:10:55', NULL),
(43, 65, 'jk', '458', 'info@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:11:56', '2022-10-25 08:11:56', NULL),
(44, 9, 'sdf', '3232', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-14 14:56:16', '2022-12-14 14:56:16', NULL),
(45, 10, 'bangla', '8787887', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:07:45', '2022-12-17 12:07:45', NULL),
(46, 11, 'bangla', '8787887', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:09:02', '2022-12-17 12:09:02', NULL),
(47, 12, 'New Company', 'New Company', 'New@Company.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:11:07', '2022-12-17 12:11:07', NULL),
(48, 13, 'sa', '4232', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:12:01', '2022-12-17 12:12:01', NULL),
(49, 14, 'nokia', '888998', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:41:53', '2022-12-17 12:41:53', NULL),
(50, 15, 'Babul Uddin', '32332332', 'info@baubl.uddin', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-26 05:11:12', '2022-12-26 05:11:12', NULL),
(51, 16, 'Md babul uddin', '9900000', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2023-02-03 13:28:35', '2023-02-03 13:28:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_owner_information`
--

CREATE TABLE `shop_owner_information` (
  `shopOwnerInfoId` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `ownerTypeId` int(11) DEFAULT NULL,
  `sirialNo` int(11) DEFAULT NULL,
  `headCode` varchar(255) DEFAULT NULL,
  `shopOwnerName` varchar(100) NOT NULL,
  `shopOwnerMobileNo` varchar(50) NOT NULL,
  `shopOwnerEmail` varchar(100) DEFAULT NULL,
  `shopOwnerAddress` varchar(191) DEFAULT NULL,
  `shopOwnerPhoneNo` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `deleteStatus` tinyint(1) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleteDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_owner_information`
--

INSERT INTO `shop_owner_information` (`shopOwnerInfoId`, `shopId`, `ownerTypeId`, `sirialNo`, `headCode`, `shopOwnerName`, `shopOwnerMobileNo`, `shopOwnerEmail`, `shopOwnerAddress`, `shopOwnerPhoneNo`, `status`, `deleteStatus`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `deleteDate`) VALUES
(1, 1, NULL, 0, '', 'Md Saiful Islam', '01884724029', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-16 09:46:30', '2022-06-16 09:46:30', NULL),
(2, 3, NULL, 0, '', 'demo', '4234', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-20 09:54:38', '2022-06-20 09:54:38', NULL),
(3, 4, NULL, 0, '', 'Sayful Islam', '0172155630', 'membersit360@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-24 20:34:28', '2022-06-24 20:34:28', NULL),
(4, 5, NULL, 0, '', 'Mosarraf Hossain Jinna', '01827693721', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-27 16:54:08', '2022-06-27 16:54:08', NULL),
(5, 6, NULL, 0, '', 'demo', '2423', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-28 19:12:00', '2022-06-28 19:12:00', NULL),
(6, 7, NULL, 0, '', 'demo', '09877', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-17 12:22:16', '2022-07-17 12:22:16', NULL),
(7, 8, NULL, 0, '', 'Shakil Razve', '01799766764', 'S.shakilrezve@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:40:45', '2022-07-18 13:40:45', NULL),
(8, 9, NULL, 0, '', 'Atik ALif', '01633303676', 'atikalif676@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:41:14', '2022-07-18 13:41:14', NULL),
(9, 10, NULL, 0, '', 'Babul', '+8801600313121', 'md.babul2865@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:47:00', '2022-07-18 13:47:00', NULL),
(10, 11, NULL, 0, '', 'Shakil razve', '01799766764', 'S.shakilrezve@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:51:49', '2022-07-18 13:51:49', NULL),
(11, 12, NULL, 0, '', 'AtikAlif', '01633303676', 'atikalif676@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:56:13', '2022-07-18 13:56:13', NULL),
(12, 13, NULL, 0, '', 's', '42324', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 23:10:53', '2022-07-18 23:10:53', NULL),
(13, 15, NULL, 0, '', 'fds', '4543', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-20 12:32:22', '2022-07-20 12:32:22', NULL),
(14, 20, NULL, 0, '', 'saiful', '89898', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:09:49', '2022-07-25 16:09:49', NULL),
(15, 21, NULL, 0, '', 'ddds', '24343', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:16:45', '2022-07-25 16:16:45', NULL),
(16, 22, NULL, 0, '', 'nazmul', '232323', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-26 15:09:16', '2022-07-26 15:09:16', NULL),
(17, 24, NULL, 0, '', 'Md', '01760550958', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-30 15:31:43', '2022-07-30 15:31:43', NULL),
(18, 26, NULL, 0, '', 'Masud Kamal', '01796587512', 'rehab.bangladesh2015@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-08-10 15:12:31', '2022-08-10 15:12:31', NULL),
(19, 27, NULL, 0, '', 'baba', '1884724029', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 15:20:27', '2022-09-27 15:20:27', NULL),
(20, 37, NULL, NULL, NULL, 'classic2022', '34545', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:08:21', '2022-09-27 20:08:21', NULL),
(21, 38, NULL, NULL, NULL, 'dalal', '4242343', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:10:22', '2022-09-27 20:10:22', NULL),
(22, 39, NULL, NULL, NULL, 'af', '33333333', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:49:55', '2022-09-27 20:49:55', NULL),
(23, 40, NULL, NULL, NULL, 'classictest', '2454', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:32:00', '2022-09-27 21:32:00', NULL),
(24, 41, NULL, NULL, NULL, 'sdemo', '545', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:55:01', '2022-09-27 21:55:01', NULL),
(25, 42, NULL, NULL, NULL, 'ma', '7878787878', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-28 22:08:12', '2022-09-28 22:08:12', NULL),
(26, 41, 1, 1, '201010101', 'tst', '545', NULL, NULL, NULL, 1, 1, 41, NULL, NULL, '2022-09-29 10:27:15', '2022-09-29 10:27:15', NULL),
(27, 42, 1, 1, '201010101', 'saiful', '8989899889', NULL, NULL, NULL, 1, 1, 42, NULL, NULL, '2022-09-29 10:27:17', '2022-09-29 10:27:17', NULL),
(28, 46, 1, 1, '201010101', 'Good2', '7666667', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:14:14', '2022-10-01 16:14:14', NULL),
(29, 47, 1, 1, '201010101', 't', '3', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:20:58', '2022-10-01 16:20:58', NULL),
(30, 47, 1, 2, '201010102', 'akash', '8898989', NULL, NULL, NULL, 1, 1, 47, NULL, NULL, '2022-10-01 18:58:15', '2022-10-01 18:58:15', NULL),
(31, 47, 1, 3, '201010103', 'obuj balok', '89898989', NULL, NULL, NULL, 1, 1, 47, NULL, NULL, '2022-10-02 20:53:04', '2022-10-02 20:53:04', NULL),
(32, 47, 1, 4, '201010104', 'JESMIN', '898898989', NULL, NULL, NULL, 1, 1, 47, NULL, NULL, '2022-10-02 22:33:20', '2022-10-02 22:33:20', NULL),
(33, 48, 1, 1, '201010101', 'nokia', '8989898989', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-04 22:39:39', '2022-10-04 22:39:39', NULL),
(34, 49, 1, 1, '201010101', 'bigdemo', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 21:53:55', '2022-10-06 21:53:55', NULL),
(35, 50, 1, 1, '201010101', 'aklima', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 22:12:37', '2022-10-06 22:12:37', NULL),
(36, 51, 1, 1, '201010101', 'Mr ayat islam', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 23:31:10', '2022-10-06 23:31:10', NULL),
(37, 52, 1, 1, '201010101', 'sfd', '3232', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:01:56', '2022-10-07 00:01:56', NULL),
(38, 53, 1, 1, '201010101', 'saiful islam', '988989', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:54:53', '2022-10-07 00:54:53', NULL),
(39, 53, 1, 2, '201010102', 'saiful', '9998', NULL, NULL, NULL, 1, 1, 53, NULL, NULL, '2022-10-07 00:58:22', '2022-10-07 00:58:22', NULL),
(40, 53, 1, 3, '201010103', 'naser', '89889', NULL, NULL, NULL, 1, 1, 53, NULL, NULL, '2022-10-07 00:59:21', '2022-10-07 00:59:21', NULL),
(41, 54, 1, 1, '201010101', 'father', '98989', 'doofazinfo@gmail.com', 'House#25,Road#5,Block#J,Rampura,Banasree,Dhaka', NULL, 1, 1, 1, NULL, NULL, '2022-10-07 09:53:59', '2022-10-07 09:53:59', NULL),
(42, 54, 1, 2, '201010102', 'nazmul', '893489', NULL, NULL, NULL, 1, 1, 54, NULL, NULL, '2022-10-07 09:58:33', '2022-10-07 09:58:33', NULL),
(43, 57, 1, 1, '201010101', 'a', 'adfs', 'infonazmulfci@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 18:12:44', '2022-10-07 18:12:44', NULL),
(44, 58, 1, 1, '201010101', 'tapos', '8998', 'saifulinfo.glob@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 19:58:34', '2022-10-07 19:58:34', NULL),
(45, 58, 1, 2, '201010102', 'nanu', '99009', NULL, NULL, NULL, 1, 1, 58, NULL, NULL, '2022-10-08 19:40:02', '2022-10-08 19:40:02', NULL),
(46, 59, 1, 1, '201010101', 'test', '3234', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 20:11:07', '2022-10-08 20:11:07', NULL),
(47, 59, 1, 2, '201010102', 'saiful', '323223', NULL, NULL, NULL, 1, 1, 59, NULL, NULL, '2022-10-08 20:23:51', '2022-10-08 20:23:51', NULL),
(48, 58, 1, 3, '201010103', 'belu', '98989', NULL, NULL, NULL, 1, 1, 58, NULL, NULL, '2022-10-08 21:15:44', '2022-10-08 21:15:44', NULL),
(49, 60, 1, 1, '201010101', 'special', '354', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 21:23:21', '2022-10-08 21:23:21', NULL),
(50, 60, 1, 2, '201010102', 'mintu', '98989899', 'saifulinfo.glob@gmail.com', NULL, NULL, 1, 1, 60, NULL, NULL, '2022-10-08 21:25:29', '2022-10-08 21:25:29', NULL),
(51, 60, 1, 3, '201010103', 'Asek', '8888989', NULL, NULL, NULL, 1, 1, 60, NULL, NULL, '2022-10-08 21:27:27', '2022-10-08 21:27:27', NULL),
(52, 60, 1, 4, '201010104', 'nazmul', '8989898989', 'saifulinfo.globe@gmail.com', NULL, NULL, 1, 1, 60, NULL, NULL, '2022-10-08 21:28:25', '2022-10-08 21:28:25', NULL),
(53, 61, 1, 1, '201010101', 'gudda', '45345', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 23:32:00', '2022-10-08 23:32:00', NULL),
(54, 61, 1, 2, '201010102', 'nuro 1', '03543543546', 'cloudsoft444@gmail.com', NULL, NULL, 1, 1, 61, NULL, NULL, '2022-10-08 23:33:57', '2022-10-08 23:33:57', NULL),
(55, 61, 1, 3, '201010103', 'nuro 2', '9988989', 'cloudsoft444@gmail.com', 'vcx', NULL, 1, 1, 61, NULL, NULL, '2022-10-08 23:34:09', '2022-10-08 23:34:09', NULL),
(56, 61, 1, 4, '201010104', 'nuro 3', '0999', NULL, NULL, NULL, 1, 1, 61, NULL, NULL, '2022-10-08 23:34:21', '2022-10-08 23:34:21', NULL),
(57, 62, 1, 1, '201010101', 'maro', '45435', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-09 10:34:02', '2022-10-09 10:34:02', NULL),
(58, 62, 1, 2, '201010102', 'mridul', '89898989', NULL, NULL, NULL, 1, 1, 62, NULL, NULL, '2022-10-09 12:01:53', '2022-10-09 12:01:53', NULL),
(59, 62, 1, 3, '201010103', 'irani', '999909', NULL, NULL, NULL, 1, 1, 62, NULL, NULL, '2022-10-09 12:02:05', '2022-10-09 12:02:05', NULL),
(60, 63, 1, 1, '201010101', 'shop', '234234', 'doofazinfo@gmail.com', 'House#99,1st floor,Sher Shah Suri Road,Mohammadpur Dhaka-1207', NULL, 1, 1, 1, NULL, NULL, '2022-10-15 01:17:15', '2022-10-15 01:17:15', NULL),
(61, 63, 1, 2, '201010102', 'saiful', '01812454358', NULL, NULL, NULL, 1, 1, 63, NULL, NULL, '2022-10-15 01:30:52', '2022-10-15 01:30:52', NULL),
(62, 63, 1, 3, '201010103', 'Nazmul', '01831710927', NULL, NULL, NULL, 1, 1, 63, NULL, NULL, '2022-10-15 01:31:05', '2022-10-15 01:31:05', NULL),
(63, 64, 1, 1, '201010101', 'jk', '458', 'info@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:10:55', '2022-10-25 08:10:55', NULL),
(64, 65, 1, 1, '201010101', 'jk', '458', 'infoo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:11:56', '2022-10-25 08:11:56', NULL),
(65, 9, 1, 1, '201010101', 'sdf', '3232', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-14 14:56:16', '2022-12-14 14:56:16', NULL),
(66, 10, 1, 1, '201010101', 'bangla', '8787887', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:07:45', '2022-12-17 12:07:45', NULL),
(67, 11, 1, 1, '201010101', 'bangla', '8787887', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:09:02', '2022-12-17 12:09:02', NULL),
(68, 12, 1, 1, '201010101', 'New Company', 'New Company', 'New@Company.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:11:07', '2022-12-17 12:11:07', NULL),
(69, 13, 1, 1, '201010101', 'sa', '4232', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:12:01', '2022-12-17 12:12:01', NULL),
(70, 14, 1, 1, '201010101', 'nokia', '888998', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:41:53', '2022-12-17 12:41:53', NULL),
(71, 15, 1, 1, '201010101', 'Babul Uddin', '32332332', 'info@baubl.uddin', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-26 05:11:12', '2022-12-26 05:11:12', NULL),
(72, 16, 1, 1, '201010101', 'Md babul uddin', '9900000', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2023-02-03 13:28:35', '2023-02-03 13:28:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_representative_information`
--

CREATE TABLE `shop_representative_information` (
  `shopRepInfoId` bigint(20) UNSIGNED NOT NULL,
  `shopId` int(11) NOT NULL,
  `SRName` varchar(100) NOT NULL,
  `SRMobileNo` varchar(50) NOT NULL,
  `SREmail` varchar(100) DEFAULT NULL,
  `SRAddress` varchar(191) DEFAULT NULL,
  `SRPhoneNo` varchar(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `deleteStatus` tinyint(1) NOT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `deleteBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `delete_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_representative_information`
--

INSERT INTO `shop_representative_information` (`shopRepInfoId`, `shopId`, `SRName`, `SRMobileNo`, `SREmail`, `SRAddress`, `SRPhoneNo`, `status`, `deleteStatus`, `createBy`, `updateBy`, `deleteBy`, `created_at`, `updated_at`, `delete_at`) VALUES
(1, 1, 'Md Saiful Islam', '01884724029', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-16 09:46:30', '2022-06-16 09:46:30', NULL),
(2, 3, 'demo', '4234', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-20 09:54:38', '2022-06-20 09:54:38', NULL),
(3, 4, 'Sayful Islam', '0172155630', 'membersit360@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-24 20:34:28', '2022-06-24 20:34:28', NULL),
(4, 5, 'Mosarraf Hossain Jinna', '01827693721', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-27 16:54:08', '2022-06-27 16:54:08', NULL),
(5, 6, 'demo', '2423', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-06-28 19:12:00', '2022-06-28 19:12:00', NULL),
(6, 7, 'demo', '09877', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-17 12:22:16', '2022-07-17 12:22:16', NULL),
(7, 8, 'Shakil Razve', '01799766764', 'S.shakilrezve@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:40:45', '2022-07-18 13:40:45', NULL),
(8, 9, 'Atik ALif', '01633303676', 'atikalif676@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:41:14', '2022-07-18 13:41:14', NULL),
(9, 10, 'Babul', '+8801600313121', 'md.babul2865@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:47:00', '2022-07-18 13:47:00', NULL),
(10, 11, 'Shakil razve', '01799766764', 'S.shakilrezve@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:51:49', '2022-07-18 13:51:49', NULL),
(11, 12, 'AtikAlif', '01633303676', 'atikalif676@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 13:56:13', '2022-07-18 13:56:13', NULL),
(12, 13, 's', '42324', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-18 23:10:53', '2022-07-18 23:10:53', NULL),
(13, 15, 'fds', '4543', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-20 12:32:22', '2022-07-20 12:32:22', NULL),
(14, 20, 'saiful', '89898', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:09:49', '2022-07-25 16:09:49', NULL),
(15, 21, 'ddds', '24343', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-25 16:16:45', '2022-07-25 16:16:45', NULL),
(16, 22, 'nazmul', '232323', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-26 15:09:16', '2022-07-26 15:09:16', NULL),
(17, 24, 'Md', '01760550958', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-07-30 15:31:43', '2022-07-30 15:31:43', NULL),
(18, 26, 'Masud Kamal', '01796587512', 'rehab.bangladesh2015@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-08-10 15:12:31', '2022-08-10 15:12:31', NULL),
(19, 27, 'baba', '1884724029', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 15:20:27', '2022-09-27 15:20:27', NULL),
(20, 37, 'classic2022', '34545', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:08:21', '2022-09-27 20:08:21', NULL),
(21, 38, 'dalal', '4242343', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:10:22', '2022-09-27 20:10:22', NULL),
(22, 39, 'af', '33333333', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 20:49:55', '2022-09-27 20:49:55', NULL),
(23, 40, 'classictest', '2454', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:32:00', '2022-09-27 21:32:00', NULL),
(24, 41, 'sdemo', '545', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-27 21:55:01', '2022-09-27 21:55:01', NULL),
(25, 42, 'ma', '7878787878', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-09-28 22:08:12', '2022-09-28 22:08:12', NULL),
(26, 46, 'Good2', '7666667', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:14:14', '2022-10-01 16:14:14', NULL),
(27, 47, 't', '3', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-01 16:20:58', '2022-10-01 16:20:58', NULL),
(28, 48, 'nokia', '8989898989', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-04 22:39:39', '2022-10-04 22:39:39', NULL),
(29, 49, 'bigdemo', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 21:53:55', '2022-10-06 21:53:55', NULL),
(30, 50, 'aklima', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 22:12:37', '2022-10-06 22:12:37', NULL),
(31, 51, 'Mr ayat islam', '01812454358', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-06 23:31:10', '2022-10-06 23:31:10', NULL),
(32, 52, 'sfd', '3232', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:01:56', '2022-10-07 00:01:56', NULL),
(33, 53, 'saiful islam', '988989', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 00:54:53', '2022-10-07 00:54:53', NULL),
(34, 54, 'father', '98989', 'doofazinfo@gmail.com', 'House#25,Road#5,Block#J,Rampura,Banasree,Dhaka', NULL, 1, 1, 1, NULL, NULL, '2022-10-07 09:53:59', '2022-10-07 09:53:59', NULL),
(35, 57, 'a', 'adfs', 'infonazmulfci@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 18:12:44', '2022-10-07 18:12:44', NULL),
(36, 58, 'tapos', '8998', 'saifulinfo.glob@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-07 19:58:34', '2022-10-07 19:58:34', NULL),
(37, 59, 'test', '3234', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 20:11:07', '2022-10-08 20:11:07', NULL),
(38, 60, 'special', '354', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 21:23:21', '2022-10-08 21:23:21', NULL),
(39, 61, 'gudda', '45345', 'doofazinfo@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-08 23:32:00', '2022-10-08 23:32:00', NULL),
(40, 62, 'maro', '45435', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-09 10:34:02', '2022-10-09 10:34:02', NULL),
(41, 63, 'shop', '234234', 'doofazinfo@gmail.com', 'House#99,1st floor,Sher Shah Suri Road,Mohammadpur Dhaka-1207', NULL, 1, 1, 1, NULL, NULL, '2022-10-15 01:17:15', '2022-10-15 01:17:15', NULL),
(42, 64, 'jk', '458', 'info@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:10:55', '2022-10-25 08:10:55', NULL),
(43, 65, 'jk', '458', 'info@gmail.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-10-25 08:11:56', '2022-10-25 08:11:56', NULL),
(44, 9, 'sdf', '3232', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-14 14:56:16', '2022-12-14 14:56:16', NULL),
(45, 10, 'bangla', '8787887', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:07:45', '2022-12-17 12:07:45', NULL),
(46, 11, 'bangla', '8787887', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:09:02', '2022-12-17 12:09:02', NULL),
(47, 12, 'New Company', 'New Company', 'New@Company.com', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:11:07', '2022-12-17 12:11:07', NULL),
(48, 13, 'sa', '4232', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:12:01', '2022-12-17 12:12:01', NULL),
(49, 14, 'nokia', '888998', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-17 12:41:53', '2022-12-17 12:41:53', NULL),
(50, 15, 'Babul Uddin', '32332332', 'info@baubl.uddin', NULL, NULL, 1, 1, 1, NULL, NULL, '2022-12-26 05:11:13', '2022-12-26 05:11:13', NULL),
(51, 16, 'Md babul uddin', '9900000', NULL, NULL, NULL, 1, 1, 1, NULL, NULL, '2023-02-03 13:28:36', '2023-02-03 13:28:36', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shop_type_entries`
--

CREATE TABLE `shop_type_entries` (
  `shopTypeEntryId` bigint(20) UNSIGNED NOT NULL,
  `shopTypeName` varchar(191) NOT NULL,
  `shopTypeCode` varchar(10) NOT NULL,
  `shopTypeStatus` int(11) NOT NULL,
  `demoShopTypeCode` varchar(20) DEFAULT NULL,
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_type_entries`
--

INSERT INTO `shop_type_entries` (`shopTypeEntryId`, `shopTypeName`, `shopTypeCode`, `shopTypeStatus`, `demoShopTypeCode`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(1, 'Pharmacy', '01', 1, NULL, 1, 1, '2021-12-08 12:34:56', '2022-01-24 10:56:34'),
(2, 'Tiles and sanitary', '02', 1, NULL, 1, 1, '2021-12-09 08:48:48', '2022-01-24 10:57:10'),
(3, 'Office Management', '03', 1, NULL, 1, NULL, '2022-01-24 10:57:41', NULL),
(4, 'Cosmetics', '04', 1, NULL, 1, NULL, '2022-01-24 10:58:23', NULL),
(5, 'Grocery Shop', '05', 1, NULL, 1, 1, '2022-01-24 10:58:23', '2022-01-24 10:59:53'),
(6, 'Super Shop', '06', 1, NULL, 1, NULL, '2022-01-24 11:00:27', NULL),
(7, 'Electrical shop', '07', 1, NULL, 1, 1, '2022-01-24 11:01:02', '2022-01-24 11:01:12'),
(8, 'Electronics Shop', '08', 1, NULL, 1, NULL, '2022-01-24 11:01:55', NULL),
(9, 'Mobile and Mobile Accessories', '09', 1, NULL, 1, NULL, '2022-01-24 11:02:45', NULL),
(10, 'computer and computer accessories', '10', 1, NULL, 1, NULL, '2022-01-24 11:03:20', NULL),
(11, 'Jewelry Shop', '11', 1, NULL, 1, NULL, '2022-01-24 11:04:40', NULL),
(12, 'Restaurants and Cafe', '12', 1, NULL, 1, NULL, '2022-01-24 11:05:30', NULL),
(13, 'automobile shop', '13', 1, NULL, 1, NULL, '2022-01-24 11:06:07', NULL),
(14, 'salon and spa', '14', 1, NULL, 1, NULL, '2022-01-24 11:06:46', NULL),
(15, 'furniture shop', '15', 1, NULL, 1, NULL, '2022-01-24 11:07:25', NULL),
(16, 'iron & steel ss', '16', 1, NULL, 1, NULL, '2022-01-24 11:08:28', NULL),
(17, 'hardware and fittings', '17', 1, NULL, 1, NULL, '2022-01-24 11:09:29', NULL),
(18, 'paint shop', '18', 1, NULL, 1, NULL, '2022-01-24 11:10:22', NULL),
(19, 'glass and aluminium', '19', 1, NULL, 1, NULL, '2022-01-24 11:10:52', NULL),
(20, 'library and stationary', '20', 1, NULL, 1, NULL, '2022-01-24 11:11:27', NULL),
(21, 'fashion shop', '21', 1, NULL, 1, NULL, '2022-01-24 11:12:16', NULL),
(22, 'shoes shop', '22', 1, NULL, 1, NULL, '2022-01-24 11:13:06', NULL),
(23, 'sports and fitness', '23', 1, NULL, 1, NULL, '2022-01-24 11:13:28', NULL),
(24, 'leather accessories', '24', 1, NULL, 1, NULL, '2022-01-24 11:14:08', NULL),
(25, 'watch and sunglass', '25', 1, NULL, 1, NULL, '2022-01-24 11:15:16', NULL),
(26, 'gift  and craft', '26', 1, NULL, 1, NULL, '2022-01-24 11:16:35', NULL),
(27, 'bike and car showroom', '27', 1, NULL, 1, NULL, '2022-01-24 11:20:57', NULL),
(28, 'flowers shop', '28', 1, NULL, 1, NULL, '2022-01-24 11:22:08', NULL),
(29, 'feed and poultry', '29', 1, NULL, 1, NULL, '2022-01-24 11:23:14', NULL),
(30, 'sweets and bakers', '30', 1, NULL, 1, NULL, '2022-01-24 11:23:45', NULL),
(31, 'crockeries shop', '31', 1, NULL, 1, NULL, '2022-01-24 11:25:03', NULL),
(32, 'E-commerce Item', '32', 1, '32-1', 1, 1, '2022-01-24 11:48:53', '2022-02-07 05:31:54'),
(33, 'onno', '', 1, NULL, 0, NULL, NULL, NULL),
(34, 'Dealer', '', 1, NULL, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `unions`
--

CREATE TABLE `unions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `upazila_id` int(11) NOT NULL,
  `union_name` varchar(191) NOT NULL,
  `union_bn_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `unions`
--

INSERT INTO `unions` (`id`, `upazila_id`, `union_name`, `union_bn_name`, `created_at`, `updated_at`) VALUES
(1, 504, 'Chauhat', 'চৌহাট ইউনিয়ন', '2021-12-13 18:59:25', NULL),
(2, 504, '\nAmta', 'আমতা ইউনিয়ন', '2021-12-13 18:59:25', NULL),
(3, 504, '\nBali', 'বালিয়া ইউনিয়ন', '2021-12-13 18:59:25', NULL),
(4, 504, '\nJadabpur', 'যাদবপুর ইউনিয়ন', '2021-12-13 18:59:25', NULL),
(5, 504, '\nBaisakanda', 'বাইশাকান্দা ইউনিয়ন', '2021-12-13 18:59:25', NULL),
(6, 504, '\nKushura', 'কুশুরা', '2021-12-13 18:59:25', NULL),
(7, 504, '\nGangutia', 'গাংগুটিয়া', '2021-12-13 18:59:25', NULL),
(8, 504, '\nSanora', 'সানোড়া', '2021-12-13 18:59:25', NULL),
(9, 504, '\nSutipara', 'সূতিপাড়া', '2021-12-13 18:59:25', NULL),
(10, 504, '\nSombhag', 'সোমভাগ', '2021-12-13 18:59:25', NULL),
(11, 504, '\nVararia', 'ভাড়ারিয়া', '2021-12-13 18:59:25', NULL),
(12, 504, '\nDhamrai', 'ধামরাই', '2021-12-13 18:59:25', NULL),
(13, 504, '\nKulla', 'কুল্লা', '2021-12-13 18:59:25', NULL),
(14, 504, '\nRowail', 'রোয়াইল', '2021-12-13 18:59:25', NULL),
(15, 504, '\nSuapur', 'সুয়াপুর', '2021-12-13 18:59:25', NULL),
(16, 504, '\nNanna', 'নান্নার', '2021-12-13 18:59:25', NULL),
(17, 531, 'Savar', 'সাভার', '2021-12-13 18:59:55', NULL),
(18, 531, '\nBirulia', 'বিরুলিয়া', '2021-12-13 18:59:55', NULL),
(19, 531, '\nDhamsona', 'ধামসোনা', '2021-12-13 18:59:55', NULL),
(20, 531, '\nShimulia', 'শিমুলিয়া', '2021-12-13 18:59:55', NULL),
(21, 531, '\nAshulia', 'আশুলিয়া', '2021-12-13 18:59:55', NULL),
(22, 531, '\nYearpur', 'ইয়ারপুর', '2021-12-13 18:59:55', NULL),
(23, 531, '\nVakurta', 'ভাকুর্তা', '2021-12-13 18:59:55', NULL),
(24, 531, '\nPathalia', 'পাথালিয়া', '2021-12-13 18:59:55', NULL),
(25, 531, '\nBongaon', 'বনগাঁও', '2021-12-13 18:59:55', NULL),
(26, 531, '\nKaundia', 'কাউন্দিয়া', '2021-12-13 18:59:55', NULL),
(27, 531, '\nTetuljhora', 'তেঁতুলঝোড়া', '2021-12-13 18:59:55', NULL),
(28, 531, 'Aminbazar', 'আমিনবাজার', '2021-12-13 18:59:55', NULL),
(29, 514, 'Hazratpur', 'হযরতপুর', '2021-12-13 19:06:05', NULL),
(30, 514, '\nKalatia', 'কলাতিয়া ইউনিয়ন', '2021-12-13 19:06:05', NULL),
(31, 514, '\nTaranagar', 'তারানগর', '2021-12-13 19:06:05', NULL),
(32, 514, '\nSakta', 'শাক্তা', '2021-12-13 19:06:05', NULL),
(33, 514, '\nRuhitpur', 'রোহিতপুর', '2021-12-13 19:06:05', NULL),
(34, 514, '\nBasta', 'বাস্তা', '2021-12-13 19:06:06', NULL),
(35, 514, '\nKalindi', 'কালিন্দি', '2021-12-13 19:06:06', NULL),
(36, 514, '\nZinzira', 'জিনজিরা', '2021-12-13 19:06:06', NULL),
(37, 514, '\nSuvadda', 'শুভাঢ্যা ইউনিয়ন', '2021-12-13 19:06:06', NULL),
(38, 514, '\nTaghoria', 'তেঘরিয়া ইউনিয়ন', '2021-12-13 19:06:06', NULL),
(39, 514, '\nKonda', 'কোন্ডা ইউনিয়ন', '2021-12-13 19:06:06', NULL),
(40, 514, '\nAganagar', 'আগানগর ইউনিয়ন', '2021-12-13 19:06:06', NULL),
(41, 523, 'Shikaripara', 'শিকারীপাড়া ইউনিয়ন', '2021-12-13 19:09:54', NULL),
(42, 523, '\nJoykrishnapur', 'জয়কৃষ্ণপুর ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(43, 523, '\nBaruakhali', 'বারুয়াখালী ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(44, 523, '\nNayansree', 'নয়নশ্রী', '2021-12-13 19:09:55', NULL),
(45, 523, '\nSholla', 'শোল্লা ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(46, 523, '\nJantrail', 'যন্ত্রাইল ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(47, 523, '\nBandura', 'বান্দুরা ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(48, 523, '\nKalakopa', 'কলাকোপা ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(49, 523, '\nBakshanagar', 'বক্সনগর ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(50, 523, '\nBarrah', 'বাহ্রা', '2021-12-13 19:09:55', NULL),
(51, 523, '\nKailail', 'কৈলাইল', '2021-12-13 19:09:55', NULL),
(52, 523, '\nAgla', 'আগলা ইউনিয়ন', '2021-12-13 19:09:55', NULL),
(53, 523, '\nGalimpur', 'গালিমপুর', '2021-12-13 19:09:55', NULL),
(54, 523, '\nChurain', 'চুড়াইন', '2021-12-13 19:09:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `upazilas`
--

CREATE TABLE `upazilas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `district_id` int(11) NOT NULL,
  `upazila_name` varchar(191) NOT NULL,
  `upazila_bn_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `upazilas`
--

INSERT INTO `upazilas` (`id`, `district_id`, `upazila_name`, `upazila_bn_name`, `created_at`, `updated_at`) VALUES
(1, 34, 'Amtali', 'আমতলী', '0000-00-00 00:00:00', '2016-04-06 00:48:15'),
(2, 34, 'Bamna ', 'বামনা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 34, 'Barguna Sadar ', 'বরগুনা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 34, 'Betagi ', 'বেতাগি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 34, 'Patharghata ', 'পাথরঘাটা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 34, 'Taltali ', 'তালতলী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 35, 'Muladi ', 'মুলাদি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 35, 'Babuganj ', 'বাবুগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 35, 'Agailjhara ', 'আগাইলঝরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 35, 'Barisal Sadar ', 'বরিশাল সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 35, 'Bakerganj ', 'বাকেরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 35, 'Banaripara ', 'বানাড়িপারা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 35, 'Gaurnadi ', 'গৌরনদী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 35, 'Hizla ', 'হিজলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 35, 'Mehendiganj ', 'মেহেদিগঞ্জ ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 35, 'Wazirpur ', 'ওয়াজিরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 36, 'Bhola Sadar ', 'ভোলা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 36, 'Burhanuddin ', 'বুরহানউদ্দিন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 36, 'Char Fasson ', 'চর ফ্যাশন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 36, 'Daulatkhan ', 'দৌলতখান', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 36, 'Lalmohan ', 'লালমোহন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 36, 'Manpura ', 'মনপুরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(23, 36, 'Tazumuddin ', 'তাজুমুদ্দিন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(24, 37, 'Jhalokati Sadar ', 'ঝালকাঠি সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(25, 37, 'Kathalia ', 'কাঁঠালিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(26, 37, 'Nalchity ', 'নালচিতি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(27, 37, 'Rajapur ', 'রাজাপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(28, 38, 'Bauphal ', 'বাউফল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(29, 38, 'Dashmina ', 'দশমিনা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(30, 38, 'Galachipa ', 'গলাচিপা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(31, 38, 'Kalapara ', 'কালাপারা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(32, 38, 'Mirzaganj ', 'মির্জাগঞ্জ ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(33, 38, 'Patuakhali Sadar ', 'পটুয়াখালী সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(34, 38, 'Dumki ', 'ডুমকি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(35, 38, 'Rangabali ', 'রাঙ্গাবালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(36, 39, 'Bhandaria', 'ভ্যান্ডারিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(37, 39, 'Kaukhali', 'কাউখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(38, 39, 'Mathbaria', 'মাঠবাড়িয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(39, 39, 'Nazirpur', 'নাজিরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(40, 39, 'Nesarabad', 'নেসারাবাদ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(41, 39, 'Pirojpur Sadar', 'পিরোজপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(42, 39, 'Zianagar', 'জিয়ানগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(43, 40, 'Bandarban Sadar', 'বান্দরবন সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(44, 40, 'Thanchi', 'থানচি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(45, 40, 'Lama', 'লামা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(46, 40, 'Naikhongchhari', 'নাইখংছড়ি ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(47, 40, 'Ali kadam', 'আলী কদম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(48, 40, 'Rowangchhari', 'রউয়াংছড়ি ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(49, 40, 'Ruma', 'রুমা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(50, 41, 'Brahmanbaria Sadar ', 'ব্রাহ্মণবাড়িয়া সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(51, 41, 'Ashuganj ', 'আশুগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(52, 41, 'Nasirnagar ', 'নাসির নগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(53, 41, 'Nabinagar ', 'নবীনগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(54, 41, 'Sarail ', 'সরাইল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, 41, 'Shahbazpur Town', 'শাহবাজপুর টাউন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, 41, 'Kasba ', 'কসবা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(57, 41, 'Akhaura ', 'আখাউরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(58, 41, 'Bancharampur ', 'বাঞ্ছারামপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(59, 41, 'Bijoynagar ', 'বিজয় নগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(60, 42, 'Chandpur Sadar', 'চাঁদপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, 42, 'Faridganj', 'ফরিদগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, 42, 'Haimchar', 'হাইমচর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, 42, 'Haziganj', 'হাজীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, 42, 'Kachua', 'কচুয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, 42, 'Matlab Uttar', 'মতলব উত্তর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(66, 42, 'Matlab Dakkhin', 'মতলব দক্ষিণ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, 42, 'Shahrasti', 'শাহরাস্তি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, 43, 'Anwara ', 'আনোয়ারা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, 43, 'Banshkhali ', 'বাশখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, 43, 'Boalkhali ', 'বোয়ালখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, 43, 'Chandanaish ', 'চন্দনাইশ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, 43, 'Fatikchhari ', 'ফটিকছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(73, 43, 'Hathazari ', 'হাঠহাজারী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(74, 43, 'Lohagara ', 'লোহাগারা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(75, 43, 'Mirsharai ', 'মিরসরাই', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, 43, 'Patiya ', 'পটিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(77, 43, 'Rangunia ', 'রাঙ্গুনিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(78, 43, 'Raozan ', 'রাউজান', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(79, 43, 'Sandwip ', 'সন্দ্বীপ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(80, 43, 'Satkania ', 'সাতকানিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(81, 43, 'Sitakunda ', 'সীতাকুণ্ড', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(82, 44, 'Barura ', 'বড়ুরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(83, 44, 'Brahmanpara ', 'ব্রাহ্মণপাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(84, 44, 'Burichong ', 'বুড়িচং', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(85, 44, 'Chandina ', 'চান্দিনা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(86, 44, 'Chauddagram ', 'চৌদ্দগ্রাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(87, 44, 'Daudkandi ', 'দাউদকান্দি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(88, 44, 'Debidwar ', 'দেবীদ্বার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(89, 44, 'Homna ', 'হোমনা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(90, 44, 'Comilla Sadar ', 'কুমিল্লা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(91, 44, 'Laksam ', 'লাকসাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(92, 44, 'Monohorgonj ', 'মনোহরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(93, 44, 'Meghna ', 'মেঘনা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(94, 44, 'Muradnagar ', 'মুরাদনগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(95, 44, 'Nangalkot ', 'নাঙ্গালকোট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(96, 44, 'Comilla Sadar South ', 'কুমিল্লা সদর দক্ষিণ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(97, 44, 'Titas ', 'তিতাস', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(98, 45, 'Chakaria ', 'চকরিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(99, 45, 'Chakaria ', 'চকরিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(100, 45, 'Cox\'s Bazar Sadar ', 'কক্স বাজার সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(101, 45, 'Kutubdia ', 'কুতুবদিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(102, 45, 'Maheshkhali ', 'মহেশখালী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(103, 45, 'Ramu ', 'রামু', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(104, 45, 'Teknaf ', 'টেকনাফ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(105, 45, 'Ukhia ', 'উখিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(106, 45, 'Pekua ', 'পেকুয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(107, 46, 'Feni Sadar', 'ফেনী সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(108, 46, 'Chagalnaiya', 'ছাগল নাইয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(109, 46, 'Daganbhyan', 'দাগানভিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(110, 46, 'Parshuram', 'পরশুরাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(111, 46, 'Fhulgazi', 'ফুলগাজি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(112, 46, 'Sonagazi', 'সোনাগাজি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(113, 47, 'Dighinala ', 'দিঘিনালা ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(114, 47, 'Khagrachhari ', 'খাগড়াছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(115, 47, 'Lakshmichhari ', 'লক্ষ্মীছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(116, 47, 'Mahalchhari ', 'মহলছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(117, 47, 'Manikchhari ', 'মানিকছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(118, 47, 'Matiranga ', 'মাটিরাঙ্গা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(119, 47, 'Panchhari ', 'পানছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(120, 47, 'Ramgarh ', 'রামগড়', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(121, 48, 'Lakshmipur Sadar ', 'লক্ষ্মীপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(122, 48, 'Raipur ', 'রায়পুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(123, 48, 'Ramganj ', 'রামগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(124, 48, 'Ramgati ', 'রামগতি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(125, 48, 'Komol Nagar ', 'কমল নগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(126, 49, 'Noakhali Sadar ', 'নোয়াখালী সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(127, 49, 'Begumganj ', 'বেগমগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(128, 49, 'Chatkhil ', 'চাটখিল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(129, 49, 'Companyganj ', 'কোম্পানীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(130, 49, 'Shenbag ', 'শেনবাগ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(131, 49, 'Hatia ', 'হাতিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(132, 49, 'Kobirhat ', 'কবিরহাট ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(133, 49, 'Sonaimuri ', 'সোনাইমুরি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(134, 49, 'Suborno Char ', 'সুবর্ণ চর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(135, 50, 'Rangamati Sadar ', 'রাঙ্গামাটি সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(136, 50, 'Belaichhari ', 'বেলাইছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(137, 50, 'Bagaichhari ', 'বাঘাইছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(138, 50, 'Barkal ', 'বরকল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(139, 50, 'Juraichhari ', 'জুরাইছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(140, 50, 'Rajasthali ', 'রাজাস্থলি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(141, 50, 'Kaptai ', 'কাপ্তাই', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(142, 50, 'Langadu ', 'লাঙ্গাডু', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(143, 50, 'Nannerchar ', 'নান্নেরচর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(144, 50, 'Kaukhali ', 'কাউখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(150, 2, 'Faridpur Sadar ', 'ফরিদপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(151, 2, 'Boalmari ', 'বোয়ালমারী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(152, 2, 'Alfadanga ', 'আলফাডাঙ্গা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(153, 2, 'Madhukhali ', 'মধুখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(154, 2, 'Bhanga ', 'ভাঙ্গা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(155, 2, 'Nagarkanda ', 'নগরকান্ড', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(156, 2, 'Charbhadrasan ', 'চরভদ্রাসন ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(157, 2, 'Sadarpur ', 'সদরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(158, 2, 'Shaltha ', 'শালথা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(159, 3, 'Gazipur Sadar-Joydebpur', 'গাজীপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(160, 3, 'Kaliakior', 'কালিয়াকৈর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(161, 3, 'Kapasia', 'কাপাসিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(162, 3, 'Sripur', 'শ্রীপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(163, 3, 'Kaliganj', 'কালীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(164, 3, 'Tongi', 'টঙ্গি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(165, 4, 'Gopalganj Sadar ', 'গোপালগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(166, 4, 'Kashiani ', 'কাশিয়ানি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(167, 4, 'Kotalipara ', 'কোটালিপাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(168, 4, 'Muksudpur ', 'মুকসুদপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(169, 4, 'Tungipara ', 'টুঙ্গিপাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(170, 5, 'Dewanganj ', 'দেওয়ানগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(171, 5, 'Baksiganj ', 'বকসিগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(172, 5, 'Islampur ', 'ইসলামপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(173, 5, 'Jamalpur Sadar ', 'জামালপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(174, 5, 'Madarganj ', 'মাদারগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(175, 5, 'Melandaha ', 'মেলানদাহা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(176, 5, 'Sarishabari ', 'সরিষাবাড়ি ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(177, 5, 'Narundi Police I.C', 'নারুন্দি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(178, 6, 'Astagram ', 'অষ্টগ্রাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(179, 6, 'Bajitpur ', 'বাজিতপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(180, 6, 'Bhairab ', 'ভৈরব', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(181, 6, 'Hossainpur ', 'হোসেনপুর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(182, 6, 'Itna ', 'ইটনা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(183, 6, 'Karimganj ', 'করিমগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(184, 6, 'Katiadi ', 'কতিয়াদি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(185, 6, 'Kishoreganj Sadar ', 'কিশোরগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(186, 6, 'Kuliarchar ', 'কুলিয়ারচর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(187, 6, 'Mithamain ', 'মিঠামাইন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(188, 6, 'Nikli ', 'নিকলি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(189, 6, 'Pakundia ', 'পাকুন্ডা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(190, 6, 'Tarail ', 'তাড়াইল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(191, 7, 'Madaripur Sadar', 'মাদারীপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(192, 7, 'Kalkini', 'কালকিনি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(193, 7, 'Rajoir', 'রাজইর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(194, 7, 'Shibchar', 'শিবচর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(195, 8, 'Manikganj Sadar ', 'মানিকগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(196, 8, 'Singair ', 'সিঙ্গাইর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(197, 8, 'Shibalaya ', 'শিবালয়', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(198, 8, 'Saturia ', 'সাঠুরিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(199, 8, 'Harirampur ', 'হরিরামপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(200, 8, 'Ghior ', 'ঘিওর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(201, 8, 'Daulatpur ', 'দৌলতপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(202, 9, 'Lohajang ', 'লোহাজং', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(203, 9, 'Sreenagar ', 'শ্রীনগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(204, 9, 'Munshiganj Sadar ', 'মুন্সিগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(205, 9, 'Sirajdikhan ', 'সিরাজদিখান', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(206, 9, 'Tongibari ', 'টঙ্গিবাড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(207, 9, 'Gazaria ', 'গজারিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(208, 10, 'Bhaluka', 'ভালুকা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(209, 10, 'Trishal', 'ত্রিশাল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(210, 10, 'Haluaghat', 'হালুয়াঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(211, 10, 'Muktagachha', 'মুক্তাগাছা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(212, 10, 'Dhobaura', 'ধবারুয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(213, 10, 'Fulbaria', 'ফুলবাড়িয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(214, 10, 'Gaffargaon', 'গফরগাঁও', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(215, 10, 'Gauripur', 'গৌরিপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(216, 10, 'Ishwarganj', 'ঈশ্বরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(217, 10, 'Mymensingh Sadar', 'ময়মনসিং সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(218, 10, 'Nandail', 'নন্দাইল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(219, 10, 'Phulpur', 'ফুলপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(220, 11, 'Araihazar ', 'আড়াইহাজার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(221, 11, 'Sonargaon ', 'সোনারগাঁও', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(222, 11, 'Bandar', 'বান্দার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(223, 11, 'Naryanganj Sadar ', 'নারায়ানগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(224, 11, 'Rupganj ', 'রূপগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(225, 11, 'Siddirgonj ', 'সিদ্ধিরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(226, 12, 'Belabo ', 'বেলাবো', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(227, 12, 'Monohardi ', 'মনোহরদি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(228, 12, 'Narsingdi Sadar ', 'নরসিংদী সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(229, 12, 'Palash ', 'পলাশ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(230, 12, 'Raipura , Narsingdi', 'রায়পুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(231, 12, 'Shibpur ', 'শিবপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(232, 13, 'Kendua Upazilla', 'কেন্দুয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(233, 13, 'Atpara Upazilla', 'আটপাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(234, 13, 'Barhatta Upazilla', 'বরহাট্টা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(235, 13, 'Durgapur Upazilla', 'দুর্গাপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(236, 13, 'Kalmakanda Upazilla', 'কলমাকান্দা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(237, 13, 'Madan Upazilla', 'মদন', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(238, 13, 'Mohanganj Upazilla', 'মোহনগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(239, 13, 'Netrakona-S Upazilla', 'নেত্রকোনা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(240, 13, 'Purbadhala Upazilla', 'পূর্বধলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(241, 13, 'Khaliajuri Upazilla', 'খালিয়াজুরি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(242, 14, 'Baliakandi ', 'বালিয়াকান্দি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(243, 14, 'Goalandaghat ', 'গোয়ালন্দ ঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(244, 14, 'Pangsha ', 'পাংশা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(245, 14, 'Kalukhali ', 'কালুখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(246, 14, 'Rajbari Sadar ', 'রাজবাড়ি সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(247, 15, 'Shariatpur Sadar -Palong', 'শরীয়তপুর সদর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(248, 15, 'Damudya ', 'দামুদিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(249, 15, 'Naria ', 'নড়িয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(250, 15, 'Jajira ', 'জাজিরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(251, 15, 'Bhedarganj ', 'ভেদারগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(252, 15, 'Gosairhat ', 'গোসাইর হাট ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(253, 16, 'Jhenaigati ', 'ঝিনাইগাতি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(254, 16, 'Nakla ', 'নাকলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(255, 16, 'Nalitabari ', 'নালিতাবাড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(256, 16, 'Sherpur Sadar ', 'শেরপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(257, 16, 'Sreebardi ', 'শ্রীবরদি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(258, 17, 'Tangail Sadar ', 'টাঙ্গাইল সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(259, 17, 'Sakhipur ', 'সখিপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(260, 17, 'Basail ', 'বসাইল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(261, 17, 'Madhupur ', 'মধুপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(262, 17, 'Ghatail ', 'ঘাটাইল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(263, 17, 'Kalihati ', 'কালিহাতি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(264, 17, 'Nagarpur ', 'নগরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(265, 17, 'Mirzapur ', 'মির্জাপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(266, 17, 'Gopalpur ', 'গোপালপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(267, 17, 'Delduar ', 'দেলদুয়ার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(268, 17, 'Bhuapur ', 'ভুয়াপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(269, 17, 'Dhanbari ', 'ধানবাড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(270, 55, 'Bagerhat Sadar ', 'বাগেরহাট সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(271, 55, 'Chitalmari ', 'চিতলমাড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(272, 55, 'Fakirhat ', 'ফকিরহাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(273, 55, 'Kachua ', 'কচুয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(274, 55, 'Mollahat ', 'মোল্লাহাট ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(275, 55, 'Mongla ', 'মংলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(276, 55, 'Morrelganj ', 'মরেলগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(277, 55, 'Rampal ', 'রামপাল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(278, 55, 'Sarankhola ', 'স্মরণখোলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(279, 56, 'Damurhuda ', 'দামুরহুদা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(280, 56, 'Chuadanga-S ', 'চুয়াডাঙ্গা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(281, 56, 'Jibannagar ', 'জীবন নগর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(282, 56, 'Alamdanga ', 'আলমডাঙ্গা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(283, 57, 'Abhaynagar ', 'অভয়নগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(284, 57, 'Keshabpur ', 'কেশবপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(285, 57, 'Bagherpara ', 'বাঘের পাড়া ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(286, 57, 'Jessore Sadar ', 'যশোর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(287, 57, 'Chaugachha ', 'চৌগাছা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(288, 57, 'Manirampur ', 'মনিরামপুর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(289, 57, 'Jhikargachha ', 'ঝিকরগাছা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(290, 57, 'Sharsha ', 'সারশা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(291, 58, 'Jhenaidah Sadar ', 'ঝিনাইদহ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(292, 58, 'Maheshpur ', 'মহেশপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(293, 58, 'Kaliganj ', 'কালীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(294, 58, 'Kotchandpur ', 'কোট চাঁদপুর ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(295, 58, 'Shailkupa ', 'শৈলকুপা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(296, 58, 'Harinakunda ', 'হাড়িনাকুন্দা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(297, 59, 'Terokhada ', 'তেরোখাদা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(298, 59, 'Batiaghata ', 'বাটিয়াঘাটা ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(299, 59, 'Dacope ', 'ডাকপে', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(300, 59, 'Dumuria ', 'ডুমুরিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(301, 59, 'Dighalia ', 'দিঘলিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(302, 59, 'Koyra ', 'কয়ড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(303, 59, 'Paikgachha ', 'পাইকগাছা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(304, 59, 'Phultala ', 'ফুলতলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(305, 59, 'Rupsa ', 'রূপসা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(306, 60, 'Kushtia Sadar', 'কুষ্টিয়া সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(307, 60, 'Kumarkhali', 'কুমারখালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(308, 60, 'Daulatpur', 'দৌলতপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(309, 60, 'Mirpur', 'মিরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(310, 60, 'Bheramara', 'ভেরামারা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(311, 60, 'Khoksa', 'খোকসা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(312, 61, 'Magura Sadar ', 'মাগুরা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(313, 61, 'Mohammadpur ', 'মোহাম্মাদপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(314, 61, 'Shalikha ', 'শালিখা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(315, 61, 'Sreepur ', 'শ্রীপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(316, 62, 'angni ', 'আংনি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(317, 62, 'Mujib Nagar ', 'মুজিব নগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(318, 62, 'Meherpur-S ', 'মেহেরপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(319, 63, 'Narail-S Upazilla', 'নড়াইল সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(320, 63, 'Lohagara Upazilla', 'লোহাগাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(321, 63, 'Kalia Upazilla', 'কালিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(322, 64, 'Satkhira Sadar ', 'সাতক্ষীরা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(323, 64, 'Assasuni ', 'আসসাশুনি ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(324, 64, 'Debhata ', 'দেভাটা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(325, 64, 'Tala ', 'তালা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(326, 64, 'Kalaroa ', 'কলরোয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(327, 64, 'Kaliganj ', 'কালীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(328, 64, 'Shyamnagar ', 'শ্যামনগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(329, 18, 'Adamdighi', 'আদমদিঘী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(330, 18, 'Bogra Sadar', 'বগুড়া সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(331, 18, 'Sherpur', 'শেরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(332, 18, 'Dhunat', 'ধুনট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(333, 18, 'Dhupchanchia', 'দুপচাচিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(334, 18, 'Gabtali', 'গাবতলি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(335, 18, 'Kahaloo', 'কাহালু', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(336, 18, 'Nandigram', 'নন্দিগ্রাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(337, 18, 'Sahajanpur', 'শাহজাহানপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(338, 18, 'Sariakandi', 'সারিয়াকান্দি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(339, 18, 'Shibganj', 'শিবগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(340, 18, 'Sonatala', 'সোনাতলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(341, 19, 'Joypurhat S', 'জয়পুরহাট সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(342, 19, 'Akkelpur', 'আক্কেলপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(343, 19, 'Kalai', 'কালাই', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(344, 19, 'Khetlal', 'খেতলাল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(345, 19, 'Panchbibi', 'পাঁচবিবি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(346, 20, 'Naogaon Sadar ', 'নওগাঁ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(347, 20, 'Mohadevpur ', 'মহাদেবপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(348, 20, 'Manda ', 'মান্দা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(349, 20, 'Niamatpur ', 'নিয়ামতপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(350, 20, 'Atrai ', 'আত্রাই', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(351, 20, 'Raninagar ', 'রাণীনগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(352, 20, 'Patnitala ', 'পত্নীতলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(353, 20, 'Dhamoirhat ', 'ধামইরহাট ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(354, 20, 'Sapahar ', 'সাপাহার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(355, 20, 'Porsha ', 'পোরশা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(356, 20, 'Badalgachhi ', 'বদলগাছি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(357, 21, 'Natore Sadar ', 'নাটোর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(358, 21, 'Baraigram ', 'বড়াইগ্রাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(359, 21, 'Bagatipara ', 'বাগাতিপাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(360, 21, 'Lalpur ', 'লালপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(361, 21, 'Natore Sadar ', 'নাটোর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(362, 21, 'Baraigram ', 'বড়াই গ্রাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(363, 22, 'Bholahat ', 'ভোলাহাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(364, 22, 'Gomastapur ', 'গোমস্তাপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(365, 22, 'Nachole ', 'নাচোল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(366, 22, 'Nawabganj Sadar ', 'নবাবগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(367, 22, 'Shibganj ', 'শিবগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(368, 23, 'Atgharia ', 'আটঘরিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(369, 23, 'Bera ', 'বেড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(370, 23, 'Bhangura ', 'ভাঙ্গুরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(371, 23, 'Chatmohar ', 'চাটমোহর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(372, 23, 'Faridpur ', 'ফরিদপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(373, 23, 'Ishwardi ', 'ঈশ্বরদী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(374, 23, 'Pabna Sadar ', 'পাবনা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(375, 23, 'Santhia ', 'সাথিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(376, 23, 'Sujanagar ', 'সুজানগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(377, 24, 'Bagha', 'বাঘা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(378, 24, 'Bagmara', 'বাগমারা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(379, 24, 'Charghat', 'চারঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(380, 24, 'Durgapur', 'দুর্গাপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(381, 24, 'Godagari', 'গোদাগারি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(382, 24, 'Mohanpur', 'মোহনপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(383, 24, 'Paba', 'পবা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(384, 24, 'Puthia', 'পুঠিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(385, 24, 'Tanore', 'তানোর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(386, 25, 'Sirajganj Sadar ', 'সিরাজগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(387, 25, 'Belkuchi ', 'বেলকুচি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(388, 25, 'Chauhali ', 'চৌহালি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(389, 25, 'Kamarkhanda ', 'কামারখান্দা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(390, 25, 'Kazipur ', 'কাজীপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(391, 25, 'Raiganj ', 'রায়গঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(392, 25, 'Shahjadpur ', 'শাহজাদপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(393, 25, 'Tarash ', 'তারাশ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(394, 25, 'Ullahpara ', 'উল্লাপাড়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(395, 26, 'Birampur ', 'বিরামপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(396, 26, 'Birganj', 'বীরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(397, 26, 'Biral ', 'বিড়াল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(398, 26, 'Bochaganj ', 'বোচাগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(399, 26, 'Chirirbandar ', 'চিরিরবন্দর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(400, 26, 'Phulbari ', 'ফুলবাড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(401, 26, 'Ghoraghat ', 'ঘোড়াঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(402, 26, 'Hakimpur ', 'হাকিমপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(403, 26, 'Kaharole ', 'কাহারোল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(404, 26, 'Khansama ', 'খানসামা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(405, 26, 'Dinajpur Sadar ', 'দিনাজপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(406, 26, 'Nawabganj', 'নবাবগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(407, 26, 'Parbatipur ', 'পার্বতীপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(408, 27, 'Fulchhari', 'ফুলছড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(409, 27, 'Gaibandha sadar', 'গাইবান্ধা সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(410, 27, 'Gobindaganj', 'গোবিন্দগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(411, 27, 'Palashbari', 'পলাশবাড়ী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(412, 27, 'Sadullapur', 'সাদুল্যাপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(413, 27, 'Saghata', 'সাঘাটা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(414, 27, 'Sundarganj', 'সুন্দরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(415, 28, 'Kurigram Sadar', 'কুড়িগ্রাম সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(416, 28, 'Nageshwari', 'নাগেশ্বরী', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(417, 28, 'Bhurungamari', 'ভুরুঙ্গামারি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(418, 28, 'Phulbari', 'ফুলবাড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(419, 28, 'Rajarhat', 'রাজারহাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(420, 28, 'Ulipur', 'উলিপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(421, 28, 'Chilmari', 'চিলমারি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(422, 28, 'Rowmari', 'রউমারি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(423, 28, 'Char Rajibpur', 'চর রাজিবপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(424, 29, 'Lalmanirhat Sadar', 'লালমনিরহাট সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(425, 29, 'Aditmari', 'আদিতমারি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(426, 29, 'Kaliganj', 'কালীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(427, 29, 'Hatibandha', 'হাতিবান্ধা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(428, 29, 'Patgram', 'পাটগ্রাম', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(429, 30, 'Nilphamari Sadar', 'নীলফামারী সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(430, 30, 'Saidpur', 'সৈয়দপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(431, 30, 'Jaldhaka', 'জলঢাকা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(432, 30, 'Kishoreganj', 'কিশোরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(433, 30, 'Domar', 'ডোমার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(434, 30, 'Dimla', 'ডিমলা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(435, 31, 'Panchagarh Sadar', 'পঞ্চগড় সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(436, 31, 'Debiganj', 'দেবীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(437, 31, 'Boda', 'বোদা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(438, 31, 'Atwari', 'আটোয়ারি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(439, 31, 'Tetulia', 'তেতুলিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(440, 32, 'Badarganj', 'বদরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(441, 32, 'Mithapukur', 'মিঠাপুকুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(442, 32, 'Gangachara', 'গঙ্গাচরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(443, 32, 'Kaunia', 'কাউনিয়া', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(444, 32, 'Rangpur Sadar', 'রংপুর সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(445, 32, 'Pirgachha', 'পীরগাছা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(446, 32, 'Pirganj', 'পীরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(447, 32, 'Taraganj', 'তারাগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(448, 33, 'Thakurgaon Sadar ', 'ঠাকুরগাঁও সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(449, 33, 'Pirganj ', 'পীরগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(450, 33, 'Baliadangi ', 'বালিয়াডাঙ্গি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(451, 33, 'Haripur ', 'হরিপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(452, 33, 'Ranisankail ', 'রাণীসংকইল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(453, 51, 'Ajmiriganj', 'আজমিরিগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(454, 51, 'Baniachang', 'বানিয়াচং', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(455, 51, 'Bahubal', 'বাহুবল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(456, 51, 'Chunarughat', 'চুনারুঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(457, 51, 'Habiganj Sadar', 'হবিগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(458, 51, 'Lakhai', 'লাক্ষাই', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(459, 51, 'Madhabpur', 'মাধবপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(460, 51, 'Nabiganj', 'নবীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(461, 51, 'Shaistagonj ', 'শায়েস্তাগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(462, 52, 'Moulvibazar Sadar', 'মৌলভীবাজার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(463, 52, 'Barlekha', 'বড়লেখা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(464, 52, 'Juri', 'জুড়ি', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(465, 52, 'Kamalganj', 'কামালগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(466, 52, 'Kulaura', 'কুলাউরা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(467, 52, 'Rajnagar', 'রাজনগর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(468, 52, 'Sreemangal', 'শ্রীমঙ্গল', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(469, 53, 'Bishwamvarpur', 'বিসশম্ভারপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(470, 53, 'Chhatak', 'ছাতক', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(471, 53, 'Derai', 'দেড়াই', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(472, 53, 'Dharampasha', 'ধরমপাশা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(473, 53, 'Dowarabazar', 'দোয়ারাবাজার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(474, 53, 'Jagannathpur', 'জগন্নাথপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(475, 53, 'Jamalganj', 'জামালগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(476, 53, 'Sulla', 'সুল্লা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(477, 53, 'Sunamganj Sadar', 'সুনামগঞ্জ সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(478, 53, 'Shanthiganj', 'শান্তিগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(479, 53, 'Tahirpur', 'তাহিরপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(480, 54, 'Sylhet Sadar', 'সিলেট সদর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(481, 54, 'Beanibazar', 'বেয়ানিবাজার', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(482, 54, 'Bishwanath', 'বিশ্বনাথ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(483, 54, 'Dakshin Surma ', 'দক্ষিণ সুরমা', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(484, 54, 'Balaganj', 'বালাগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(485, 54, 'Companiganj', 'কোম্পানিগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(486, 54, 'Fenchuganj', 'ফেঞ্চুগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(487, 54, 'Golapganj', 'গোলাপগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(488, 54, 'Gowainghat', 'গোয়াইনঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(489, 54, 'Jaintiapur', 'জয়ন্তপুর', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(490, 54, 'Kanaighat', 'কানাইঘাট', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(491, 54, 'Zakiganj', 'জাকিগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(492, 54, 'Nobigonj', 'নবীগঞ্জ', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(493, 1, 'Adabor', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(494, 1, 'Airport', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(495, 1, 'Badda', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(496, 1, 'Banani', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(497, 1, 'Bangshal', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(498, 1, 'Bhashantek', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(499, 1, 'Cantonment', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(500, 1, 'Chackbazar', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(501, 1, 'Darussalam', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(502, 1, 'Daskhinkhan', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(503, 1, 'Demra', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(504, 1, 'Dhamrai', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(505, 1, 'Dhanmondi', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(506, 1, 'Dohar', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(507, 1, 'Gandaria', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(508, 1, 'Gulshan', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(509, 1, 'Hazaribag', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(510, 1, 'Jatrabari', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(511, 1, 'Kafrul', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(512, 1, 'Kalabagan', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(513, 1, 'Kamrangirchar', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(514, 1, 'Keraniganj', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(515, 1, 'Khilgaon', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(516, 1, 'Khilkhet', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(517, 1, 'Kotwali', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(518, 1, 'Lalbag', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(519, 1, 'Mirpur Model', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(520, 1, 'Mohammadpur', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(521, 1, 'Motijheel', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(522, 1, 'Mugda', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(523, 1, 'Nawabganj', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(524, 1, 'New Market', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(525, 1, 'Pallabi', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(526, 1, 'Paltan', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(527, 1, 'Ramna', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(528, 1, 'Rampura', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(529, 1, 'Rupnagar', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(530, 1, 'Sabujbag', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(531, 1, 'Savar', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(532, 1, 'Shah Ali', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(533, 1, 'Shahbag', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(534, 1, 'Shahjahanpur', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(535, 1, 'Sherebanglanagar', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(536, 1, 'Shyampur', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(537, 1, 'Sutrapur', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(538, 1, 'Tejgaon', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(539, 1, 'Tejgaon I/A', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(540, 1, 'Turag', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(541, 1, 'Uttara', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(542, 1, 'Uttara West', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(543, 1, 'Uttarkhan', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(544, 1, 'Vatara', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(545, 1, 'Wari', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(546, 1, 'Others', '', '2016-04-06 05:00:09', '0000-00-00 00:00:00'),
(547, 35, 'Airport', 'এয়ারপোর্ট', '2016-04-06 05:22:44', '0000-00-00 00:00:00'),
(548, 35, 'Kawnia', 'কাউনিয়া', '2016-04-06 05:24:16', '0000-00-00 00:00:00'),
(549, 35, 'Bondor', 'বন্দর', '2016-04-06 05:26:55', '0000-00-00 00:00:00'),
(550, 35, 'Others', 'অন্যান্য', '2016-04-06 05:27:50', '0000-00-00 00:00:00'),
(551, 24, 'Boalia', 'বোয়ালিয়া', '2016-04-06 05:31:49', '0000-00-00 00:00:00'),
(552, 24, 'Motihar', 'মতিহার', '2016-04-06 05:32:36', '0000-00-00 00:00:00'),
(553, 24, 'Shahmokhdum', 'শাহ্ মকখদুম ', '2016-04-06 05:35:51', '0000-00-00 00:00:00'),
(554, 24, 'Rajpara', 'রাজপারা ', '2016-04-06 05:38:08', '0000-00-00 00:00:00'),
(555, 24, 'Others', 'অন্যান্য', '2016-04-06 05:38:45', '0000-00-00 00:00:00'),
(556, 43, 'Akborsha', 'Akborsha', '2016-04-06 05:56:37', '0000-00-00 00:00:00'),
(557, 43, 'Baijid bostami', 'বাইজিদ বোস্তামী', '2016-04-06 06:09:14', '0000-00-00 00:00:00'),
(558, 43, 'Bakolia', 'বাকোলিয়া', '2016-04-06 06:10:28', '0000-00-00 00:00:00'),
(559, 43, 'Bandar', 'বন্দর', '2016-04-06 06:11:29', '0000-00-00 00:00:00'),
(560, 43, 'Chandgaon', 'চাঁদগাও', '2016-04-06 06:12:10', '0000-00-00 00:00:00'),
(561, 43, 'Chokbazar', 'চকবাজার', '2016-04-06 06:12:46', '0000-00-00 00:00:00'),
(562, 43, 'Doublemooring', 'ডাবল মুরিং', '2016-04-06 06:13:46', '0000-00-00 00:00:00'),
(563, 43, 'EPZ', 'ইপিজেড', '2016-04-06 06:14:31', '0000-00-00 00:00:00'),
(564, 43, 'Hali Shohor', 'হলী শহর', '2016-04-06 06:15:30', '0000-00-00 00:00:00'),
(565, 43, 'Kornafuli', 'কর্ণফুলি', '2016-04-06 06:16:05', '0000-00-00 00:00:00'),
(566, 43, 'Kotwali', 'কোতোয়ালী', '2016-04-06 06:16:44', '0000-00-00 00:00:00'),
(567, 43, 'Kulshi', 'কুলশি', '2016-04-06 06:17:45', '0000-00-00 00:00:00'),
(568, 43, 'Pahartali', 'পাহাড়তলী', '2016-04-06 06:19:02', '0000-00-00 00:00:00'),
(569, 43, 'Panchlaish', 'পাঁচলাইশ', '2016-04-06 06:20:00', '0000-00-00 00:00:00'),
(570, 43, 'Potenga', 'পতেঙ্গা', '2016-04-06 06:20:56', '0000-00-00 00:00:00'),
(571, 43, 'Shodhorgat', 'সদরঘাট', '2016-04-06 06:21:55', '0000-00-00 00:00:00'),
(572, 43, 'Others', 'অন্যান্য', '2016-04-06 06:22:27', '0000-00-00 00:00:00'),
(573, 44, 'Others', 'অন্যান্য', '2016-04-06 06:37:35', '0000-00-00 00:00:00'),
(574, 59, 'Aranghata', 'আড়াংঘাটা', '2016-04-06 07:30:26', '0000-00-00 00:00:00'),
(575, 59, 'Daulatpur', 'দৌলতপুর', '2016-04-06 07:31:48', '0000-00-00 00:00:00'),
(576, 59, 'Harintana', 'হারিন্তানা ', '2016-04-06 07:33:42', '0000-00-00 00:00:00'),
(577, 59, 'Horintana', 'হরিণতানা ', '2016-04-06 07:34:47', '0000-00-00 00:00:00'),
(578, 59, 'Khalishpur', 'খালিশপুর', '2016-04-06 07:35:32', '0000-00-00 00:00:00'),
(579, 59, 'Khanjahan Ali', 'খানজাহান আলী', '2016-04-06 07:36:50', '0000-00-00 00:00:00'),
(580, 59, 'Khulna Sadar', 'খুলনা সদর', '2016-04-06 07:37:34', '0000-00-00 00:00:00'),
(581, 59, 'Labanchora', 'লাবানছোরা', '2016-04-06 07:38:59', '0000-00-00 00:00:00'),
(582, 59, 'Sonadanga', 'সোনাডাঙ্গা', '2016-04-06 07:39:58', '0000-00-00 00:00:00'),
(583, 59, 'Others', 'অন্যান্য', '2016-04-06 07:41:50', '0000-00-00 00:00:00'),
(584, 2, 'Others', 'অন্যান্য', '2016-04-06 07:43:32', '0000-00-00 00:00:00'),
(585, 4, 'Others', 'অন্যান্য', '2016-04-06 07:44:43', '0000-00-00 00:00:00'),
(586, 5, 'Others', 'অন্যান্য', '2016-04-06 07:45:54', '0000-00-00 00:00:00'),
(587, 54, 'Airport', 'বিমানবন্দর', '2016-04-06 07:54:23', '0000-00-00 00:00:00'),
(588, 54, 'Hazrat Shah Paran', 'হযরত শাহ পরাণ', '2016-04-06 07:56:49', '0000-00-00 00:00:00'),
(589, 54, 'Jalalabad', 'জালালাবাদ', '2016-04-06 07:57:51', '0000-00-00 00:00:00'),
(590, 54, 'Kowtali', 'কোতোয়ালী', '2016-04-06 07:59:03', '0000-00-00 00:00:00'),
(591, 54, 'Moglabazar', 'মোগলাবাজার', '2016-04-06 08:00:34', '0000-00-00 00:00:00'),
(592, 54, 'Osmani Nagar', 'ওসমানী নগর', '2016-04-06 08:01:12', '0000-00-00 00:00:00'),
(593, 54, 'South Surma', 'দক্ষিণ সুরমা', '2016-04-06 08:01:52', '0000-00-00 00:00:00'),
(594, 54, 'Others', 'অন্যান্য', '2016-04-06 08:02:43', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `adminId` int(11) DEFAULT NULL,
  `shopId` int(11) DEFAULT NULL,
  `employeeId` int(11) DEFAULT NULL,
  `adminAccessId` varchar(191) DEFAULT NULL,
  `shopAccessName` varchar(191) DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `address` varchar(191) DEFAULT NULL,
  `createBy` int(11) DEFAULT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `email_verified_at`, `adminId`, `shopId`, `employeeId`, `adminAccessId`, `shopAccessName`, `password`, `address`, `createBy`, `updateBy`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'doofaz it', '01', 'doofazit@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, '$2y$10$OJorD8ruDZusjkPazIMYlOROVI80NlUIzKG.UKkgcSmfKvCMG0t4q', 'Dhaka', NULL, 1, 1, NULL, '2020-03-14 03:58:48', '2020-03-18 09:25:07');

-- --------------------------------------------------------

--
-- Table structure for table `user_login_histories`
--

CREATE TABLE `user_login_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ipAddress` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `shopId` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `userType` int(11) NOT NULL COMMENT '1=Admin, 2=User/shop, 3=Demo User',
  `createBy` int(11) NOT NULL,
  `updateBy` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_login_histories`
--

INSERT INTO `user_login_histories` (`id`, `ipAddress`, `userName`, `shopId`, `password`, `userType`, `createBy`, `updateBy`, `created_at`, `updated_at`) VALUES
(1, '127.0.0.1', 'siyamholiday@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-03 10:52:16', NULL),
(2, '127.0.0.1', 'siyamholiday@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-06 12:36:07', NULL),
(3, '127.0.0.1', 'siyamholiday@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-07 07:24:07', NULL),
(4, '127.0.0.1', 'siyamholiday@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-08 12:29:14', NULL),
(5, '127.0.0.1', 'siyamholiday@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-08 12:29:19', NULL),
(6, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-09 03:25:54', NULL),
(7, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-09 09:46:59', NULL),
(8, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-10 05:13:06', NULL),
(9, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-12 09:22:52', NULL),
(10, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-13 07:57:41', NULL),
(11, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-14 10:34:20', NULL),
(12, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-14 12:27:44', NULL),
(13, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-15 09:15:38', NULL),
(14, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-16 05:22:17', NULL),
(15, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-16 16:07:23', NULL),
(16, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-17 07:13:43', NULL),
(17, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-20 03:21:16', NULL),
(18, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-20 10:06:16', NULL),
(19, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-21 04:36:42', NULL),
(20, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-22 05:00:53', NULL),
(21, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-22 05:03:00', NULL),
(22, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-24 04:36:31', NULL),
(23, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-11-28 06:01:32', NULL),
(24, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-02 06:35:11', NULL),
(25, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-02 06:35:13', NULL),
(26, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-02 06:35:14', NULL),
(27, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-02 06:48:07', NULL),
(28, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-03 06:24:55', NULL),
(29, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-04 08:04:42', NULL),
(30, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-04 08:06:07', NULL),
(31, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-05 07:52:42', NULL),
(32, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-07 07:14:29', NULL),
(33, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-11 05:40:57', NULL),
(34, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-12 04:24:25', NULL),
(35, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-12 07:55:34', NULL),
(36, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-14 11:57:22', NULL),
(37, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-15 04:28:22', NULL),
(38, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-15 09:21:44', NULL),
(39, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-15 14:06:38', NULL),
(40, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-16 09:04:22', NULL),
(41, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-16 09:04:26', NULL),
(42, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-17 06:31:31', NULL),
(43, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-17 08:38:43', NULL),
(44, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-17 11:23:03', NULL),
(45, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2022-12-17 12:39:16', NULL),
(46, '127.0.0.1', 'nokia', NULL, '123', 2, 0, NULL, '2022-12-17 12:43:41', NULL),
(47, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-20 06:00:54', NULL),
(48, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-21 18:34:31', NULL),
(49, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-22 04:28:23', NULL),
(50, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-22 11:09:42', NULL),
(51, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-22 17:32:43', NULL),
(52, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-23 16:25:30', NULL),
(53, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2022-12-26 05:08:29', NULL),
(54, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-26 05:09:18', NULL),
(55, '127.0.0.1', 'travel', NULL, '123', 2, 0, NULL, '2022-12-26 05:12:32', NULL),
(56, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-27 10:31:11', NULL),
(57, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2022-12-29 04:48:21', NULL),
(58, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2022-12-30 09:15:07', NULL),
(59, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2022-12-31 05:43:21', NULL),
(60, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-01 05:12:42', NULL),
(61, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-02 05:56:41', NULL),
(62, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-03 05:36:57', NULL),
(63, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-03 18:15:08', NULL),
(64, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-04 07:40:03', NULL),
(65, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-05 04:26:58', NULL),
(66, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-09 07:26:19', NULL),
(67, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-10 05:08:54', NULL),
(68, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-11 04:30:02', NULL),
(69, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-12 11:33:02', NULL),
(70, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-13 02:17:53', NULL),
(71, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-13 14:29:45', NULL),
(72, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-14 06:17:10', NULL),
(73, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-15 05:25:08', NULL),
(74, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-01-16 05:02:57', NULL),
(75, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-01-17 03:52:37', NULL),
(76, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-17 04:27:49', NULL),
(77, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-01-18 10:58:32', NULL),
(78, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-20 03:56:17', NULL),
(79, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-21 04:57:50', NULL),
(80, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-21 06:25:46', NULL),
(81, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-21 13:53:54', NULL),
(82, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-22 07:15:24', NULL),
(83, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-22 07:17:03', NULL),
(84, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-23 12:26:51', NULL),
(85, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-23 17:02:31', NULL),
(86, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-23 18:04:39', NULL),
(87, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-24 14:04:26', NULL),
(88, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-25 06:30:34', NULL),
(89, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-25 06:56:20', NULL),
(90, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-25 19:01:16', NULL),
(91, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-26 04:29:54', NULL),
(92, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-26 04:50:38', NULL),
(93, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-26 05:40:39', NULL),
(94, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-28 04:50:44', NULL),
(95, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-01-28 15:58:12', NULL),
(96, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-28 16:06:12', NULL),
(97, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-01-28 16:08:17', NULL),
(98, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-28 16:13:49', NULL),
(99, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-29 05:42:48', NULL),
(100, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-29 11:07:33', NULL),
(101, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-29 13:48:22', NULL),
(102, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-30 04:10:01', NULL),
(103, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-01-30 05:22:34', NULL),
(104, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-01 09:40:01', NULL),
(105, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-01 16:14:29', NULL),
(106, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-02 06:15:14', NULL),
(107, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-03 13:08:20', NULL),
(108, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-03 13:17:10', NULL),
(109, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-03 13:22:48', NULL),
(110, '127.0.0.1', 'siyam', NULL, '123', 2, 0, NULL, '2023-02-03 13:29:50', NULL),
(111, '127.0.0.1', 'siyam', NULL, '123', 2, 0, NULL, '2023-02-03 13:37:38', NULL),
(112, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-03 14:14:03', NULL),
(113, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-04 06:08:07', NULL),
(114, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-05 08:23:29', NULL),
(115, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-05 08:30:49', NULL),
(116, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-05 08:32:53', NULL),
(117, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-06 03:25:28', NULL),
(118, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-06 04:21:23', NULL),
(119, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-06 05:24:23', NULL),
(120, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-08 04:17:22', NULL),
(121, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-08 04:19:39', NULL),
(122, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-02-08 04:23:22', NULL),
(123, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-09 12:26:42', NULL),
(124, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-12 11:21:47', NULL),
(125, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-13 03:33:37', NULL),
(126, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-17 06:06:26', NULL),
(127, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-17 10:00:48', NULL),
(128, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-25 05:28:07', NULL),
(129, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-26 05:46:15', NULL),
(130, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-26 19:14:43', NULL),
(131, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-27 06:24:56', NULL),
(132, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-27 14:58:22', NULL),
(133, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-28 05:52:58', NULL),
(134, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-02-28 06:54:55', NULL),
(135, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-01 07:13:23', NULL),
(136, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-01 08:58:45', NULL),
(137, '127.0.0.1', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-03-01 09:24:15', NULL),
(138, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-11 08:18:35', NULL),
(139, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-12 03:46:16', NULL),
(140, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-13 05:39:13', NULL),
(141, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-13 09:49:50', NULL),
(142, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-13 16:11:02', NULL),
(143, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-14 04:43:12', NULL),
(144, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-15 04:52:09', NULL),
(145, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-15 18:55:25', NULL),
(146, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-16 04:57:58', NULL),
(147, '127.0.0.1', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-16 16:10:14', NULL),
(148, '114.130.156.62', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-19 09:22:31', NULL),
(149, '114.130.156.62', 'tca3', NULL, '123', 2, 0, NULL, '2023-03-19 10:48:22', NULL),
(150, '103.134.63.49', 'tca3', NULL, '123', 2, 0, NULL, '2023-05-02 06:27:13', NULL),
(151, '103.134.63.49', 'travel', NULL, '123', 2, 0, NULL, '2023-05-07 04:46:56', NULL),
(152, '103.134.63.49', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-05-07 04:51:01', NULL),
(153, '114.130.156.45', 'travel', NULL, '123', 2, 0, NULL, '2023-05-15 06:37:41', NULL),
(154, '103.134.63.49', 'travel', NULL, '123', 2, 0, NULL, '2023-05-25 08:41:36', NULL),
(155, '103.143.139.143', 'siyam', NULL, '123', 2, 0, NULL, '2023-06-03 19:55:43', NULL),
(156, '103.143.139.143', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-06-03 19:56:49', NULL),
(157, '103.143.139.143', 'siyamholidays@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-06-03 19:59:50', NULL),
(158, '103.143.139.143', 'tca3', NULL, '123', 2, 0, NULL, '2023-06-03 20:04:35', NULL),
(159, '103.143.139.143', 'siyam', NULL, '123', 2, 0, NULL, '2023-06-03 20:10:27', NULL),
(160, '103.143.139.143', 'doofazit@gmail.com', NULL, '12345678', 1, 0, NULL, '2023-06-03 20:16:26', NULL),
(161, '103.143.139.143', 'doofaz', NULL, '123', 2, 0, NULL, '2023-06-03 20:16:36', NULL),
(162, '103.143.139.143', 'doofaz', NULL, '123', 2, 0, NULL, '2023-06-03 20:23:14', NULL),
(163, '103.143.139.143', 'doofaz', NULL, '123', 2, 0, NULL, '2023-06-03 20:29:29', NULL),
(164, '202.134.10.132', 'doofaz', NULL, '123', 2, 0, NULL, '2023-06-04 04:45:56', NULL),
(165, '103.134.60.51', 'doofaz', NULL, '123', 2, 0, NULL, '2024-01-16 09:38:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

CREATE TABLE `wards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `union_id` int(11) NOT NULL,
  `ward_name` varchar(191) NOT NULL,
  `ward_bn_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`id`, `union_id`, `ward_name`, `ward_bn_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'ward no 1', '', NULL, NULL),
(2, 2, 'ward no 2', '', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_setups`
--
ALTER TABLE `account_setups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_menus`
--
ALTER TABLE `admin_menus`
  ADD PRIMARY KEY (`adminMenuId`);

--
-- Indexes for table `admin_menu_title_names`
--
ALTER TABLE `admin_menu_title_names`
  ADD PRIMARY KEY (`adminMenuTitleId`);

--
-- Indexes for table `admin_sub_menus`
--
ALTER TABLE `admin_sub_menus`
  ADD PRIMARY KEY (`adminSubMenuId`);

--
-- Indexes for table `asset_brand_entries`
--
ALTER TABLE `asset_brand_entries`
  ADD PRIMARY KEY (`assetBrandEntryId`);

--
-- Indexes for table `chart_of_accounts`
--
ALTER TABLE `chart_of_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chart_of_account_balances`
--
ALTER TABLE `chart_of_account_balances`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chart_of_account_group_types`
--
ALTER TABLE `chart_of_account_group_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chart_of_account_registers`
--
ALTER TABLE `chart_of_account_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chart_of_account_relations`
--
ALTER TABLE `chart_of_account_relations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chart_of_account_relations_id_index` (`id`),
  ADD KEY `chart_of_account_relations_accountheadcode_index` (`accountHeadCode`(191));

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_categories`
--
ALTER TABLE `home_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_bank_information`
--
ALTER TABLE `htl_bank_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_bank_infos`
--
ALTER TABLE `htl_bank_infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_bookings`
--
ALTER TABLE `htl_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_booking_information`
--
ALTER TABLE `htl_booking_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_booking_invoice_no_generates`
--
ALTER TABLE `htl_booking_invoice_no_generates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_booking_product_lists`
--
ALTER TABLE `htl_booking_product_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_cancelation_policies`
--
ALTER TABLE `htl_cancelation_policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_contact_information`
--
ALTER TABLE `htl_contact_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_contact_position_types`
--
ALTER TABLE `htl_contact_position_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_contact_types`
--
ALTER TABLE `htl_contact_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_customer_information`
--
ALTER TABLE `htl_customer_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_facilities`
--
ALTER TABLE `htl_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_facility_masters`
--
ALTER TABLE `htl_facility_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_facility_types`
--
ALTER TABLE `htl_facility_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_images`
--
ALTER TABLE `htl_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_image_titles`
--
ALTER TABLE `htl_image_titles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_information`
--
ALTER TABLE `htl_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_language_information`
--
ALTER TABLE `htl_language_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_locations`
--
ALTER TABLE `htl_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_meta_information`
--
ALTER TABLE `htl_meta_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_payment_types`
--
ALTER TABLE `htl_payment_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_policy_extra_information`
--
ALTER TABLE `htl_policy_extra_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_policy_information`
--
ALTER TABLE `htl_policy_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_property_types`
--
ALTER TABLE `htl_property_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_bed_types`
--
ALTER TABLE `htl_rom_bed_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_facilities`
--
ALTER TABLE `htl_rom_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_facility_types`
--
ALTER TABLE `htl_rom_facility_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_images`
--
ALTER TABLE `htl_rom_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_information`
--
ALTER TABLE `htl_rom_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_price_types`
--
ALTER TABLE `htl_rom_price_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_pricings`
--
ALTER TABLE `htl_rom_pricings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_rom_types`
--
ALTER TABLE `htl_rom_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_room_facility_masters`
--
ALTER TABLE `htl_room_facility_masters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_settings_generals`
--
ALTER TABLE `htl_settings_generals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_settings_general_order_bies`
--
ALTER TABLE `htl_settings_general_order_bies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `htl_translate_information`
--
ALTER TABLE `htl_translate_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_account_intormations`
--
ALTER TABLE `shop_account_intormations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_address_locations`
--
ALTER TABLE `shop_address_locations`
  ADD PRIMARY KEY (`shopALId`);

--
-- Indexes for table `shop_billing_amounts`
--
ALTER TABLE `shop_billing_amounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_billing_grace_information`
--
ALTER TABLE `shop_billing_grace_information`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_billing_requests`
--
ALTER TABLE `shop_billing_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_bill_month_lists`
--
ALTER TABLE `shop_bill_month_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_contact_person_information`
--
ALTER TABLE `shop_contact_person_information`
  ADD PRIMARY KEY (`shopCPInfoId`);

--
-- Indexes for table `shop_owner_information`
--
ALTER TABLE `shop_owner_information`
  ADD PRIMARY KEY (`shopOwnerInfoId`);

--
-- Indexes for table `shop_representative_information`
--
ALTER TABLE `shop_representative_information`
  ADD PRIMARY KEY (`shopRepInfoId`);

--
-- Indexes for table `shop_type_entries`
--
ALTER TABLE `shop_type_entries`
  ADD PRIMARY KEY (`shopTypeEntryId`);

--
-- Indexes for table `unions`
--
ALTER TABLE `unions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upazilas`
--
ALTER TABLE `upazilas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `user_login_histories`
--
ALTER TABLE `user_login_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wards`
--
ALTER TABLE `wards`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_setups`
--
ALTER TABLE `account_setups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `admin_menus`
--
ALTER TABLE `admin_menus`
  MODIFY `adminMenuId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `admin_menu_title_names`
--
ALTER TABLE `admin_menu_title_names`
  MODIFY `adminMenuTitleId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `admin_sub_menus`
--
ALTER TABLE `admin_sub_menus`
  MODIFY `adminSubMenuId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `asset_brand_entries`
--
ALTER TABLE `asset_brand_entries`
  MODIFY `assetBrandEntryId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `chart_of_accounts`
--
ALTER TABLE `chart_of_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=372;

--
-- AUTO_INCREMENT for table `chart_of_account_balances`
--
ALTER TABLE `chart_of_account_balances`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `chart_of_account_group_types`
--
ALTER TABLE `chart_of_account_group_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `chart_of_account_registers`
--
ALTER TABLE `chart_of_account_registers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1210;

--
-- AUTO_INCREMENT for table `chart_of_account_relations`
--
ALTER TABLE `chart_of_account_relations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=240;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `home_categories`
--
ALTER TABLE `home_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `htl_bank_information`
--
ALTER TABLE `htl_bank_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `htl_bank_infos`
--
ALTER TABLE `htl_bank_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `htl_bookings`
--
ALTER TABLE `htl_bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `htl_booking_information`
--
ALTER TABLE `htl_booking_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `htl_booking_invoice_no_generates`
--
ALTER TABLE `htl_booking_invoice_no_generates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `htl_booking_product_lists`
--
ALTER TABLE `htl_booking_product_lists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `htl_cancelation_policies`
--
ALTER TABLE `htl_cancelation_policies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `htl_contact_information`
--
ALTER TABLE `htl_contact_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `htl_contact_position_types`
--
ALTER TABLE `htl_contact_position_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `htl_contact_types`
--
ALTER TABLE `htl_contact_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `htl_customer_information`
--
ALTER TABLE `htl_customer_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `htl_facilities`
--
ALTER TABLE `htl_facilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `htl_facility_masters`
--
ALTER TABLE `htl_facility_masters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=198;

--
-- AUTO_INCREMENT for table `htl_facility_types`
--
ALTER TABLE `htl_facility_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `htl_images`
--
ALTER TABLE `htl_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `htl_image_titles`
--
ALTER TABLE `htl_image_titles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `htl_information`
--
ALTER TABLE `htl_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `htl_language_information`
--
ALTER TABLE `htl_language_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `htl_locations`
--
ALTER TABLE `htl_locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `htl_meta_information`
--
ALTER TABLE `htl_meta_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `htl_payment_types`
--
ALTER TABLE `htl_payment_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `htl_policy_extra_information`
--
ALTER TABLE `htl_policy_extra_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `htl_policy_information`
--
ALTER TABLE `htl_policy_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `htl_property_types`
--
ALTER TABLE `htl_property_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `htl_rom_bed_types`
--
ALTER TABLE `htl_rom_bed_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `htl_rom_facilities`
--
ALTER TABLE `htl_rom_facilities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `htl_rom_facility_types`
--
ALTER TABLE `htl_rom_facility_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `htl_rom_images`
--
ALTER TABLE `htl_rom_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `htl_rom_information`
--
ALTER TABLE `htl_rom_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `htl_rom_price_types`
--
ALTER TABLE `htl_rom_price_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `htl_rom_pricings`
--
ALTER TABLE `htl_rom_pricings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `htl_rom_types`
--
ALTER TABLE `htl_rom_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `htl_room_facility_masters`
--
ALTER TABLE `htl_room_facility_masters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `htl_settings_generals`
--
ALTER TABLE `htl_settings_generals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `htl_settings_general_order_bies`
--
ALTER TABLE `htl_settings_general_order_bies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `htl_translate_information`
--
ALTER TABLE `htl_translate_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=571;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=441;

--
-- AUTO_INCREMENT for table `shop_account_intormations`
--
ALTER TABLE `shop_account_intormations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `shop_address_locations`
--
ALTER TABLE `shop_address_locations`
  MODIFY `shopALId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `shop_billing_amounts`
--
ALTER TABLE `shop_billing_amounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shop_billing_grace_information`
--
ALTER TABLE `shop_billing_grace_information`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shop_billing_requests`
--
ALTER TABLE `shop_billing_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `shop_bill_month_lists`
--
ALTER TABLE `shop_bill_month_lists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `shop_contact_person_information`
--
ALTER TABLE `shop_contact_person_information`
  MODIFY `shopCPInfoId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `shop_owner_information`
--
ALTER TABLE `shop_owner_information`
  MODIFY `shopOwnerInfoId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `shop_representative_information`
--
ALTER TABLE `shop_representative_information`
  MODIFY `shopRepInfoId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `shop_type_entries`
--
ALTER TABLE `shop_type_entries`
  MODIFY `shopTypeEntryId` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `unions`
--
ALTER TABLE `unions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `upazilas`
--
ALTER TABLE `upazilas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=595;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_login_histories`
--
ALTER TABLE `user_login_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `wards`
--
ALTER TABLE `wards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
